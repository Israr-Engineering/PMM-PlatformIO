#include <PMMInternalRTC/PMMInternalRTC.h>

// bool PMMInternalRTCCheck();
// String PMMInternalRTCTime();

RTCZero PMMInternRTC;
bool PMMInternalRTCInit()
{
    PMMInternRTC.begin();
}
uint32_t PMMInternalRTCUNIXTime()
{
    return PMMInternRTC.getEpoch();
}
void PMMInternalRTCSETUNIXTime(uint32_t time)
{
    PMMInternRTC.setEpoch(time);
}

String PMMInternalRTCTime()
{
    String returnDate = String(PMMInternRTC.getYear()) + "/" +
                        String(PMMInternRTC.getMonth()) + "/" +
                        String(PMMInternRTC.getDay()) + " " +
                        String(PMMInternRTC.getHours()) + ":" +
                        String(PMMInternRTC.getMinutes()) + ":" +
                        String(PMMInternRTC.getSeconds());
    return returnDate;
}
