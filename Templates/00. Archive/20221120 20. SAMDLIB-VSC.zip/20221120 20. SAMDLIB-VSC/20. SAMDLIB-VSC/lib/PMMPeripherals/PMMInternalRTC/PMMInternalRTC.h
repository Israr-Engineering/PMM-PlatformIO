#ifndef PMMInternalRTC
#define PMMInternalRTC
#include <Arduino.h>
#include <projectConfigration.h>
#include <Arduino.h>
#include <Wire.h>
#include <../DS3231/DS3231.h>
#include <../PMMGlobalFunction/PMMGlobalFunction.h>
#include <../RTCZero/src/RTCZero.h>

bool PMMInternalRTCInit();
bool PMMInternalRTCCheck();
String PMMInternalRTCTime();
DateTime PMMInternalRTCNOW();
uint32_t PMMInternalRTCUNIXTime();
void PMMInternalRTCSETUNIXTime(uint32_t time);
void PMMInternalSetRTC(bool form, byte year, byte month, byte date, byte hour, byte minute, byte second);

// String GetTimeandDateRTC();
// String GetTimeRTC();
// String GetDateRTC();
// String GetSecRTC();
// String GetMinRTC();
// String GetHourRTC();
// String GetDayDateRTC();
// String GetMonthRTC();
// String GetYearRTC();
// void PMMRTCSETUNIXTime(uint32_t unixTime);
// int16_t PMMReturnDayOfYear();
// int16_t PMMReturnCurrentHour();
// int16_t PMMReturnInMinute();

#endif