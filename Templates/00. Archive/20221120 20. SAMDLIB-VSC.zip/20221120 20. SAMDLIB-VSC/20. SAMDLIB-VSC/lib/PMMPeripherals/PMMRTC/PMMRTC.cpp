
#include <PMMRTC/PMMRTC.h>

RTClib PMMDS3231;
DS3231 RTCSetTime;
bool century = false;
bool h12Flag;
bool pmFlag;

bool PMMInitRTC()
{
    Debugprintln("Start Initalizing RTC");
    bool RTCFound = false;
    RTCFound = PMMRTCCheck();
    if (RTCFound)
    {
        Debugprintln("RTC Found");
        Debugprintln("Finish Initalizing RTC");
        return RTCFound;
    }
    Debugprintln("RTC Not Found");
    Debugprintln("Finish Initalizing RTC");
    return false;
}

bool PMMRTCCheck()
{
    Wire.begin();
    Wire.beginTransmission(0x68);
    bool RTCFound = Wire.endTransmission() == 0;
    return RTCFound;
}
DateTime PMMRTCNOW()
{
    DateTime now = PMMDS3231.now();
    return now;
}
uint32_t PMMRTCUNIXTime()
{
    DateTime now = PMMDS3231.now();
    return now.unixtime();
}
void PMMRTCSETUNIXTime(uint32_t unixTime)
{
    RTCSetTime.setEpoch(unixTime);
}
String PMMRTCTime()
{
    DateTime now = PMMDS3231.now();

    String returnDate = String(now.year()) + "/" +
                        String(now.month()) + "/" +
                        String(now.day()) + " " +
                        String(now.hour()) + ":" +
                        String(now.minute()) + ":" +
                        String(now.second());
    return returnDate;
}
String PMMGetTimeFromUnix(uint32_t unix)
{
    DateTime now = DateTime(unix);

    String returnDate = String(now.year()) + "/" +
                        String(now.month()) + "/" +
                        String(now.day()) + " " +
                        String(now.hour()) + ":" +
                        String(now.minute()) + ":" +
                        String(now.second());
    return returnDate;
}
uint8_t PMMReturnMonthNumber()
{
    DateTime now = PMMDS3231.now();
    return now.month();
}
uint8_t PMMReturnDayNumber()
{
    DateTime now = PMMDS3231.now();
    return now.month();
}
bool PMMISNoon()
{
    DateTime now = PMMDS3231.now();
    if (now.hour() + 1 >= 12)
        return true;
    else
        return false;
}
int16_t PMMReturnDayOfYear()
{
    DateTime now = PMMDS3231.now();
    byte monthIndex = now.month();
    byte dayNumber = now.day();
    const uint8_t daysInMonth[] PROGMEM = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30};
    int16_t numberOfDays = 0;
    for (uint8_t i = 0; i < (monthIndex - 1); i++)
        numberOfDays += daysInMonth[i];
    numberOfDays += dayNumber;
    return numberOfDays;
}
int16_t PMMReturnCurrentHour()
{
    DateTime now = PMMDS3231.now();
    return now.hour();
}
int16_t PMMReturnInMinute()
{
    DateTime now = PMMDS3231.now();
    return now.hour() * 60 + now.minute();
}
