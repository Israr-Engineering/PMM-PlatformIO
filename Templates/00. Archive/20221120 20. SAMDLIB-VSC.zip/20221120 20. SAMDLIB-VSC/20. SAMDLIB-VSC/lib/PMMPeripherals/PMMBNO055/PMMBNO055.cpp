#include <PMMBNO055/PMMBNO055.h>
Adafruit_BNO055 bno = Adafruit_BNO055(55);

void PMMMBNO055Setup(uint8_t pinNumber)
{
    bool BNO055Found = bno.begin();
    Debugprintln("Start Initalize PMMMBNO055");
    if (!BNO055Found)
        Debugprintln("Faild Initalize PMMMBNO055");
    else
    {
        bno.setExtCrystalUse(false);
        Debugprintln("Initalize PMMMBNO055 Successfully");
    }
    
}

void PMMBNO055GetCoordination(float &xAxis, float &yAxis, float &zAxis)
{
    sensors_event_t event;
    bno.getEvent(&event);
    xAxis = event.orientation.x + xAxisCalibration;
    yAxis = event.orientation.y + yAxisCalibration;
    zAxis = event.orientation.z + zAxisCalibration;
    // /* Display the floating point data */
    // SerialUSB.print("X: ");
    // SerialUSB.print(xAxis, 4);
    // SerialUSB.print("\tY: ");
    // SerialUSB.print(yAxis, 4);
    // SerialUSB.print("\tZ: ");
    // SerialUSB.print(zAxis, 4);
    // SerialUSB.println("");
    // delay(100);
}

void PMMBNO55Calibrate()
{
    // @TODO Joghaimi  Save Default Settings In EEPROM
    float currentxAxis, currentyAxis, currentzAxis;
    // Set The Current Values to zero
    xAxisCalibration = 0;
    yAxisCalibration = 0;
    zAxisCalibration = 0;
    PMMBNO055GetCoordination(currentxAxis, currentyAxis, currentzAxis);
    xAxisCalibration = -1 * currentxAxis;
    yAxisCalibration = -1 * currentyAxis;
    zAxisCalibration = -1 * currentzAxis;
    Debugprintln("BNO055 Calibrated ..");
}