#ifndef PMMBNO055
#define PMMBNO055
#include <Arduino.h>
#include <projectConfigration.h>
#include <SPI.h>
#include <Wire.h>
#include <Adafruit BNO055/Adafruit_BNO055.h>
#include <Adafruit BNO055/utility/imumaths.h>
#include <Adafruit_Sensor.h>
#include <../PMMGlobalFunction/PMMGlobalFunction.h>
void PMMMBNO055Setup(uint8_t pinNumber);
void PMMBNO055GetCoordination(float &xAxis, float &yAxis, float &zAxis);
void PMMBNO55Calibrate();

extern float xAxisCalibration, yAxisCalibration, zAxisCalibration;

#endif