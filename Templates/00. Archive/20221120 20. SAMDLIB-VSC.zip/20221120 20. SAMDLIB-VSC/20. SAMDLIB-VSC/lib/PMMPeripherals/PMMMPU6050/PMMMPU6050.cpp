#include <PMMMPU6050/PMMMPU6050.h>

// === MPU
MPU6050 mpu;
// Adafruit_MPU6050 PMMMPU;
#define OUTPUT_READABLE_YAWPITCHROLL
bool dmpReady = false;  // set true if DMP init was successful
uint8_t devStatus;      // return status after each device operation (0 = success, !0 = error)
uint16_t fifoCount;     // count of all bytes currently in FIFO
uint8_t fifoBuffer[64]; // FIFO storage buffer
Quaternion q;           // [w, x, y, z]         quaternion container
VectorFloat gravity;    // [x, y, z]            gravity vector
float ypr[3];           // [yaw, pitch, roll]   yaw/pitch/roll container and gravity vector

int timeRemoving = 0;
bool firstRun = true;
void PMMMPU6050Setup(uint8_t pinNumber)
{
    Wire.begin();
    Wire.setClock(400000); // 400kHz I2C clock. Comment this line if having compilation difficulties
    mpu.initialize();      // initialize device
    pinMode(pinNumber, INPUT);
    devStatus = mpu.dmpInitialize();

    // supply your own gyro offsets here, scaled for min sensitivity
    // mpu.setXGyroOffset(51);
    // mpu.setYGyroOffset(8);
    // mpu.setZGyroOffset(21);
    // mpu.setXAccelOffset(1150);
    // mpu.setYAccelOffset(-50);
    // mpu.setZAccelOffset(1060);

    // make sure it worked (returns 0 if so)
    if (devStatus == 0)
    {
        SerialUSB.println("Device Worked");
        // Calibration Time: generate offsets and calibrate our MPU6050
        // mpu.CalibrateAccel(6);
        // mpu.CalibrateGyro(6);
        // mpu.PrintActiveOffsets();
        // turn on the DMP, now that it's ready
        mpu.setDMPEnabled(true);
        // attachInterrupt(digitalPinToInterrupt(pinNumber), dmpDataReady, RISING);
        mpu.getIntStatus();
        // set our DMP Ready flag so the main loop() function knows it's okay to use it
        // SerialUSB.println(F("DMP ready! Waiting for first interrupt..."));
        dmpReady = true;
        // get expected DMP packet size for later comparison
        mpu.dmpGetFIFOPacketSize();
    }
    else
        SerialUSB.println("Device Not Worked");
}

bool PMMMPUCheck()
{
    Wire.begin();
    Wire.setClock(400000);
    Wire.beginTransmission(0x69);
    bool MPUFound = Wire.endTransmission() == 0;
    return MPUFound;
}

void PMMMPUGetCoordination(float &xAxis, float &yAxis, float &zAxis)
{
    if (mpu.dmpGetCurrentFIFOPacket(fifoBuffer))
    {
        // display Euler angles in degrees

        if (firstRun)
        {
            for (int i = 0; i < 40; i++)
            {
                mpu.dmpGetQuaternion(&q, fifoBuffer);
                mpu.dmpGetGravity(&gravity, &q);
                mpu.dmpGetYawPitchRoll(ypr, &q, &gravity);
                delay(500);
            }
            firstRun = false;
        }
        else
        {
            mpu.dmpGetQuaternion(&q, fifoBuffer);
            mpu.dmpGetGravity(&gravity, &q);
            mpu.dmpGetYawPitchRoll(ypr, &q, &gravity);
            xAxis = float(((ypr[0] * 180 / 3.1415) * 10) / 10) + xAxisCalibration;
            yAxis = float(((ypr[2] * 180 / 3.1415) * 10) / 10) + yAxisCalibration;
            zAxis = float(((ypr[1] * 180 / 3.1415) * 10) / 10) + zAxisCalibration;

            xAxis=PMMMPUFloatToFloat(xAxis);
            yAxis=PMMMPUFloatToFloat(yAxis);
            zAxis=PMMMPUFloatToFloat(zAxis);
        }
    }
}
float PMMMPUFloatToFloat(float value)
{
    return float(int(value * 10) / 10.0);
}
void PMMMPUCalibrate(float setThecurrentxAxis, float setThecurrentyAxis, float setThecurrentzAxis)
{
    // @TODO Joghaimi  Save Default Settings In EEPROM
    float currentxAxis, currentyAxis, currentzAxis;
    // Set The Current Values to zero
    xAxisCalibration = 0;
    yAxisCalibration = 0;
    zAxisCalibration = 0;
    PMMMPUGetCoordination(currentxAxis, currentyAxis, currentzAxis);
    xAxisCalibration = -1 * currentxAxis + setThecurrentxAxis;
    yAxisCalibration = -1 * currentyAxis + setThecurrentyAxis;
    zAxisCalibration = -1 * currentzAxis + setThecurrentzAxis;
}