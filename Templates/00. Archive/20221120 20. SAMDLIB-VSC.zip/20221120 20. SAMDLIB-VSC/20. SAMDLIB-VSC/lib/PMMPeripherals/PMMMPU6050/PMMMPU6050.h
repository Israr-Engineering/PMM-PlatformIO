#ifndef PMMMPU6050
#define PMMMPU6050
#include <Arduino.h>
#include <projectConfigration.h>
#include <Arduino.h>
#include <Wire.h>
#include <I2Cdevlib-MPU6050/MPU6050_6Axis_MotionApps612.h>
// #include <Adafruit_MPU6050.h>
// #include <Adafruit_Sensor.h>
void PMMMPU6050Setup(uint8_t pinNumber);
bool PMMMPUCheck();
void PMMMPUGetCoordination(float &xAxis, float &yAxis, float &zAxis);
void PMMMPUCalibrate(float setThecurrentxAxis, float setThecurrentyAxis, float setThecurrentzAxis);
float PMMMPUFloatToFloat(float value);
extern float xAxisCalibration, yAxisCalibration, zAxisCalibration;
extern float PMMMPUOldReadingValuex, PMMMPUOldReadingValuey, PMMMPUOldReadingValuez;

#endif