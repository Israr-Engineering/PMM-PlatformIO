#ifndef PMMLora
#define PMMLora

#include <Arduino.h>
#include <projectConfigration.h>
#include <SPI.h>
#include <Wire.h>
#include <LoRa.h>
bool PMMLoraInit(byte loraCS, byte loraRST, byte loraDo0);
void PMMLoraSendString(String sendData);
#endif