#include <PMMLora/PMMLora.h>
/***
 * ==== General Note In Lora
 *   - Software Factors SpreadingFactor, Bandwidth and CodingRate
 *   - Lora Arch is Start Toplogy
 *   - Link Budget => is the strngth of signal (whene its increase its better)
 *   - DataRate => The number of data send by secound
 *
 * ==== Functions
 *   - setTxPower : The TX power of the radio Maximum 20DB
 *   - setSpreadingFactor : Chirp Spread Spectrum (CSS) increase this value increase the distance
 *   - setSignalBandwidth
 *   - packetRssi
 *   - setCodingRate4
 *   - setPreambleLength
 *   - setGain(gain) : LNA gain
 *
 */

bool PMMLoraInit(byte loraCS, byte loraRST, byte loraDo0)
{
  LoRa.setPins(loraCS, loraRST, 10);
  SerialUSB.print("Start Initalizing Lora ");
  while (!LoRa.begin(868E6))
  {
    SerialUSB.print(".");
    delay(500);
  }
  SerialUSB.println();
  SerialUSB.println("Lora Initalized Seccuessfully");
  LoRa.setTxPower(20); // Maximum Transmition Power
  LoRa.setFrequency(868E6);
  // LoRa.setSpreadingFactor(12); //  increase this value increase the distance
  // LoRa.setSignalBandwidth(7.8E3);
  // LoRa.setSyncWord(0xF4);
  // LoRa.setGain(6);
  SerialUSB.println("Lora Initalized succ");
  return true; // TODO
}
void PMMLoraSendString(String sendData)
{
  LoRa.beginPacket();
  LoRa.print(sendData);
  LoRa.endPacket();
}

// int packetSize = LoRa.parsePacket();
// if (packetSize)
// {
//     // received a packet
//     SerialUSB.print("Received packet '");

//     // read packet
//     while (LoRa.available())
//     {
//         String LoRaData = LoRa.readString();
//         SerialUSB.print(LoRaData);
//     }

//     // print RSSI of packet
//     SerialUSB.print("' with RSSI ");
//     SerialUSB.println(LoRa.packetRssi());
//}
