#ifndef PMMUSBConfigration
#define PMMUSBConfigration
#include <Arduino.h>
#include <projectConfigration.h>
#include <PMMGlobalFunction.h>
#include <PMMUDPLib/PMMUDPLib.h>
#include <PMMEEPROMDeviceSettings/PMMEEPROMDeviceSettings.h>
#include <PMMEEPROMModBus/PMMEEPROMModBus.h>
#include <PMMEEPROMSerialParam/PMMEEPROMSerialParam.h>
#include <PMMEEPROMEthernet/PMMEEPROMEthernet.h>


#include <PMM1103DeviceLib/PMM1103SlaveDevice/PMM1103SlaveTest/PMM1103SlaveTest.h>
#include <PMM1103DeviceLib/PMM1103SlaveDevice/PMM1103SlaveMonitor/PMM1103SlaveMonitor.h>

void PMMConfigrationLoop();
void PMMSendConfigration();
void PMMSplitString(String parameter, String &returnVal, String &returnString);
void PMMGetDeviceSettings();
void PMMSendDeviceSettings();
void PMMFactoryReset();
void isAlive();


void checkUSBConnection();
void setSetting();
void UplodeSetting();
void saveUSBSettings(String str);


String USBreturnBoadrInfo();
// extern ExternalEEPROM EEPROM;
extern String controllerIPAddress;
extern String subNetMask;
extern String DNS;
extern String GatWay;
extern String remoteIPAddress;
extern String UDPPort;
extern struct SerialParameter portOne;

extern byte firstRunValue;
extern String password;
extern String DeviceName;
extern String MACAddressString;
extern String controllerSerialNumber;
extern String webservestring;

extern String DeviceName;
extern byte firstRunValue;
extern String password;

extern String UDPPort2;
extern String UDPPort3;
extern String UDPPort4;
extern String TCPORRTU;
extern String slaveId;




extern struct SerialParameter portTwo;
extern struct SerialParameter portThree;
extern struct SerialParameter portFour;

extern String FirmwareVersion;
extern String hardwareVersion;

#endif