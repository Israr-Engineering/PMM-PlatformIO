#include <PMMUSBConfigration/PMMUSBConfigration.h>

void PMMConfigrationLoop()
{
    if (!(SerialUSB.available() > 0))
        return;
    SerialUSB.setTimeout(200);
    String readData = SerialUSB.readString();
    if (readData == "PMMConfigration")
        isAlive();
    else if (readData == "PMMReset")
        NVIC_SystemReset();
    else if (readData == "PMMfactoryReset")
        PMMFactoryReset();
    else if (readData == "PMMDownloadSettings")
        PMMSendDeviceSettings();
    else if (readData == "PMMgetSetting")
        PMMGetDeviceSettings();
    else if (readData == "PMM1103SlaveTest")
        PMM1103SlaveTestLoop();
    else if (readData == "PMM1103SlaveMonitor")
        PMM1103SlaveMonitorLoop();
}

void isAlive()
{
    SerialUSB.println("PMMAlive");
}
void PMMGetDeviceSettings()
{
    String boardInfo = "";
    // boardInfo=DeviceName+","+TCPORRTU+slaveId+controllerIPAddress+subNetMask+DNS+GatWay+remoteIPAddress
    // UDPPort+UDPPort2+UDPPort3+UDPPort4+portOne.baudRate+portOne.dataBit+portOne.stopBit+portOne.parity+portOne.interface
    // +portTwo.baudRate+portTwo.dataBit+portTwo.stopBit+portTwo.parity+portTwo.interface+portTwo.baudRate+
    // portThree.dataBit+portThree.stopBit+portThree.parity+portThree.interface+
    // portFour.dataBit+portFour.stopBit+portFour.parity+portFour.interface+MACAddressString+controllerSerialNumber+
    // webservestring+FirmwareVersion+hardwareVersion

    boardInfo += "16";
    boardInfo += ",";
    boardInfo += TCPORRTU;
    boardInfo += ",";
    boardInfo += slaveId;
    boardInfo += ",";
    boardInfo += controllerIPAddress;
    boardInfo += ",";
    boardInfo += subNetMask;
    boardInfo += ",";
    boardInfo += DNS;
    boardInfo += ",";
    boardInfo += GatWay;
    boardInfo += ",";
    boardInfo += remoteIPAddress;
    boardInfo += ",";
    boardInfo += UDPPort;
    boardInfo += ",";
    boardInfo += UDPPort2;
    boardInfo += ",";
    boardInfo += UDPPort3;
    boardInfo += ",";
    boardInfo += UDPPort4;
    boardInfo += ",";
    boardInfo += portOne.baudRate;
    boardInfo += ",";
    boardInfo += portOne.dataBit;
    boardInfo += ",";
    boardInfo += portOne.stopBit;
    boardInfo += ",";
    boardInfo += portOne.parity;
    boardInfo += ",";
    boardInfo += portOne.interface;
    boardInfo += ",";

    boardInfo += portTwo.baudRate;
    boardInfo += ",";
    boardInfo += portTwo.dataBit;
    boardInfo += ",";
    boardInfo += portTwo.stopBit;
    boardInfo += ",";
    boardInfo += portTwo.parity;
    boardInfo += ",";
    boardInfo += portTwo.interface;
    boardInfo += ",";

    boardInfo += portThree.baudRate;
    boardInfo += ",";
    boardInfo += portThree.dataBit;
    boardInfo += ",";
    boardInfo += portThree.stopBit;
    boardInfo += ",";
    boardInfo += portThree.parity;
    boardInfo += ",";
    boardInfo += portThree.interface;
    boardInfo += ",";

    boardInfo += portFour.baudRate;
    boardInfo += ",";
    boardInfo += portFour.dataBit;
    boardInfo += ",";
    boardInfo += portFour.stopBit;
    boardInfo += ",";
    boardInfo += portFour.parity;
    boardInfo += ",";
    boardInfo += portFour.interface;
    boardInfo += ",";

    boardInfo += MACAddressString;
    boardInfo += ",";
    boardInfo += controllerSerialNumber;
    boardInfo += ",";
    boardInfo += webservestring;
    boardInfo += ",";
    boardInfo += FirmwareVersion;
    boardInfo += ",";
    boardInfo += hardwareVersion;
    boardInfo += ",";
    SerialUSB.println(boardInfo);
}
void PMMSendDeviceSettings()
{
    SerialUSB.println("Waiting");
    while (true)
    {
        if (SerialUSB.available() > 0)
        {
            String Settings = SerialUSB.readString();
            // TODO ","
            // PMMSplitString(Settings, DeviceName, Settings); // 0, || 34 || Remove Set Device Name
            PMMSplitString(Settings, TCPORRTU, Settings); // 0
            PMMSplitString(Settings, slaveId, Settings);  // ""

            PMMSplitString(Settings, controllerIPAddress, Settings); // 192.168.1.200
            PMMSplitString(Settings, subNetMask, Settings);          // 255.255.255.0
            PMMSplitString(Settings, DNS, Settings);                 // 8.8.8.8
            PMMSplitString(Settings, GatWay, Settings);              // 192.168.1.1
            PMMSplitString(Settings, remoteIPAddress, Settings);     // 192.168.1.5

            PMMSplitString(Settings, UDPPort, Settings);  // 91
            PMMSplitString(Settings, UDPPort2, Settings); //
            PMMSplitString(Settings, UDPPort3, Settings); //
            PMMSplitString(Settings, UDPPort4, Settings); //

            PMMSplitString(Settings, portOne.baudRate, Settings);  // 4
            PMMSplitString(Settings, portOne.dataBit, Settings);   // 0
            PMMSplitString(Settings, portOne.stopBit, Settings);   // 0
            PMMSplitString(Settings, portOne.parity, Settings);    // 0
            PMMSplitString(Settings, portOne.interface, Settings); // 0
            PMMSplitString(Settings, portTwo.baudRate, Settings);  // 4
            PMMSplitString(Settings, portTwo.dataBit, Settings);   //,0
            PMMSplitString(Settings, portTwo.stopBit, Settings);   //,0,
            PMMSplitString(Settings, portTwo.parity, Settings);    // 0
            PMMSplitString(Settings, portTwo.interface, Settings); //,0

            PMMSplitString(Settings, portThree.baudRate, Settings);  //,4,
            PMMSplitString(Settings, portThree.dataBit, Settings);   // 0,
            PMMSplitString(Settings, portThree.stopBit, Settings);   // 0,
            PMMSplitString(Settings, portThree.parity, Settings);    // 0
            PMMSplitString(Settings, portThree.interface, Settings); //,0

            PMMSplitString(Settings, portFour.baudRate, Settings);  //,4
            PMMSplitString(Settings, portFour.dataBit, Settings);   //,0,
            PMMSplitString(Settings, portFour.stopBit, Settings);   // 0
            PMMSplitString(Settings, portFour.parity, Settings);    //,0
            PMMSplitString(Settings, portFour.interface, Settings); //,0

            // Device Configuration
            PMMSplitString(Settings, MACAddressString, Settings);       // 5678
            PMMSplitString(Settings, controllerSerialNumber, Settings); //,1324
            PMMSplitString(Settings, webservestring, Settings);         //,0
            PMMSplitString(Settings, FirmwareVersion, Settings);        //,0
            PMMSplitString(Settings, hardwareVersion, Settings);        //,0

            setDefaultUDPSetting();
            setDefaultSerialMode();
            PMMSetModbusSeting();
            setDeviceSettings();
            // Reset Device
            NVIC_SystemReset();
            break;
        }
    }
}
void PMMSplitString(String parameter, String &returnVal, String &returnString)
{
    /**
     * getValueFormString : get the first string from many Split string separeted with ,
     * Note That whene we save string we add & to indicate the end of it
     * @param String parameter: the line of data saved inEEPROM
     * @param String returnVal: the first string in this data
     * @param String returnString: the rest of the passed string
     *
     */
    int index = parameter.indexOf(",");
    returnVal = parameter.substring(0, index);
    returnString = parameter.substring((returnVal.length()) + 1, (parameter.length()));
}
void PMMFactoryReset()
{
    writeEEPROM(1, 2);
    NVIC_SystemReset();
}