

#ifndef generalEEPROMFunction
#define generalEEPROMFunction
#include <Arduino.h>
#include <Wire.h>
#include <EthernetUdp.h>
#include <projectConfigration.h>
#include "SparkFun_External_EEPROM.h"
#include <PID_v1.h>

extern bool inDebugMode;
extern byte firstRunValue;

void cleanEEPROM();
bool isItFirstRun();
void markAsRead();
byte readEEPROM(unsigned int eeAddr);
void writeEEPROM(unsigned int eeAddr, byte data);
void initEEPROM();
String readStringEEPROM(int address, int numberOfChar);
int saveStringToEEprom(String toSave, int startFrom);
void getValueFormString(String parameter, String &returnVal,String &returnString);
void splitString(String parameter, String &returnVal, String &returnString);
void removeAndSignFromString(String &returnString);
String readJsonFromEEPROM(int address, int numberOfValue);

#endif
