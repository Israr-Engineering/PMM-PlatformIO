

#ifndef projectInitalization
#define projectInitalization

#include <Arduino.h>
#include <SPI.h>
#include <Ethernet.h>
#include <EthernetUdp.h>
#include <ArduinoJson.h>
#include <PMMIOLib/PMMIOLib.h>
#include <PMMAnalogSwitch/PMMAnalogSwitch.h>
#include <HC595.h>
#include <ArduinoRS485.h> // ArduinoModbus depends on the ArduinoRS485 library
#include <ArduinoModbus.h>
#include <ModbusMaster.h>
#include <Wire.h>
#include <projectConfigration.h>
#include <generalEEPROMFunction.h>
#include <PMMGlobalFunction.h>

#include <PMMWebController/PMMWebController.h>
#include <PMMTCPServer/PMMTCPServer.h>
#include <PMMModbusGateWay/PMMModbusGateWay.h>
#include <PMMEEPROMSerialParam/PMMEEPROMSerialParam.h>
#include <PMMUDPLib/PMMUDPLib.h>
#include <PID_v1.h>
#include <PMMEEPROMAuth/PMMEEPROMAuth.h>
#include <PMM1003DeviceLib/PMM1003DeviceLib.h>
#include <PMM1002DeviceLib/PMM1002DeviceLib.h>
#include <PMM0501DeviceLib/PMM0501DeviceLib.h>
#include <PMM0632DeviceLib/PMM0632DeviceLib.h>
#include <PMM0620DeviceLib/PMM0620DeviceLib.h>
#include <PMM0625TDeviceLib/PMM0625TDeviceLib.h>
#include <PMM0638DeviceLib/PMM0638DeviceLib.h>
#include <PMM0630DeviceLib/PMM0630DeviceLib.h>
#include <PMM0639DeviceLib/PMM0639DeviceLib.h>
#include <PMM0406DeviceLib/PMM0406DeviceLib.h>
#include <PMM0612DeviceLib/PMM0612DeviceLib.h>
#include <PMM0613DeviceLib/PMM0613DeviceLib.h>
#include <PMM1104DeviceLib/PMM1104DeviceLib.h>
#include <PMM1103DeviceLib/PMM1103MasterDevice/PMM1103MasterDevice.h>
#include <PMM1103DeviceLib/PMM1103SlaveDevice/PMM1103SlaveDevice.h>

#include <HC595.h>
#include <PMMEEPROMAi/PMMEEPROMAi.h>
#include <PMMEEPROMAO/PMMEEPROMAO.h>
#include <PMMEEPROMDeviceSettings/PMMEEPROMDeviceSettings.h>
#include <PMMEEPROMPID/PMMEEPROMPID.h>
#include <PMMWebServerOnEEPROM/PMMWebServerOnEEPROM.h>
#include <PMMEEPROMTrackerSettings/PMMEEPROMTrackerSettings.h>
void PMMGetSavedPrameter();
void initializeProject();

extern bool PMM0501Device;
extern bool PMM0501DeviceOnePort;
extern bool PMM1003Device;
extern bool PMM1002Device;
extern bool PMM6032Device;
extern bool PMM0620Device;
extern bool PMM0638Device;
extern bool PMM0625TDevice;
extern bool PMM0627Device;
extern bool PMM0630Device;
extern bool PMM0626RDevice;
extern bool PMM0639Device;
extern bool PMM0612Device;
extern bool PMM0613Device;
extern bool PMM1103Device;
extern bool PMM1103MasterDevice;
extern bool PMM1104Device;
extern bool PMM1103SlavDevice;

// Serial Parameter
extern SerialParameter portOne;
extern SerialParameter portTwo;
extern SerialParameter portThree;
extern SerialParameter portFour;
// Ethernet Parameter
extern String DNS;
extern String GatWay;
// Serial Port 


// UDP Parameter
extern String remoteIPAddress;
extern String UDPPort;
extern EthernetUDP Udp;
extern EthernetUDP Udp2;
extern EthernetUDP Udp3;
extern EthernetUDP Udp4;
extern EthernetUDP Udp5;
extern String ModelName;
extern int UDPPortInt;
extern bool bridgeOrModBus;
extern bool webPageConfugration;
extern bool modBusSlave;
extern bool modBusTCPSlave;
extern bool modBusRTUSlave;
// extern bool IODevice;
// extern String IOslaveid;




#endif