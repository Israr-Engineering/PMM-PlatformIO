#include <projectInitalization.h>
void initializeProject()
{
    PMM1003Device = false;
    PMM0620Device = false;
    PMM1002Device = false;
    PMM0501Device = false;
    bridgeOrModBus = false;
    PMM6032Device = false;
    PMM0625TDevice = false;
    PMM0626RDevice = false;
    PMM0638Device = false;
    PMM0630Device = false;
    PMM0639Device = false;
    PMM0406Device = false;
    PMM0612Device = false;
    PMM1103Device = false;
    PMM1103SlavDevice = true; // Firmware Purbose
    // Configure Pins First
    if (PMM1103SlavDevice)
        PMM1103SlaveIOInit();
    PMMGetSavedPrameter();
    // Configration Area
    if (PMM0501Device)
    {
        ModelName = "PMM 0501 Ethernet - Serial (TCP-RTU) converter";
        PMMInitalize0501();
    }
    else if (PMM1003Device)

    {
        ModelName = "PMM 1003 IO Mirror";
        PMMInitalize1003();
    }
    else if (PMM1002Device)
    {
        ModelName = "PMM 1002 IO Mirror";
        PMMInitalize1002();
    }
    else if (PMM6032Device)
    {
        ModelName = "PMM 0632 8XAI 12Bit";
        PMMInitalize0632();
    }
    else if (PMM0620Device)
    {
        ModelName = "PMM 0620 12x Digital Input";
        PMMInitalize0620();
    }
    else if (PMM0625TDevice || PMM0626RDevice || PMM0627Device)
    {
        if (PMM0625TDevice)
            ModelName = "PMM 0625 T 8x Digital Output";
        else if (PMM0626RDevice)
            ModelName = "PMM 0626 R 8x Digital Output";
        else if (PMM0627Device)
            ModelName = "PMM 0627 T 8x Digital Isolated AC Output (Triac 2A)";
        PMMInitalize0625T();
    }
    else if (PMM0638Device)
    {
        ModelName = "PMM 0638  8x  Analog IO";
        PMMInitalize0638();
    }
    else if (PMM0630Device)
    {
        ModelName = "PMM 0630 8x  Analog Input";
        PMMInitalize0630();
    }
    else if (PMM0639Device)
    {
        ModelName = "PMM 0639 4x  Analog Input & 4x DIO";
        PMMInitalize0639();
    }
    else if (PMM0406Device)
    {
        ModelName = "PMM 0406 Ethernet - Serial (TCP-RTU) converter";
        PMMInitalize0406();
    }
    else if (PMM0612Device)
    {
        ModelName = "PMM 0612 Ethernet/Fiber - Serial converter";
        PMMInitalize0612();
    }
    else if (PMM0613Device)
    {
        ModelName = "PMM 0613 PID Converter";
        PMMInitalize0613();
    }
    else if (PMM1104Device)
    {
        ModelName = "PMM 1104 Zero Export";
        PMMInitalize1104();
    }
    else if (PMM1103MasterDevice)
        PMMInitalize1103Master();
    else if (PMM1103SlavDevice)
        PMMInitalize1103Slave();
    Debugprintln("Out From Project Init");
}
// get Saved Data From EEPROM
void PMMGetSavedPrameter()
{
    /**
     * @brief Get All Saved Parameter on the EEPROM
     */
    SerialUSB.begin(9600); // Initalize USB For Debug
    Debugprintln("Start Project Init ...");
    projectParamConfigtaion(); // get default Project parameter
    Debugprintln("Start EEPROM INIT ...");
    initEEPROM();

    Debugprintln("..."); // Initalize EEPROM
    // Check if its saved before+
    SerialUSB.println(isItFirstRun());
    if (isItFirstRun())
    {
        cleanEEPROM();          // Clean EEPROM
        markAsRead();           // Only For Testing
        setDefaultUDPSetting(); // get Default Network Info
        setDefaultSerialMode(); // get Default Serial Port
        setPasswordInEEPROM();  // Save Password
        PMMSetModbusSeting();   // Modbus Settings
        setAiInfo();
        setAOInfo();
        setDeviceSettings();
        PMMSetPidInfo();
        PMMWebPageSetHeaderTag();
        PMMWebPageSetFooter();
        PMMWebPageSetLogin();
        PMMWebPageSetAbout();
        // PMMSetTrackerInfo();
        PMMSetMasterTrackerInfo();
    }
    else
    {
        getUDPSetting();
        getSerialSettingFromEEPROM();
        returnSavedPasswordInEEPROM();
        PMMgetModBusSetting();
        getAiInfo();
        getAOInfo();
        PMMGetPidInfo();
        PMMGetMasterTrackerInfo();
        // PMMGetTrackerInfo();
        getDeviceSettings();
    }
    Debugprintln("..."); // Initaliz
    webPageConfugration = webservestring == "1" ? true : false;
}
