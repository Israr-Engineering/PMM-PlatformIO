/**
 * @file projectConfigration.cpp
 * @author Ahmad Joghaimi
 * @brief This File Will containe the Basic Info and the Initalization of the project
 * @version 0.1
 * @date 2022-01-17
 *
 * @copyright Copyright (c) 2022
 *
 */
#include <projectConfigration.h>

// ====> Ethernet Port
String controllerIPAddress;
String subNetMask;
String DNS;
String GatWay;
String remoteIPAddress;
String UDPPort;
String UDPPort2;
String UDPPort3;
String UDPPort4;
String MACAddressString = "2525252501";
String controllerSerialNumber = "062012010801";
String password = "12344321";
String ModelName = "PMM 0625 Digital Output";
String FirmwareVersion = "1.0";
String hardwareVersion = "1.0";
String webservestring = "1";

int UDPPortInt;
// SerialParameter {Always Decleare Four Serial Port}
byte numberOfSerial = 2;
struct SerialParameter portOne;
struct SerialParameter portTwo;
struct SerialParameter portThree;
struct SerialParameter portFour;
// Configure Ai
struct AI aiArray[8];
struct AO aoArray[4];
uint16_t modbusAO[8];
struct PIDArray pidArray[4];
// IO
struct modBusCoils PMMInputCoilModbus;
struct modBusCoils PMMOutputCoilModbus;
struct modBusHolding PMMInputHolding;
struct modBusHolding PMMOutputHolding;
struct AD7441 PMMAD7441;

// Configration and Modes
bool inDebugMode = true;
// Device Configration
bool PMM0501Device = false;
bool PMM0501DeviceOnePort = false;
bool PMM0406Device = false;
bool PMM1003Device = false;
bool PMM6032Device = false;
bool PMM0620Device = false;
bool PMM0625TDevice = false;
bool PMM0626RDevice = false;
bool PMM0627Device = false;
bool PMM1002Device = false;
bool PMM0638Device = false;
bool PMM0630Device = false;
bool PMM0639Device = true;
bool PMM0612Device = false;
bool PMM0613Device = false;
bool PMM1103Device = false;
bool PMM1103MasterDevice = false;
bool PMM1103SlavDevice = false;
bool PMM1104Device = false;
String DeviceName = "16"; // Set As
// UDP Configration
EthernetUDP Udp;
EthernetUDP Udp2;
EthernetUDP Udp3;
EthernetUDP Udp4;
EthernetUDP Udp5;
// ModBus Configration
String ModbusOrUDP;
String TCPORRTU;
String slaveId = "1";
String ReadCoilsStartAddress;
String ReadCoilsQuintity;
String WriteCoilsStartAddress;
String WriteCoilsQuintity;
String ReadHoldingRegStartAddress;
String ReadHoldingRegQuintity;
String WriteHoldingRegStartAddress;
String WriteHoldingRegQuintity;
String inputRegisterStartAddress;
String inputRegisterQuintity;
// Sel operation
String selOperation;
// IF WebBage is enabled the Value is true
bool webPageConfugration = true;
// True for Bridge , False For ModBus || The value get from Webpages and EEPROM
bool bridgeOrModBus = true;
// ModBus Slave {True to enable device as ModBus Slave}
bool modBusSlave = true;
// ModBus Slave RTU {True to enable device as ModBus RTU Slave}
bool modBusRTUSlave = false;
// ModBus Slave TCP {True to enable device as ModBus TCP Slave}
bool modBusTCPSlave = true;
// Init AS IO Device

byte firstRunValue = 1; // Change it to clean the EEPROM in the next run
byte mac[] = {0x25, 0x25, 0x25, 0x25, 0x25, 0x51};
uint8_t EthernetCS = 10;
uint8_t resetButton = 20;
// ModBus Bridge Configration
String enableModBus;
String readCoilAdd;
String ReadCoilQuint;
String ReadHoldingAdd;
String ReadHoldingQuint;
String WriteCoilQuint;
String WriteCoilAdd;
String WriteHoldingAdd;
String WritHoldingQuint;
uint8_t NumOfCoils;

// Tracker Settings
// Master Tracker
float xAxisCalibration, yAxisCalibration, zAxisCalibration = 0;
float PMM1103RequiredMasterx, PMM1103RequiredMastery, PMM1103RequiredMasterz;
float PMM1103TollerentMasterx, PMM1103TollerentMastery, PMM1103TollerentMasterz;
int PMM1103MasterlostCommunicationTime = 5, PMM1103ModeType = 1;
float PMMMPUOldReadingValuex, PMMMPUOldReadingValuey, PMMMPUOldReadingValuez;
float PMM1103MaxLimitSwitchDegree, PMM1103MinLimitSwitchDegree, PMM1103MaxDegree, PMM1103MinDegree;
float PMM1103TimeZone, PMM1103Longitude, PMM1103HRA, PMM1103Latitude, PMM1103TrueAngel;
int PMM1103LostCommunicationDay = 0;
int PMM1103SunSet = 0;
int PMM1103SunRise = 0;

void projectParamConfigtaion()
{
    /**
     * This Values are the values that saved in the EEPROM at First Run
     **/
    // Get Parameter That Saved Deep inside The EEPROM

    /// UDP Setting
    controllerIPAddress = "192.168.1.200";
    subNetMask = "255.255.255.0";
    DNS = "8.8.8.8";
    GatWay = "192.168.1.1";
    remoteIPAddress = "192.168.1.5";
    UDPPort = "91";
    UDPPort2 = "92";
    UDPPort3 = "93";
    UDPPort4 = "94";
    /// Serial Setting
    portOne.baudRate = "4";
    portOne.dataBit = "0";
    portOne.stopBit = "0";
    portOne.parity = "0";
    portOne.interface = "0";

    portTwo.baudRate = "4";
    portTwo.dataBit = "0";
    portTwo.stopBit = "0";
    portTwo.parity = "0";
    portTwo.interface = "0";

    portThree.baudRate = "4";
    portThree.dataBit = "0";
    portThree.stopBit = "0";
    portThree.parity = "0";
    portThree.interface = "0";

    portFour.baudRate = "4";
    portFour.dataBit = "0";
    portFour.stopBit = "0";
    portFour.parity = "0";
    portFour.interface = "0";

    pinMode(resetButton, OUTPUT);
    /// ModBus Configration
    enableModBus = "1"; // 0 :Enable , 1: Disable
    readCoilAdd = "0";
    ReadCoilQuint = "12";
    ReadHoldingAdd = "0";
    ReadHoldingQuint = "0";
    WriteCoilAdd = "0";
    WriteCoilQuint = "12";
    WriteHoldingAdd = "0";
    WritHoldingQuint = "0";
    // IO Configration
    // IOslaveid = "1";
    // IOType = "0"; // 0 TCPIO , 1 RTU IO
    selOperation = "SerialMirror";
    // Configure Default Ai
    for (uint8_t i = 0; i < 8; i++)
    {
        aiArray[i].canBeNegative = false;
        aiArray[i].factorValue = 1;
        aiArray[i].offset = 0;
        aiArray[i].FX = 1;
        aiArray[i].OX = 1;
    }
    TCPORRTU = "0";
    ModbusOrUDP = "0";
}
