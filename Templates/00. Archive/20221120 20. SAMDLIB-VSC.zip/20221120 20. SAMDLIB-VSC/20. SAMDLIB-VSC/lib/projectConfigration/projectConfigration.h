#ifndef projectConfigration
#define projectConfigration
#include <Arduino.h>
#include <Ethernet.h>
#include <EthernetUdp.h>
#include <PID_v1.h>
// #include <HC595.h>

typedef struct SerialParameter
{
    String baudRate;
    String dataBit;
    String stopBit;
    String parity;
    String interface;
} SerialParameter;

typedef struct AnalogSwitch
{
    uint8_t inputCount;
    uint8_t dataPin;
    uint8_t S0;
    uint8_t S1;
    uint8_t S2;
    uint8_t S3;
} AnalogSwitch;
typedef struct Multiplexer
{
    uint8_t SERIn;
    uint8_t RCLK;
    uint8_t SRCLK;
    uint8_t SRCLKInv;
    uint8_t numberOfOutput;
    uint8_t numberOfChip;
} Multiplexer;

typedef struct modBusCoils
{
    int startAddress;
    uint8_t quentity;
    uint8_t read;
    uint8_t write;
    bool *forcedArray;
    bool *forcedValue;
    bool *boolArrayCurrent;
    bool *boolArray;
} modBusCoils;

typedef struct modBusHolding
{
    int startAddress;
    uint8_t quentity;
    uint8_t read;
    uint8_t write;
    word *outputValue;
    bool configMode = false;
    struct AI *holingArray;

} modBusHolding;
typedef struct AD7441
{
    uint8_t cs;
    uint8_t alertFlage;
    uint8_t rst;
    uint8_t EthCS;
    uint8_t ready;

} AD7441;

typedef struct AO
{
    bool isVoltage = 0;
    bool forced = false;

    uint16_t valueOnADC;
    union
    {
        float valueAsFloat;
        uint16_t valueAsInt[2];
    } floatToInt;
} AO;

typedef struct AI
{

    uint32_t analogValues[30];
    uint8_t numberOfreading = 0;
    uint32_t total = 0;
    float offset = 0;
    float factorValue = 1;
    uint8_t pinNumber;
    bool canBeNegative;
    bool equationType;
    uint16_t FX;
    uint16_t OX;
    union
    {
        float valueAsFloat;
        int32_t valueAsLong;
        uint16_t valueAsInt[2];
    } floatToInt;
} AI;

typedef struct PIDArray
{

    double setPoint = 0;
    double ki = 0;
    double kp = 0;
    double kd = 0;
    double minOutput = 0;
    double maxOutput = 0;
    double input = 0;
    double output = 0;
    PID obj;
} PIDArray;
void projectParamConfigtaion();
#endif