#ifndef PMM0406DeviceLib
#define PMM0406DeviceLib
#include <Arduino.h>
#include <projectConfigration.h>
#include <PMMWebController/PMMWebController.h>
#include <PMMTCPServer/PMMTCPServer.h>
#include <PMMRTUSlave/modbusRTUWrappper.h>
#include <PMMModbusGateWay/PMMModbusGateWay.h>
#include <PMMEEPROMSerialParam/PMMEEPROMSerialParam.h>
#include <PMMUDPLib/PMMUDPLib.h>
#include <PMMEEPROMAuth/PMMEEPROMAuth.h>
#include <PMMUDPBridge/PMMUDPBridge.h>
#include "wiring_private.h"

extern bool webPageConfugration;
extern SerialParameter portOne;
extern SerialParameter portTwo;
// UDP Parameter
extern String remoteIPAddress;
extern String UDPPort;
extern EthernetUDP Udp;
extern EthernetUDP Udp2;
extern bool bridgeOrModBus;
extern Uart Serial2;
extern uint8_t EthernetCS ;
void PMMInitalize0406();
void PMM0406Loop();



#endif