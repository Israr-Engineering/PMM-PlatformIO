#include <PMM0406DeviceLib/PMM0406DeviceLib.h>
// Uart Serial2(&sercom1, 11, 10, SERCOM_RX_PAD_0, UART_TX_PAD_2);
void PMMInitalize0406()
{
    // Seial Configration
    Debugprintln("0406 Device");
    bridgeOrModBus = ModbusOrUDP == "0" ? true : false;
    // Initalize Ethernet
    EthernetCS = 6;
    initalizeEthernet();
    // Initalize WebServer
    // if (webPageConfugration)
    // PMMInitWebServer();
    // Initalize Serial Port
    initialSerialPort(Serial2, portOne.baudRate, portOne.dataBit, portOne.parity, portOne.stopBit, portOne.interface);
    initialSerialPort(Serial, portTwo.baudRate, portTwo.dataBit, portTwo.parity, portTwo.stopBit, portTwo.interface);

    initialSerialPort(Serial1, portThree.baudRate, portThree.dataBit, portThree.parity, portThree.stopBit, portThree.interface);
    initialSerialPort(Serial3, portFour.baudRate, portFour.dataBit, portFour.parity, portFour.stopBit, portFour.interface);

    // ============= COM2
    pinPeripheral(10, PIO_SERCOM);
    pinPeripheral(11, PIO_SERCOM);
    // ============= COM3
    pinPeripheral(3, PIO_SERCOM_ALT);
    pinPeripheral(4, PIO_SERCOM_ALT);
    // Bridge Mode Or Converter
    // if (bridgeOrModBus)
    // {
    //     PMMGateWayinitalize();
    //     Debugprintln("ModBus Bridge Mode");
    // }
    // else
    // {
    PMMUDPInit(Udp, 91);  // UDP Port 1
    PMMUDPInit(Udp2, 92); // UDP Port 2
    PMMUDPInit(Udp3, 93); // UDP Port 2
    PMMUDPInit(Udp4, 94); // UDP Port 2
    Debugprintln("UDP Bridge Mode");
    // }
}
void PMM0406Loop()
{
    // if (bridgeOrModBus)
    // PMMGateWayLoop();
    // else
    PMMUDPLoop();
}
