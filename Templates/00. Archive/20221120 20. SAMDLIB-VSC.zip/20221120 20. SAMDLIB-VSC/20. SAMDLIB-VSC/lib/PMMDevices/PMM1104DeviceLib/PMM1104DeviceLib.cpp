#include <PMM1104DeviceLib/PMM1104DeviceLib.h>
ModbusMaster RTUMasterOne;
ModbusMaster RTUMasterTwo;
// Inverter Values
byte powerAnalyserId = 1;
int PowerAnalyserConsumptionPower = 1;
// Inverter Values
byte InverterId = 1;

union
{
    float valueAsFloat;
    uint16_t valueAsInt[2];
} floatToInt;


void PMMInitalize1104()
{
    initalizeEthernet();
    // Initalize WebServer
    if (webPageConfugration)
        PMMInitWebServer();
    // Initalize Serial Port
    initialSerialPort(Serial, portOne.baudRate, portOne.dataBit, portOne.parity, portOne.stopBit, portOne.interface);
    initialSerialPort(Serial1, portTwo.baudRate, portTwo.dataBit, portTwo.parity, portTwo.stopBit, portTwo.interface);
    // Initalize Modbus MAster
}
void PMMLoop1104()
{
    // Read Power Analyser
    RTUMasterOne.begin(powerAnalyserId, Serial); // Checked || Confirned
    uint8_t resposneCode = RTUMasterOne.readHoldingRegisters(PowerAnalyserConsumptionPower, 2);
    if (resposneCode == 0)
    {
        // Get the Value form Power
        floatToInt.valueAsInt[0] = RTUMasterOne.getResponseBuffer(0);
        floatToInt.valueAsInt[1] = RTUMasterOne.getResponseBuffer(1);
        // Convert to Readable Value
    }
    // Check the Power info

    
    // Update Inverter Info
}