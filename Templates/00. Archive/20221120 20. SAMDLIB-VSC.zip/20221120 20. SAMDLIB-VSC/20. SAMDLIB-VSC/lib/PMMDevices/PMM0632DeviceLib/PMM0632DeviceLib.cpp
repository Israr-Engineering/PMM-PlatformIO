#include <PMM0632DeviceLib/PMM0632DeviceLib.h>
extern struct AI aiArray[8];
uint16_t outputConfigrationArray[16];
String deviceModbusType = "RTUSlave";
struct modBusCoils inputCoilModbus0632;
struct modBusCoils outputCoilModbus0632;
struct modBusHolding inputHolding0632;
struct modBusHolding outputHolding0632;

void PMMInitalize0632()
{
    Debugprintln("0632 Device");
    // Configure Ai Pins
    // Configure more Ai Source ::https://forum.arduino.cc/t/arduino-zero-additional-analog-inputs/350356/5
    aiArray[0].pinNumber = A1;
    aiArray[1].pinNumber = A2;
    aiArray[2].pinNumber = A3;
    aiArray[3].pinNumber = A4;
    // aiArray[4].pinNumber = A6;
    // aiArray[5].pinNumber = A7;
    // aiArray[6].pinNumber = A8;
    // aiArray[7].pinNumber = A9;
    analogReference(AR_EXTERNAL);

    // Anitalize Ai
    for (uint8_t i = 0; i < 8; i++)
        // clear analogValues arrays
        memset(aiArray[i].analogValues, 0, 10 * sizeof(int16_t));
    // Init holding reg
    inputHolding0632.holingArray = aiArray;
    inputHolding0632.startAddress = ReadHoldingRegStartAddress.toInt();
    inputHolding0632.quentity = 16;
    inputHolding0632.read = true;
    inputHolding0632.write = false;

    // Output holding reg
    outputHolding0632.outputValue = outputConfigrationArray;
    outputHolding0632.startAddress = ReadHoldingRegStartAddress.toInt();
    outputHolding0632.quentity = 16;
    outputHolding0632.read = false;
    outputHolding0632.write = true;
    outputHolding0632.configMode = true;
    initalizeEthernet();
    // Initalize WebServer
    if (webPageConfugration)
        PMMInitWebServer();
    initialSerialPort(Serial, portOne.baudRate, portOne.dataBit, portOne.parity, portOne.stopBit, portOne.interface);
    SerialUSB.println();
    // 0 => TCP Slave , 1 => RTU Slave
    // Start in TCP Testing

    if (TCPORRTU == "0")
    { // TCP Slave
        initModBusTCP(slaveId.toInt());
        PMMInitRegister(slaveId.toInt(), 3, ReadHoldingRegStartAddress.toInt(), 16);
    }
    else if (TCPORRTU == "1")
    {
        Debugprintln("RTUSlave");                              // RTU Slave
        PMMRTUSlaveStartConfig(Serial, 9600, slaveId.toInt()); // Other Serial info is set on line 37
        PMMInitRTUSlaveRegister(slaveId.toInt(), 3, ReadHoldingRegStartAddress.toInt(), 16);
    }
}

void PMM0632Loop()
{

    analogReadCalibratoin(aiArray, 8);
    // analogReadSettings(aiArray, outputConfigrationArray);
    if (TCPORRTU == "0") // TCP Slave
        PMMTCPSlaveLoop(slaveId.toInt(), outputCoilModbus0632, inputCoilModbus0632, outputHolding0632, inputHolding0632);
    else if (TCPORRTU == "1") // RTU Slave
        PMMRTUSlaveLoop(slaveId.toInt(), outputCoilModbus0632, inputCoilModbus0632, outputHolding0632, inputHolding0632);
}

void analogReadSettings(struct AI *ai, uint16_t *configrationArray)
{
    union
    {
        float valueAsFloat;
        uint16_t valueAsInt[2];
    } floatToInt;
    floatToInt.valueAsInt[0] = configrationArray[32];
    floatToInt.valueAsInt[1] = configrationArray[33];
    if (floatToInt.valueAsFloat == 1)
    {
        SerialUSB.println("Configured");
    }
}
void analogReadCalibratoin(struct AI *ai, uint8_t quentity)
{
    for (uint8_t i = 0; i < quentity; i++)
    {
        // sub last reading
        ai[i].total = ai[i].total - ai[i].analogValues[ai[i].numberOfreading];
        // Read new value
        // specifay resolution
        analogReadResolution(12);
        ai[i].analogValues[ai[i].numberOfreading] = analogRead(ai[i].pinNumber);
        // add it to the total
        ai[i].total += ai[i].analogValues[ai[i].numberOfreading];
        ai[i].numberOfreading++;
        if (ai[i].numberOfreading >= 30)
            ai[i].numberOfreading = 0;
        // Analog Value
        ai[i].floatToInt.valueAsFloat = ai[i].total / 30.0;
        if (!ai[i].equationType)
            ai[i].floatToInt.valueAsFloat = (ai[i].floatToInt.valueAsFloat * (ai[i].factorValue) / ai[i].FX) - ai[i].offset / ai[i].OX;
        else
            ai[i].floatToInt.valueAsFloat = (ai[i].floatToInt.valueAsFloat - (ai[i].offset / ai[i].FX)) * ai[i].factorValue / ai[i].OX;

        if (ai[i].floatToInt.valueAsFloat < 0 && !ai[i].canBeNegative)
            ai[i].floatToInt.valueAsFloat = 0;
        delay(1);
    }
}
