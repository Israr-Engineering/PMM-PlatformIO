#ifndef PMM0632DeviceLib
#define PMM0632DeviceLib
#include <Arduino.h>
#include <projectConfigration.h>
#include <PMMWebController/PMMWebController.h>
#include <PMMTCPServer/PMMTCPServer.h>
#include <PMMRTUSlave/modbusRTUWrappper.h>
#include <PMMModbusGateWay/PMMModbusGateWay.h>
#include <PMMEEPROMSerialParam/PMMEEPROMSerialParam.h>
#include <PMMUDPLib/PMMUDPLib.h>
#include <PMMEEPROMAuth/PMMEEPROMAuth.h>
void PMMInitalize0632();
void PMM0632Loop();
void analogReadCalibratoin(struct AI *ai, uint8_t quentity);
void analogReadSettings(struct AI *ai, uint16_t *configrationArray);
extern bool webPageConfugration;
extern String slaveId;
extern String ReadHoldingRegStartAddress;
extern String ReadHoldingRegQuintity;
#endif