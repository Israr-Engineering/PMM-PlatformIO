#ifndef PMM1103SlaveMovment
#define PMM1103SlaveMovment
#include <Arduino.h>
#include <projectConfigration.h>
#include <SPI.h>
#include <PMMEEPROMSerialParam/PMMEEPROMSerialParam.h>
#include <PMMEEPROMAuth/PMMEEPROMAuth.h>
#include <PMMEEPROMTrackerSettings/PMMEEPROMTrackerSettings.h>
#include <../PMMFlash/PMMFlashGeneralFunction/PMMFlashGeneralFunction.h>
#include <SparkFun SPI SerialFlash Arduino Library/src/SparkFun_SPI_SerialFlash.h>
#include <../PMMPeripherals/PMMBNO055/PMMBNO055.h>
#include <../PMMPeripherals/PMMMPU6050/PMMMPU6050.h>
#include <../PMMPeripherals/PMMRTC/PMMRTC.h>
#include <../PMMPeripherals/PMMLora/PMMLora.h>
#include <LoRa.h>
#include <ArduinoRS485.h> // ArduinoModbus depends on the ArduinoRS485 library
#include <ArduinoModbus.h>
#include <PMM1103DeviceLib/PMM1103SlaveDevice/PMM1103SlaveVariable/PMM1103SlaveVariable.h>

// --- IO Pinout
extern byte PMM1103SlaveRelayOne;
extern byte PMM1103SlaveRelayTwo;
extern byte PMM1103SlaveSerialOneSelect;
extern byte PMM1103SlaveSerialTwoSelect;
extern byte PMM1103SlaveSensorInterruptPins;
// byte OrderWestBtn = A3;
extern byte PMM1103SlaveFeadBackBtn;
extern byte PMM1103SlavefanControl;
extern byte PMM1103SlavelossOfPower;
extern byte PMM1103SlaveautoManual;
extern byte PMM1103SlaveFeedbackPin;
// Lora
extern byte PMM1103SlaveloraCS;
extern byte PMM1103SlaveloraRST;
extern byte PMM1103SlaveOrderWest;
extern byte PMM1103SlaveOrderEast;
extern int PMM1103Slavecounter;
// Flash
extern byte PMM1103SlaveFlashCS;
extern bool PMM1103SlaveAutoManual;
extern struct AI PMM1103SlaveAiArray1103[8];
extern float PMM1103Slavex, PMM1103Slavey, PMM1103Slavez;
extern byte PMM1103SlaveautoManualPin;
extern bool PMM1103Reached;
extern int PMM1103LostCommunicationDay;
void PMM1103SlaveIOInit();
void PMMInputLoop1103Slave();
// West Movment
void PMMPositining1103SlaveStartWestMovment();
void PMMPositining1103SlaveStopWestMovment();
// East Movment
void PMMPositining1103SlaveStartEastMovment();
void PMMPositining1103SlaveStopEastMovment();
void PMMUpdatePostiotn1103Slave();
void PMMAutoPositining1103Slave();
void PMMManualPositining1103Slave();
void PMMAutoStall1103Slave();
void PMMStopTracking();
void PMMAutoCalculatedAngel(float HRA);
#endif
