// #include <PMM1103DeviceLib/PMM1103MasterDevice/PMM1103MasterModbus/PMM1103MasterModbus.h>

// void PMMInitModbusRTU1103Master()
// {
//     // Init Serial Settings
//     // initialSerialPort(Serial, portOne.baudRate, portOne.dataBit, portOne.parity, portOne.stopBit, portOne.interface);
//     Serial1.begin(9600);
//     // Initalize Master Device
//     PMMRTUMasterStartConfig(Serial1, 9600, 1, PMM1103MasterSerialTwoSelect); // Other Serial info is set on line 37
//     PMMInitRTUMasterRegister(1, 3, 4000, 50);

//     // Init holding reg
//     PMM1103MasterInputHolding.holingArray = PMM1103MasterAiArray1103;
//     PMM1103MasterInputHolding.startAddress = 4000;
//     PMM1103MasterInputHolding.quentity = 16;
//     PMM1103MasterInputHolding.read = true;
//     PMM1103MasterInputHolding.write = false;
//     // Output holding reg
//     PMM1103MasterOutputHolding.outputValue = PMM1103MasterOutputConfigrationArray;
//     PMM1103MasterOutputHolding.startAddress = 4016;
//     PMM1103MasterOutputHolding.quentity = 30;
//     PMM1103MasterOutputHolding.read = false;
//     PMM1103MasterOutputHolding.write = true;
//     PMM1103MasterOutputHolding.configMode = true;
// }
// void PMMModbusRTU1103Master(){
    

// }
