#include <PMM1103DeviceLib/PMM1103MasterDevice/PMM1103MasterDevice.h>



/**
 * @ToDo
 *
 *   - Enable PowerLoss
 *   - Solve Reset Problem
 */

bool PMM1103MasterAutoManual = true; // Test Purpose
int PMM1103MasterTimeInUTC;
bool lastMovment = false; // False : West , True : East {Get the Value From EEPROM}
int lastTimeRequested = 0;
void PMMInitalize1103Master()
{
    SerialUSB.begin(9600);
    ModelName = "PMM 1103 Master Tracker";
    Debugprintln("1103 Master Device");
    PMMInitIO1103Master();
    PMMInitModbusRTU1103Master();
    PMMInitRTC();
    // Start MPU
    PMMMBNO055Setup(PMM1103MasterSensorInterruptPins);
    // At startting Turn All Relay Off
    PMMPositining1103MasterStopEastMovment();
    PMMPositining1103MasterStopWestMovment();
    // Full Modbus Array From EEPROM
    lastTimeRequested = millis(); 
    // === Interrupt
    // attachInterrupt(PMM1103MasterlossOfPower, PMMAlarmIO1103Master, LOW);
}

void PMM1103MasterLoop()
{
    PMMInputLoop1103Master();
    PMMUpdatePostiotn1103Master();
    bool modbusCommunicateOk = PMMRTUSlaveLoop(1, PMM1103MasterOnputCoilModbus, PMM1103MasterOnputCoilModbus, PMM1103MasterOutputHolding, PMM1103MasterInputHolding, true);
    if (modbusCommunicateOk)
    {
        // Get Settings
        PMM1103MasterSaveSettings();
        // Reset Timer
        lastTimeRequested = millis();
    }
    if (PMM1103MasterAutoManual)
    {
        // => It Has Two Option ->> Has Communication , Has No Communication
        // Adjust the value to Do what it have to
        if (lastTimeRequested + PMM1103MasterlostCommunicationTime < millis())
            PMMAutoPositining1103Master();
        // else // Auto Nogataitions
            
    }
    else
    {
        // Manual Naguation -> Get the Command From the IO
        SerialUSB.print("*");
    }
    delay(1000);
}

// ****************** SetUP Functions
// =====  @brief Init IO For Master Tracker
void PMMInitIO1103Master()
{
    Debugprintln("Init IO ..");
    // === Output
    pinMode(PMM1103MasterSerialOneSelect, OUTPUT);
    pinMode(PMM1103MasterSerialTwoSelect, OUTPUT);
    pinMode(PMM1103MasterRelayTwo, OUTPUT);
    pinMode(PMM1103MasterRelayOne, OUTPUT);
    pinMode(PMM1103MasterfanControl, OUTPUT);
    // === Serial Enable Output
    digitalWrite(PMM1103MasterSerialOneSelect, HIGH);
    digitalWrite(PMM1103MasterSerialTwoSelect, HIGH);
    // === Input
    pinMode(PMM1103MasterautoManual, INPUT_PULLUP);
    pinMode(PMM1103MasterFeedbackPin, INPUT_PULLUP);
}
// =====  @brief Init Modbus RTU Settings
void PMMInitModbusRTU1103Master()
{
    // Init Serial Settings
    // initialSerialPort(Serial, portOne.baudRate, portOne.dataBit, portOne.parity, portOne.stopBit, portOne.interface);
    Serial1.begin(9600);
    // Initalize Slave Device
    PMMRTUSlaveStartConfig(Serial1, 9600, 1, PMM1103MasterSerialTwoSelect); // Other Serial info is set on line 37
    PMMInitRTUSlaveRegister(1, 3, 4000, 50);

    // Init holding reg
    PMM1103MasterInputHolding.holingArray = PMM1103MasterAiArray1103;
    PMM1103MasterInputHolding.startAddress = 4000;
    PMM1103MasterInputHolding.quentity = 16;
    PMM1103MasterInputHolding.read = true;
    PMM1103MasterInputHolding.write = false;
    // Output holding reg
    PMM1103MasterOutputHolding.outputValue = PMM1103MasterOutputConfigrationArray;
    PMM1103MasterOutputHolding.startAddress = 4016;
    PMM1103MasterOutputHolding.quentity = 30;
    PMM1103MasterOutputHolding.read = false;
    PMM1103MasterOutputHolding.write = true;
    PMM1103MasterOutputHolding.configMode = true;
}
// ****************** LOOP Functions
void PMMAutoPositining1103Master()
{
    // Does It Worth Moving ?
    bool shouldNotMove = int(PMM1103RequiredMastery) + int(PMM1103TollerentMastery) >= (PMM1103Mastery) && int(PMM1103RequiredMastery) - int(PMM1103TollerentMastery) <= (PMM1103Mastery);
    // SerialUSB.println(PMM1103Mastery);
    if (!shouldNotMove)
    {
        // Check The Y Axis Only
        if (PMM1103FloatToFloat(PMM1103RequiredMastery) > PMM1103FloatToFloat(PMM1103Mastery))
        {
            // Move West
            PMMPositining1103MasterStartWestMovment();
        }
        else if (PMM1103FloatToFloat(PMM1103RequiredMastery) < PMM1103FloatToFloat(PMM1103Mastery))
        {
            // Move East
            PMMPositining1103MasterStartEastMovment();
        }
    }
    else
    {
        // Stop All Of It
        PMMPositining1103MasterStopEastMovment();
        PMMPositining1103MasterStopWestMovment();
    }
}
void PMMPositining1103MasterStartWestMovment()
{
    // Check if FeedBack Is Reached
    bool canMoveWest = (digitalRead(PMM1103MasterFeedbackPin)) ? true : lastMovment;

    // Stop East Movment
    PMMPositining1103MasterStopEastMovment();
    if (canMoveWest)
    {
        digitalWrite(PMM1103MasterRelayOne, HIGH);
        // Debugprintln("Move West");
        lastMovment = false; // Set false to specifiay that the last movemaent was west
    }
    else
    {
        PMMPositining1103MasterStopWestMovment(); // Stop Movment
        Debugprintln("Error !!");
    }
}
void PMMPositining1103MasterStopWestMovment()
{
    digitalWrite(PMM1103MasterRelayOne, LOW);
}
void PMMPositining1103MasterStartEastMovment()
{
    // Check if FeedBack Is Reached
    bool canMoveEast = (digitalRead(PMM1103MasterFeedbackPin)) ? true : !lastMovment;

    // Stop East
    PMMPositining1103MasterStopWestMovment();
    if (canMoveEast)
    {
        lastMovment = true; // Set true to specifiay that the last movemaent was East
        digitalWrite(PMM1103MasterRelayTwo, HIGH);
        // Debugprintln("Move East");
    }
    else
    {
        PMMPositining1103MasterStopEastMovment();
        Debugprintln("Error !!");
    }
}
void PMMPositining1103MasterStopEastMovment()
{
    // Debugprintln("StopMovment East");
    digitalWrite(PMM1103MasterRelayTwo, LOW);
}

void PMM1103MasterSaveSettings()
{
    // Modbus Addresses ==>>> 4018 -8 // Data Type Is Float
    // Get Required Position
    bool saveDirectionSettings = PMM1103intToFloat(PMM1103MasterOutputConfigrationArray[8], PMM1103MasterOutputConfigrationArray[9]) == 1;
    if (saveDirectionSettings) // 4018 - 8
    {
        Debugprintln("Save Direction");
        PMM1103RequiredMasterx = PMM1103intToFloat(PMM1103MasterOutputConfigrationArray[2], PMM1103MasterOutputConfigrationArray[3]);
        PMM1103RequiredMastery = PMM1103intToFloat(PMM1103MasterOutputConfigrationArray[4], PMM1103MasterOutputConfigrationArray[5]);
        PMM1103RequiredMasterz = PMM1103intToFloat(PMM1103MasterOutputConfigrationArray[6], PMM1103MasterOutputConfigrationArray[7]);
        // Save The Settings In EEPROM
        PMMSetMasterTrackerInfo();
    }
    // Modbus Addresses ==>>> 4026 -8 // Data Type Is Float
    // Tolerant
    bool saveTolerantDirectionSettings = PMM1103intToFloat(PMM1103MasterOutputConfigrationArray[16], PMM1103MasterOutputConfigrationArray[17]) == 1;
    if (saveTolerantDirectionSettings) // 4026 - 8
    {
        Debugprintln("Save Tolerant Direction");
        PMM1103TollerentMasterx = PMM1103intToFloat(PMM1103MasterOutputConfigrationArray[10], PMM1103MasterOutputConfigrationArray[11]);
        PMM1103TollerentMastery = PMM1103intToFloat(PMM1103MasterOutputConfigrationArray[12], PMM1103MasterOutputConfigrationArray[13]);
        PMM1103TollerentMasterz = PMM1103intToFloat(PMM1103MasterOutputConfigrationArray[14], PMM1103MasterOutputConfigrationArray[15]);
        // Save The Settings In EEPROM || TODO
        PMMSetMasterTrackerInfo();
    }
    // Modbus Addresses ==>>> 4034 -6 // Data Type Is Long
    // Save Time
    bool saveTimeSettings =
        PMM1103intToLong(PMM1103MasterOutputConfigrationArray[22], PMM1103MasterOutputConfigrationArray[23]) == 1;
    if (saveTimeSettings)
    { // 4034 - 6
        Debugprintln("Save Time ");
        uint32_t timeInUTC = PMM1103intToLong(PMM1103MasterOutputConfigrationArray[18], PMM1103MasterOutputConfigrationArray[19]);
        uint32_t timeZone = PMM1103intToLong(PMM1103MasterOutputConfigrationArray[20], PMM1103MasterOutputConfigrationArray[21]);
        PMMRTCSETUNIXTime(timeInUTC + timeZone);
    }

    bool calibrateBNO055 = PMM1103intToFloat(PMM1103MasterOutputConfigrationArray[24], PMM1103MasterOutputConfigrationArray[25]) == 1;
    if (calibrateBNO055) // 4040 - 4
    {
        PMMBNO55Calibrate();
        PMMSetMasterTrackerInfo();
    }

    bool saveSettings =
        PMM1103intToFloat(PMM1103MasterOutputConfigrationArray[34], PMM1103MasterOutputConfigrationArray[35]) == 1;
    if (saveSettings)
    {
        PMM1103MasterlostCommunicationTime = PMM1103intToFloat(PMM1103MasterOutputConfigrationArray[32], PMM1103MasterOutputConfigrationArray[33]);
        PMMSetMasterTrackerInfo();
    }
}

// ===== @brief Read Data From BNO and update it in modbus and update Time
void PMMUpdatePostiotn1103Master()
{
    PMMBNO055GetCoordination(PMM1103Masterx, PMM1103Mastery, PMM1103Masterz);
    // Show Value in Modbus
    PMM1103MasterAiArray1103[0].floatToInt.valueAsFloat = PMM1103Masterx;
    PMM1103MasterAiArray1103[1].floatToInt.valueAsFloat = PMM1103Mastery;
    PMM1103MasterAiArray1103[2].floatToInt.valueAsFloat = PMM1103Masterz;
    // Update Time
    PMM1103MasterAiArray1103[3].floatToInt.valueAsLong = PMMRTCUNIXTime();
    // SerialUSB.println(PMMRTCUNIXTime());
}
// ===== @brief Do Something when Power is lost
void PMMAlarmIO1103Master() {}
void PMMInputLoop1103Master()
{
    PMM1103MasterAutoManual = digitalRead(PMM1103MasterautoManual); // If Set Float Then Auto , if Pulled to ground then manual
}




// ****************** Global Function
float PMM1103intToFloat(uint16_t value0, uint16_t value1)
{
    union
    {
        float valueAsFloat;
        uint16_t valueAsInt[2];
    } floatToInt;

    floatToInt.valueAsInt[0] = value0;
    floatToInt.valueAsInt[1] = value1;
    return floatToInt.valueAsFloat;
}
int32_t PMM1103intToLong(uint16_t value0, uint16_t value1)
{
    union
    {
        float valueAsFloat;
        int32_t valueAsLong;
        uint16_t valueAsInt[2];
    } floatToInt;

    floatToInt.valueAsInt[0] = value0;
    floatToInt.valueAsInt[1] = value1;
    return floatToInt.valueAsLong;
}

// ==== Convert Float to Float with 1 Decimal Point
float PMM1103FloatToFloat(float value)
{
    return float(int(value * 10) / 10.0);
}
