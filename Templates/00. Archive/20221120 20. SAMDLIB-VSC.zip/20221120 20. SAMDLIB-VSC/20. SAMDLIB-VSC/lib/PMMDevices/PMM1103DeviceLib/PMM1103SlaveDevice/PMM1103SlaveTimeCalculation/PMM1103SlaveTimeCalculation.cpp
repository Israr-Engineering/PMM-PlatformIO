#include <PMM1103DeviceLib/PMM1103SlaveDevice/PMM1103SlaveTimeCalculation/PMM1103SlaveTimeCalculation.h>

/**
 * @brief Global Functions
 * PMMDegreeToRadian : Convert degree to radian
 * PMMRadianToDegree : convert radian to degree
 */
long int theTime;
float PMMDegreeToRadian(float degree) { return degree * PI / 180; }
float PMMRadianToDegree(float rad) { return rad * 180 / PI; }
/// @brief Get the HRA
/// @return Return HRA in Degree
float PMMHRA()
{
    /// All Value are right -> Tested at 2022/10/09 10:16
    // PMM1103Longitude = 36.0276305; // Just for Test
    PMM1103TimeZone = 3; // Just for Test
    // Calaculate the Day Number
    float B = PMMReturnB();
    int currentTimeInMinute = PMMReturnInMinute();                // the current minute in the day
    float EOT = 9.87 * sin(2 * B) - 7.53 * cos(B) - 1.5 * sin(B); // Calculate Eot
    // SerialUSB.println("***************************");
    // SerialUSB.print("EOT: ");
    // SerialUSB.println(EOT);

    float LTSM = 15.0 * PMM1103TimeZone; // 3 is the time zone for jordan -> local standard time moderation
    // SerialUSB.print("LTSM: ");
    // SerialUSB.println(LTSM);
    float TC = 4 * (PMM1103Longitude - LTSM) + EOT; // Time in minute Time Correction factor -> Worked
    // SerialUSB.print("TC: ");
    // SerialUSB.println(TC);
    float LST = currentTimeInMinute + TC; // Time in Local solar time
    // SerialUSB.print("LST: ");
    // SerialUSB.println(LST);
    float HRA = 15 * (LST) / 60 + 180;
    // SerialUSB.print("HRA: ");
    // SerialUSB.println(HRA);
    if (HRA > 180)
        HRA = HRA - 360;
    return HRA;
}

float PMMCalculateTC()
{
    float B = PMMReturnB();
    int currentTimeInMinute = PMMReturnInMinute();                // the current minute in the day
    float EOT = 9.87 * sin(2 * B) - 7.53 * cos(B) - 1.5 * sin(B); // Calculate Eot
    float LTSM = 15.0 * PMM1103TimeZone;                          // 3 is the time zone for jordan -> local standard time moderation
    float TC = 4 * (PMM1103Longitude - LTSM) + EOT;               // Time in minute Time Correction factor -> Worked
    return TC;
}

/// @brief Return the B which is the angel for EOT {Eqaution of time}
/// @return angel on Radian
float PMMReturnB()
{
    int16_t dayNumber = PMMReturnDayOfYear();
    float B = (360.0 / 365.0) * (dayNumber - 81);
    B = B * PI / 180.0;
    return B;
}
/// @brief
/// @param lat
/// @param Declination on RADian
/// @param HRARAD
/// @return Elivation in Degree
float PMMCalculateElevation(float latinDeg, float DeclinationRAD, float HRARAD)
{
    double latRAD = latinDeg * PI / 180; // convert to Radians
    // double DeclinationRAD = Declination * PI / 180; // convert to Radians
    double Elevation = asin((sin(DeclinationRAD) * sin(latRAD)) + (cos(latRAD) * cos(DeclinationRAD) * cos(HRARAD)));
    double ElevationRAD = Elevation;
    Elevation = Elevation * (180 / PI);
    return Elevation;
}
/// @brief
/// @param HRAVal
/// @param HRARAD
/// @param DeclinationRAD
/// @param latRAD
/// @param ElevationRAD
/// @return Retaun Azmith in Radian
float PMMCalculateAzmuith(float HRAVal, float HRARAD, float DeclinationRAD, float latRAD, float ElevationRAD)
{
    // HRA in radian
    float AzimuthRAD = acos((sin(DeclinationRAD) * cos(latRAD) - cos(DeclinationRAD) * sin(latRAD) * cos(HRARAD)) / cos(ElevationRAD));
    float AzimuthDegree = PMMRadianToDegree(AzimuthRAD);
    // if (HRAVal > 0)
    // {
    //     AzimuthDegree = 360 - AzimuthDegree;
    //     AzimuthRAD = PMMDegreeToRadian(AzimuthDegree);
    // }
    return AzimuthRAD;
}

float PMMSunTrueAngel()
{

    /// TRUE Angel Has ERROr After 2:50 its in miuns
    /// @return
    float HRAVal = PMMHRA();
    float HRARAD = PMMDegreeToRadian(HRAVal);
    float B = PMMReturnB();
    float DeclinationDeg = 23.45 * sin(B);
    float DeclinationRAD = PMMDegreeToRadian(DeclinationDeg); // RADIAN

    float eleveation = PMMCalculateElevation(PMM1103Latitude, DeclinationRAD, HRARAD); // In Degree
    // SerialUSB.print("eleveation: ");
    // SerialUSB.println(eleveation);
    float Zenith = 90 - eleveation; // Bs
    float ZenithRAD = PMMDegreeToRadian(Zenith);
    // SerialUSB.print("Zenith: ");
    // SerialUSB.println(Zenith);
    float b = cos(ZenithRAD);
    float azmithInRAD = PMMCalculateAzmuith(HRAVal, HRARAD, DeclinationRAD, PMMDegreeToRadian(PMM1103Latitude), PMMDegreeToRadian(eleveation));
    float azmithInDeg = PMMRadianToDegree(azmithInRAD);
    if (HRAVal > 0)
    {
        azmithInDeg = 360 - azmithInDeg;
    }
    // SerialUSB.print("azmithInDeg: ");
    // SerialUSB.println(azmithInDeg);

    float trueAngel = PMMCalculateTrueAngel(azmithInDeg, ZenithRAD);
    float trueAngelNRL = PMMCalculateTrueAngelNRL(eleveation, azmithInDeg);
    // SerialUSB.print("trueAngel: ");
    // SerialUSB.println(trueAngel);
    PMM1103SunSet = PMMSunSet(DeclinationRAD, PMMDegreeToRadian(PMM1103Latitude));
    PMM1103SunRise = PMMSunRise(DeclinationRAD, PMMDegreeToRadian(PMM1103Latitude));
    // SerialUSB.println(PMMRTCTime());
    // if (PMMISNoon())
    //     trueAngel = abs(trueAngel);

    int currentTime = PMMRTCUNIXTime();
    bool betweenSunSetAndSunRise = (currentTime < PMM1103SunSet && currentTime > PMM1103SunRise);
    if (!betweenSunSetAndSunRise)
        trueAngel = 0;
    if (millis() > theTime + 5000)
    {
        theTime = millis();
        SerialUSB.print("Current Time: ");
        SerialUSB.println(PMMRTCTime());
        SerialUSB.print("PMM1103SunRise ");
        SerialUSB.println(PMMGetTimeFromUnix(PMM1103SunRise));
        SerialUSB.print("PMM1103SunSet ");
        SerialUSB.println(PMMGetTimeFromUnix(PMM1103SunSet));
        SerialUSB.print("is it None Time ");
        SerialUSB.println(PMMISNoon());
        SerialUSB.print("True Angel ");
        SerialUSB.println(trueAngel);
        SerialUSB.println("*__=__*__=__*__=__*__=__*");
    }
    if (trueAngel > 56)
        trueAngel = 56;
    if (trueAngel < -56)
        trueAngel = -56;
    return trueAngel;
}
/// @param Azimuth in Degree
/// @param ZenithRAD in Rad
/// @return True Angel in Degree
float PMMCalculateTrueAngel(float Azimuth, float ZenithRAD)
{
    float Ys = 180 - Azimuth; // Ys
    float Yt = 360;
    Ys = PMMDegreeToRadian(Ys);
    Yt = PMMDegreeToRadian(Yt);
    float a = cos(Yt) * sin(ZenithRAD) * sin(Ys) - sin(Yt) * sin(ZenithRAD) * cos(Ys);
    float b = cos(ZenithRAD);
    float TrueAngle = -1 * atan(a / b);
    return PMMRadianToDegree(TrueAngle);
}

/// @brief
/// @param Elevation in degree
/// @param AzimuthDeg in dgree
/// @return return true angel NRL
float PMMCalculateTrueAngelNRL(float Elevation, float AzimuthDeg)
{

    float Bs = Elevation;
    float Ys = 360 - AzimuthDeg; // Ys
    Ys = PMMDegreeToRadian(AzimuthDeg);
    float Sx = cos(Bs) * sin(Ys);
    float Sy = cos(Bs) * cos(Ys);
    float Sz = sin(Bs);
    float Ya = 0;
    // Asmith
    float Yg = 0;
    float Bg = 0;
    float Dy = Ya - Yg;
    float Ba = atan(tan(Bg) * cos(Dy));
    // Ba = 180;
    // ?????? Ahmad Joghaimi-> ? Why to Add try to convert it to radian while it radian already?
    // Sx = Sx * Math.PI / 180;
    // Sy = Sy * Math.PI / 180;
    // Sz = Sz * Math.PI / 180;
    float Sxx = (cos(Ya)) - (Sy * sin(Ya));
    float Szz = (sin(Ya) * sin(Ba)) + (Sy * sin(Ba) * cos(Ya)) + (Sz * cos(Ba));
    float TrueAngleNerl = atan(Sxx / Szz);
    TrueAngleNerl = PMMDegreeToRadian(TrueAngleNerl);
    return TrueAngleNerl;
}

int PMMSunSet(float DeclinationRAD, float latRAD)
{
    DateTime RTCDateTiem = PMMRTCNOW();
    DateTime TimeAt12Am = DateTime(RTCDateTiem.year(), RTCDateTiem.month(), RTCDateTiem.day() + 1, 0, 0, 0);
    float tmp;
    tmp = ((double)1 / 15 * acos(tan(DeclinationRAD) * tan(latRAD)));
    tmp = tmp * 180 / PI;
    float TC = PMMCalculateTC();
    int sunset = TimeAt12Am.unixtime() - tmp * 60 * 60 - TC * 60;
    // int sunrise = TimeAt12Am.unixtime() + tmp * 60 * 60 - TC * 60;
    // SerialUSB.print("Current Time :");
    // SerialUSB.println(PMMRTCTime());
    // SerialUSB.print("Sun Rise :");
    // SerialUSB.println(PMMGetTimeFromUnix(sunrise));
    // SerialUSB.print("Sun Set :");
    // SerialUSB.println(PMMGetTimeFromUnix(sunset));
    // SerialUSB.println("===========");
    return sunset;
}
int PMMSunRise(float DeclinationRAD, float latRAD)
{
    DateTime RTCDateTiem = PMMRTCNOW();
    DateTime TimeAt12Am = DateTime(RTCDateTiem.year(), RTCDateTiem.month(), RTCDateTiem.day(), 0, 0, 0);
    float tmp;
    tmp = ((double)1 / 15 * acos(tan(DeclinationRAD) * tan(latRAD)));
    tmp = tmp * 180 / PI;
    float TC = PMMCalculateTC();
    // int sunset = TimeAt12Am.unixtime() - tmp * 60 * 60 - TC * 60;  // + PMM1103TimeZone * 60 * 60;
    int sunrise = TimeAt12Am.unixtime() + tmp * 60 * 60 - TC * 60; //+ PMM1103TimeZone * 60 * 60;
    return sunrise;
}
