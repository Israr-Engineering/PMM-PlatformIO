/**
 * Modbus Mapping
 *  -> 4000 - 4015 -> Read Holding Register
 *     4000 - 4001 -> X Axis Value {Float}
 *     4002 - 4003 -> Y Axis Value {Float}
 *     4004 - 4005 -> Z Axis Value {Float}
 *     4006 - 4007 -> Time In UTC {Long}
 *     4008 - 4009 -> Calculated TrueAngel {Float}
 *     4010 - 4011 -> Auto Manual {Float}
 *     4012 - 4013 -> Mode {1 => Tracking , 2=> Stall , 3=> Stop}
 *  -> 4016 - 4032 -> Write Multiple Holding Register
 *     4016 , 4017 -> Auto / Manual     {Float}
 *     4018 , 4019 -> X Axis Value      {Float}
 *     4020 , 4021 -> Y Axis Value      {Float}
 *     4022 , 4023 -> Z Axis Value      {Float}
 *     4024 , 4025 -> Save Axis Values  {Float}
 *     4026 , 4027 -> X Axis Value Tallerent {Float}
 *     4028 , 4029 -> Y Axis Value Tallerent {Float}
 *     4030 , 4031 -> Z Axis Value Tallerent {Float}
 *     4032 , 4033 -> Save Axis Values {Float}
 *     // Save time in Unix [Data type long Int]
 *     4034 , 4035 -> Time in Unix    // in socund
 *     4036 , 4037 -> Time Difference // in secound
 *     4038 , 4039 -> Save Time
 *     // ==>> calibrate MPU & BNO {Set the current value for MPU & BNO} [Data type float]
 *     4040 , 4041 -> BNO055 Calibrate {Float}
 *     4042 , 4043 -> MPU XAxis        {Float}
 *     4044 , 4045 -> MPU YAxis        {Float}
 *     4046 , 4047 -> MPU ZAxis        {Float}
 *     // ==>> Save Comunication lost time [Data type Long] 
 *     4048 , 4049 -> TimeIFTheirNoCommunication Convert To Auto
 *     4050 , 4051 -> Save Settings
 *     // ==>> Save slave id [Data type float]
 *     4052 , 4053 -> Slave ID
 *     4054 , 4055 -> Save Setting
 *     // ==>> Select traking Settings [data type float]
 *     4056 , 4057 -> Mode {1 => Tracking , 2=> Stall , 3=> Stop , 4=> onlyTracking}
 *     4058 , 4059 -> Save Mode
 *     4060 , 4061 -> Reset microcontroller
 *     // ==>> Save Tracking Limits [data type float]
 *     4062 , 4063 -> Max Limit Switch Value {Alarm if exceeded}
 *     4064 , 4065 -> Min Limit Switch Value {Alarm if exceeded}
 *     4066 , 4067 -> Max degree for Tracking
 *     4068 , 4069 -> Min degree for Tracking
 *     4070 , 4071 -> Save Settigns 
 *     // ==>> Save solar time settings [data type float]
 *     4072 , 4073 -> longitude
 *     4074 , 4075 -> Latitude
 *     4076 , 4077 -> time Zone
 *     4078 , 4079 -> save solar time correction param
 *  
 */

#ifndef PMM1103SlaveModbus
#define PMM1103SlaveModbus
#include <Arduino.h>
#include <projectConfigration.h>
#include <SPI.h>
#include <PMMRTUSlave/modbusRTUWrappper.h>
#include <PMMEEPROMSerialParam/PMMEEPROMSerialParam.h>
#include <PMMEEPROMAuth/PMMEEPROMAuth.h>
#include <PMMEEPROMTrackerSettings/PMMEEPROMTrackerSettings.h>
#include <../PMMFlash/PMMFlashGeneralFunction/PMMFlashGeneralFunction.h>
#include <SparkFun SPI SerialFlash Arduino Library/src/SparkFun_SPI_SerialFlash.h>
#include <../PMMPeripherals/PMMBNO055/PMMBNO055.h>
#include <../PMMPeripherals/PMMMPU6050/PMMMPU6050.h>
#include <../PMMPeripherals/PMMRTC/PMMRTC.h>
#include <../PMMPeripherals/PMMLora/PMMLora.h>
#include <LoRa.h>
#include <ArduinoRS485.h> // ArduinoModbus depends on the ArduinoRS485 library
#include <ArduinoModbus.h>
#include <PMM1103DeviceLib/PMM1103SlaveDevice/PMM1103SlaveVariable/PMM1103SlaveVariable.h>

extern byte PMM1103SlaveSerialOneSelect;
extern byte PMM1103SlaveSerialTwoSelect;
extern struct AI PMM1103SlaveAiArray1103[8];
extern word PMM1103SlaveOutputConfigrationArray[64];
extern word PMM1103SlaveInputArray[16];
extern struct modBusCoils PMM1103SlaveOnputCoilModbus;
extern struct modBusHolding PMM1103SlaveInputHolding;
extern struct modBusHolding PMM1103SlaveOutputHolding;
void PMMInitModbusRTU1103Slave(int slaveid);
void PMMModbusRTU1103Slave();
void PMMInitModbusTracker();

#endif
