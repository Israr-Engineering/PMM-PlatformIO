
#include <PMM1103DeviceLib/PMM1103SlaveDevice/PMM1103SlaveDevice.h>
int SlavelastTimeRequested = 0;
bool notSaved = false;
byte currnetSlaveid = 1;
void PMMInitalize1103Slave()
{

    SerialUSB.begin(9600);
    ModelName = "PMM 1103 Slave Tracker";
    Debugprintln("1103 Slave Device");
    currnetSlaveid = slaveId.toInt();

    PMM1103SlaveIOInit();
    PMMInitModbusRTU1103Slave(currnetSlaveid);
    PMMInitRTC();
    PMMInternalRTCInit();
    PMMMPU6050Setup(PMM1103SlaveSensorInterruptPins);
    // At startting Turn All Relay Off
    PMMPositining1103SlaveStopEastMovment();
    PMMPositining1103SlaveStopWestMovment();
    // Full Modbus Array From EEPROM
    SlavelastTimeRequested = millis();
    // Currnet Slave id
    // attachInterrupt(PMM1103SlavelossOfPower, PMMAlarmIO1103Slave, LOW); // No Need For LOS
    Debugprintln("Out From 1103 Slave Init");
}
void PMM1103SlaveLoop()
{
    PMM1103TrueAngel = PMMSunTrueAngel();
    PMMInputLoop1103Slave();      // Read Input & Sensors
    PMMUpdatePostiotn1103Slave(); // Read Position
    PMM1103MasterTimeing = PMMRTCUNIXTime();
    PMM1103SlaveAiArray1103[3].floatToInt.valueAsLong = PMM1103MasterTimeing; // Update Time
    PMM1103SlaveAiArray1103[4].floatToInt.valueAsFloat = PMM1103TrueAngel;
    PMM1103SlaveAiArray1103[5].floatToInt.valueAsFloat = PMM1103SlaveAutoManual;
    PMM1103SlaveAiArray1103[6].floatToInt.valueAsFloat = PMM1103ModeType;
    PMM1103SlaveAiToHoldingArray();
    bool modbusCommunicateOk = PMMRTUSlaveLoop(currnetSlaveid, PMM1103SlaveOnputCoilModbus, PMM1103SlaveOnputCoilModbus, PMM1103SlaveOutputHolding, PMM1103SlaveInputHolding, true);
    // Get Settings
    PMM1103SlaveSaveSettings();
    if (modbusCommunicateOk)
        SlavelastTimeRequested = millis(); // Reset Timer
    // delay(1000);
    // SerialUSB.print(".");
    /// @brief If Not In Monitoring
    if (!PMM1103SlaveAutoManualMonitor)
    {
        if (PMM1103SlaveAutoManual)
        {

            // if (PMM1103LostCommunicationDay != 0)
            // {
            //     PMM1103LostCommunicationDay = 0;
            //     PMMSetMasterTrackerInfo(); // Return the day to Zero Cause their is communication
            // }

            if (PMM1103ModeType == 1)
                // Tack the Position from the Modbus
                PMMAutoPositining1103Slave();
            else if (PMM1103ModeType == 2)
                // go to stall position
                PMMAutoStall1103Slave();
            else if (PMM1103ModeType == 3)
                PMMStopTracking();
            else if (PMM1103ModeType == 4) // Make the Controller Decide the angel
            {
                PMMAutoCalculatedAngel(PMM1103TrueAngel);
                // SerialUSB.println(PMM1103TrueAngel);
            }
            else if (PMM1103ModeType == 5) // Shared control Between Controller and Gateway
            {
                if (SlavelastTimeRequested + PMM1103MasterlostCommunicationTime * 1000 < millis())
                    PMMAutoCalculatedAngel(PMM1103TrueAngel);
                else
                    PMMAutoPositining1103Slave();
            }
            else if (PMM1103ModeType == 6) // Same as 1 the difference in the gateway
                PMMAutoPositining1103Slave();
        
        

        
        
            // => It Has Two Option ->> Has Communication , Has No Communication
            // Adjust the value to Do what it have to
            // if (false) // SlavelastTimeRequested + PMM1103MasterlostCommunicationTime * 1000 < millis())
            //     PMMAutoCalculatedAngel(PMM1103TrueAngel);
            // else
            // {
            //     if (PMM1103LostCommunicationDay != 0)
            //     {
            //         PMM1103LostCommunicationDay = 0;
            //         PMMSetMasterTrackerInfo(); // Return the day to Zero Cause their is communication
            //     }
            //     if (PMM1103ModeType == 1)
            //         // Tack the Position from the Modbus
            //         PMMAutoPositining1103Slave();
            //     else if (PMM1103ModeType == 2)
            //         // go to stall position
            //         PMMAutoStall1103Slave();
            //     else if (PMM1103ModeType == 3)
            //         PMMStopTracking();
            // }
        }
        else
            PMMManualPositining1103Slave();
    }
}

void PMM1103SlaveAiToHoldingArray()
{
    for (int i = 0, j = 0; i < 8; i++)
    {
        PMM1103SlaveInputArray[j] = PMM1103SlaveAiArray1103[i].floatToInt.valueAsInt[1];
        j++;
        PMM1103SlaveInputArray[j] = PMM1103SlaveAiArray1103[i].floatToInt.valueAsInt[0];
        j++;
    }
}

void PMMAlarmIO1103Slave()
{
    // Save MPU Position
    if (!notSaved)
    {
        PMMMPUOldReadingValuey = 30; // PMM1103Slavey;
        PMMMPUOldReadingValuex = 30; // PMM1103Slavex;
        PMMMPUOldReadingValuez = 30; // PMM1103Slavez;
        PMMSetMasterTrackerInfo();
        notSaved = true;
    }
}