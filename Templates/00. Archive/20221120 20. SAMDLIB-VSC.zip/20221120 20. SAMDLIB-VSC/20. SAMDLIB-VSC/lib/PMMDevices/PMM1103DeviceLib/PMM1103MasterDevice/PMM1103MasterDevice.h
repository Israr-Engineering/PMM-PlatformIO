#ifndef PMM1103MasterDeviceLib
#define PMM1103MasterDeviceLib

#include <Arduino.h>
#include <projectConfigration.h>
#include <SPI.h>
#include <PMMRTUSlave/modbusRTUWrappper.h>
#include <PMMEEPROMSerialParam/PMMEEPROMSerialParam.h>
#include <PMMEEPROMAuth/PMMEEPROMAuth.h>
#include <PMMEEPROMTrackerSettings/PMMEEPROMTrackerSettings.h>
#include <../PMMFlash/PMMFlashGeneralFunction/PMMFlashGeneralFunction.h>
#include <SparkFun SPI SerialFlash Arduino Library/src/SparkFun_SPI_SerialFlash.h>
#include <../PMMPeripherals/PMMBNO055/PMMBNO055.h>
#include <../PMMPeripherals/PMMMPU6050/PMMMPU6050.h>
#include <../PMMPeripherals/PMMRTC/PMMRTC.h>
#include <../PMMPeripherals/PMMLora/PMMLora.h>
#include <LoRa.h>
#include <ArduinoRS485.h> // ArduinoModbus depends on the ArduinoRS485 library
#include <ArduinoModbus.h>



#include <PMM1103DeviceLib/PMM1103MasterDevice/PMM1103MasterModbus/PMM1103MasterModbus.h>

// --- Global Functions
extern String ModelName;
extern SerialParameter portOne;
extern SerialParameter portTwo;
// --- IO Pinout
static byte PMM1103MasterRelayOne = A3;
static byte PMM1103MasterRelayTwo = A4;
static byte PMM1103MasterSerialOneSelect = 26;
static byte PMM1103MasterSerialTwoSelect = 9;
static byte PMM1103MasterSensorInterruptPins = 11;
// byte OrderWestBtn = A3;
static byte PMM1103MasterFeadBackBtn = 8;
static byte PMM1103MasterfanControl = 2;
static byte PMM1103MasterlossOfPower = 6;
static byte PMM1103MasterautoManual = 8;
static byte PMM1103MasterFeedbackPin = 5;
// Lora
static byte PMM1103MasterloraCS = A2;

static byte PMM1103MasterloraRST = 4;
static byte PMM1103MasterDO0 = 10;
static int PMM1103Mastercounter = 0;
// Flash
static byte PMM1103MasterFlashCS = 9;
// --- Modbus Struct Info
static struct AI PMM1103MasterAiArray1103[8];
static word PMM1103MasterOutputConfigrationArray[38];

static struct modBusCoils PMM1103MasterOnputCoilModbus;
// static struct modBusCoils PMM1103MasterOutputCoilModbus;
static struct modBusHolding PMM1103MasterInputHolding;
static struct modBusHolding PMM1103MasterOutputHolding;
static float PMM1103Masterx, PMM1103Mastery, PMM1103Masterz;
extern float PMM1103RequiredMasterx, PMM1103RequiredMastery, PMM1103RequiredMasterz;
extern float PMM1103TollerentMasterx, PMM1103TollerentMastery, PMM1103TollerentMasterz;
extern int PMM1103MasterlostCommunicationTime;
void PMMInitalize1103Master();
void PMMInitIO1103Master();
void PMMInitModbusRTU1103Master();
void PMM1103MasterLoop();
void PMMAlarmIO1103Master();
void PMMUpdatePostiotn1103Master();
void PMMAutoPositining1103Master();
void PMMInputLoop1103Master();
// West Movment
void PMMPositining1103MasterStartWestMovment();
void PMMPositining1103MasterStopWestMovment();
// East Movment
void PMMPositining1103MasterStartEastMovment();
void PMMPositining1103MasterStopEastMovment();
// General Function
float PMM1103FloatToFloat(float value);
float PMM1103intToFloat(uint16_t value0, uint16_t value1);
int32_t PMM1103intToLong(uint16_t value0, uint16_t value1);
void PMM1103MasterSaveSettings();

#endif