#include <PMM1103DeviceLib/PMM1103SlaveDevice/PMM1103SlaveMovment/PMM1103SlaveMovment.h>

bool SlavelastMovment = false;
bool canMoveEast;
bool canMoveWest;
int currentTime = 0;
// Initalize IO
void PMM1103SlaveIOInit()
{
    Debugprintln("Init IO ..");
    // === Output
    pinMode(PMM1103SlaveSerialOneSelect, OUTPUT);
    pinMode(PMM1103SlaveSerialTwoSelect, OUTPUT);
    pinMode(PMM1103SlaveRelayTwo, OUTPUT);
    pinMode(PMM1103SlaveRelayOne, OUTPUT);
    pinMode(PMM1103SlavefanControl, OUTPUT);
    // === Serial Enable Output
    digitalWrite(PMM1103SlaveSerialOneSelect, HIGH);
    digitalWrite(PMM1103SlaveSerialTwoSelect, HIGH);
    // === Relay TurnOff
    digitalWrite(PMM1103SlaveRelayOne, LOW);
    digitalWrite(PMM1103SlaveRelayTwo, LOW);
    // for (int i = 0; i < 50; i++)
    // {
    //     digitalWrite(PMM1103SlaveRelayOne, LOW);
    //     digitalWrite(PMM1103SlaveRelayTwo, LOW);
    //     delay(500);
    //     digitalWrite(PMM1103SlaveRelayOne, HIGH);
    //     digitalWrite(PMM1103SlaveRelayTwo, HIGH);
    //     delay(500);
    // }
    // === Input
    pinMode(PMM1103SlaveautoManualPin, INPUT_PULLUP);
    pinMode(PMM1103SlaveFeedbackPin, INPUT_PULLUP);
    pinMode(PMM1103SlaveOrderWest, INPUT_PULLUP);
    pinMode(PMM1103SlaveOrderEast, INPUT_PULLUP);
}

// **** LOOP Functions

void PMMAutoCalculatedAngel(float HRA)
{
    // bool theNextDayWithoutCommunication = false;
    // if (PMM1103LostCommunicationDay != PMMReturnDayNumber() && PMM1103LostCommunicationDay != 0)
    // {
    //     theNextDayWithoutCommunication = true;
    // }
    // else if (PMM1103LostCommunicationDay == 0)
    // {
    //     PMM1103LostCommunicationDay = PMMReturnDayNumber();
    //     // PMMSetMasterTrackerInfo(); // Save the New Day
    // }
    // // Go To Store Posistion
    // uint8_t numberOfMonth = PMMReturnMonthNumber();
    // bool inWinter = numberOfMonth == 1 || numberOfMonth == 2 || numberOfMonth == 11 || numberOfMonth == 12;
    // bool itsAfterSunSet = PMMRTCUNIXTime() > PMM1103SunSet;

    // if (inWinter || theNextDayWithoutCommunication || itsAfterSunSet)
    // {
    //     PMMAutoStall1103Slave();
    //     return;
    // }

    // Does It Worth Moving ?
    bool shouldNotMove = int(HRA) /*+ int(PMM1103TollerentMastery)*/ >= (PMM1103Slavey) && int(HRA) /*- int(PMM1103TollerentMastery)*/ <= (PMM1103Slavey);

    // SerialUSB.println(PMM1103Mastery);
    if (int(HRA) != int(PMM1103Slavey))
    {

        // Check The Y Axis Only
        if (HRA > -60 && HRA < 60)
        {

            if (HRA > PMM1103SlaveFloatToFloat(PMM1103Slavey))
                PMMPositining1103SlaveStartWestMovment();
            else if (HRA < PMM1103SlaveFloatToFloat(PMM1103Slavey))
                PMMPositining1103SlaveStartEastMovment();
        }
        else
        {
            PMMPositining1103SlaveStopWestMovment();
            PMMPositining1103SlaveStopEastMovment();
        }
    }
    else
    {

        // Stop All Of It
        PMMPositining1103SlaveStopWestMovment();
        PMMPositining1103SlaveStopEastMovment();
    }
}

void PMMAutoPositining1103Slave()
{
    // delay(1000);

    // Not Reached At least for once
    if (!PMM1103Reached)
    {

        if (int(PMM1103RequiredMastery) != int(PMM1103Slavey))
        {
            // SerialUSB.println("Moving ..");
            if (PMM1103SlaveFloatToFloat(PMM1103RequiredMastery) > PMM1103SlaveFloatToFloat(PMM1103Slavey))
                PMMPositining1103SlaveStartWestMovment(); // Move West
            else if (PMM1103SlaveFloatToFloat(PMM1103RequiredMastery) < PMM1103SlaveFloatToFloat(PMM1103Slavey))
                PMMPositining1103SlaveStartEastMovment();
            else
            {
                // SerialUSB.println("Stop Moving ..");
                // You reach you goal ..
                PMMPositining1103SlaveStopWestMovment();
                PMMPositining1103SlaveStopEastMovment();
                PMM1103Reached = true;
            }
        }
        else
        {
            PMMPositining1103SlaveStopWestMovment();
            PMMPositining1103SlaveStopEastMovment();
            PMM1103Reached = true;
        }
    }
    else
    {
        // If its reached check if its stell in the right posisition
        bool lessThanUpperLimit = int(PMM1103RequiredMastery) + int(PMM1103TollerentMastery) >= (PMM1103Slavey);
        bool moreThanUpperLimit = int(PMM1103RequiredMastery) - int(PMM1103TollerentMastery) <= (PMM1103Slavey);
        PMM1103Reached = lessThanUpperLimit && moreThanUpperLimit;
    }
}
/* Todooo   PMM1103NotReachedYet*/
// *** Stall position
void PMMAutoStall1103Slave()
{
    if (!PMM1103Reached)
    {
        if (0 != PMM1103Slavey)
        {
            if (0 > PMM1103SlaveFloatToFloat(PMM1103Slavey))
                PMMPositining1103SlaveStartWestMovment(); // Move West
            else if (0 < PMM1103SlaveFloatToFloat(PMM1103Slavey))
                PMMPositining1103SlaveStartEastMovment();
            else
            {
                // You reach you goal ..
                PMMPositining1103SlaveStopWestMovment();
                PMMPositining1103SlaveStopEastMovment();
                PMM1103Reached = true;
            }
        }
        else
        {
            PMMPositining1103SlaveStopWestMovment();
            PMMPositining1103SlaveStopEastMovment();
            PMM1103Reached = true;
        }
    }
    else
    {
        // If its reached check if its stell in the right posisition
        bool lessThanUpperLimit = int(PMM1103TollerentMastery) >= (PMM1103Slavey);
        bool moreThanUpperLimit = -int(PMM1103TollerentMastery) <= (PMM1103Slavey) * -1;
        PMM1103Reached = lessThanUpperLimit && moreThanUpperLimit;
    }
}
// *** Stop Tracker
void PMMStopTracking()
{
    PMMPositining1103SlaveStopEastMovment();
    PMMPositining1103SlaveStopWestMovment();
}
/* Todooo*/
// Manual Control
void PMMManualPositining1103Slave()
{
    bool goWest = !digitalRead(PMM1103SlaveOrderWest);
    bool goEast = !digitalRead(PMM1103SlaveOrderEast);
    PMM1103Reached = false;
    if (goWest)
    {
        PMMPositining1103SlaveStartWestMovment();
    }
    else if (goEast)
    {
        PMMPositining1103SlaveStartEastMovment();
    }
    else
    {
        PMMPositining1103SlaveStopEastMovment();
        PMMPositining1103SlaveStopWestMovment();
    }
}

void PMMUpdatePostiotn1103Slave()
{
    PMMMPUGetCoordination(PMM1103Slavex, PMM1103Slavey, PMM1103Slavez);
    // Show Value in Modbus
    PMM1103SlaveAiArray1103[0].floatToInt.valueAsFloat = PMM1103Slavex;
    PMM1103SlaveAiArray1103[1].floatToInt.valueAsFloat = PMM1103Slavey;
    PMM1103SlaveAiArray1103[2].floatToInt.valueAsFloat = PMM1103Slavez;
}

void PMMPositining1103SlaveStartWestMovment()
{
    // Check if FeedBack Is Reached //
    // bool ManualControlBoundry = (PMM1103Slavey < PMM1103MaxLimitSwitchDegree) && PMM1103SlaveautoManualPin;
    // bool AutoControlBoundry = PMM1103Slavey < PMM1103MaxDegree;
    bool inBoundry = false;

    if (!PMM1103SlaveautoManualPin) // its one in Auto
        inBoundry = (PMM1103Slavey < PMM1103MaxLimitSwitchDegree);
    else
        inBoundry = PMM1103Slavey < PMM1103MaxDegree;
    // (ManualControlBoundry) || AutoControlBoundry;
    canMoveWest = (inBoundry);

    // Stop East Movment
    PMMPositining1103SlaveStopEastMovment();
    if (canMoveWest)
    {
        digitalWrite(PMM1103SlaveRelayOne, HIGH);
        SlavelastMovment = false; // Set false to specifiay that the last movemaent was west
    }
    else
    {
        // if (millis() > currentTime + 1000)
        // {
        // currentTime = millis();
        // SerialUSB.println("Trying move West ..");
        // SerialUSB.print("Current Y: ");
        // SerialUSB.println(PMM1103Slavey);
        // SerialUSB.print("PMM1103MaxLimitSwitchDegree : ");
        // SerialUSB.println(PMM1103MaxLimitSwitchDegree);
        // SerialUSB.print("PMM1103MaxDegree : ");
        // SerialUSB.println(PMM1103MaxDegree);
        // }

        // SerialUSB.println("NO Move Allowed");
        // SerialUSB.println(PMM1103MaxDegree);
        PMMPositining1103SlaveStopWestMovment(); // Stop Movment
    }
}
void PMMPositining1103SlaveStopWestMovment()
{
    digitalWrite(PMM1103SlaveRelayOne, LOW);
}
void PMMPositining1103SlaveStartEastMovment()
{
    // Check if FeedBack Is Reached   //
    bool ManualControlBoundry = PMM1103Slavey > PMM1103MinLimitSwitchDegree;
    bool AutoControlBoundry = PMM1103Slavey > PMM1103MinDegree;
    bool inBoundry = false;

    if (!PMM1103SlaveAutoManual)
        inBoundry = (PMM1103Slavey > PMM1103MinLimitSwitchDegree);
    else
        inBoundry = (PMM1103Slavey > PMM1103MinDegree);

    canMoveEast = inBoundry;
    // SerialUSB.println(inBoundry);

    // Stop East
    PMMPositining1103SlaveStopWestMovment();

    if (canMoveEast)
    {
        SlavelastMovment = true; // Set true to specifiay that the last movemaent was East
        digitalWrite(PMM1103SlaveRelayTwo, HIGH);
    }
    else
    {
        // if (millis() > currentTime + 1000)
        // {
        // currentTime = millis();
        // SerialUSB.println("Trying move East ..");
        // SerialUSB.print("Current Y: ");
        // SerialUSB.println(PMM1103Slavey);
        // SerialUSB.print("PMM1103MinLimitSwitchDegree : ");
        // SerialUSB.println(PMM1103MinLimitSwitchDegree);
        // SerialUSB.print("PMM1103MinDegree : ");
        // SerialUSB.println(PMM1103MinDegree);
        // }

        PMMPositining1103SlaveStopEastMovment();
    }
}
void PMMPositining1103SlaveStopEastMovment()
{
    digitalWrite(PMM1103SlaveRelayTwo, LOW);
}
void PMMInputLoop1103Slave()
{
    PMM1103SlaveAutoManual = digitalRead(PMM1103SlaveautoManualPin); // If Set Float Then Auto , if Pulled to ground then manual
}