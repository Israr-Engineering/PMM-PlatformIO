--- How To USE
# Trackers Mode - Auto Tracking 
    * You can check if the Mode is Auto or manual at Modbus Holidng register Float -> 4010 - 4011 
        - 0.0 -> Manual 
        - 0.1 -> Auto
    * Defined inside Modbus Holidng register Float -> 4056 , 4057 
        - Tracking       -> Value is 1.0 --> Take the Angel Value from Modbus 
        - Stall          -> Value is 2.0 --> Go To Zero Position
        - Stop           -> Value is 3.0 --> Stop Moving 
        - AutoTracking   -> Value is 4.0 --> Make the controller decide the angel 
        - TrackingAuto   -> Value is 5.0 --> Control by Gateway if their are lost of communication it will be controlled by controller 
        - SetAngel       -> Value is 6.0 --> Take Only one Angel
    * Read the Auto Mode at Modbus Holidng register Float -> 4012 - 4013 

# Calculating the True Angel 
    * Angel Calculation 
        - Set the Current time At Holding Register Long {Time in UTC}            -> 4034 , 4035
        - Time Zone 3 * 60 *60 {10800}                                           -> 4036 , 4037
        - Set the Langetude and Latitude At Holding Register Float 
            -> 4072 , 4073 -> longitude ->  35.864799
            -> 4074 , 4075 -> Latitude  ->  31.959700
            -> 4076 , 4077 -> time Zone -> 3 
        - Set the Mode To 4.0 long int -> 4056 , 4057