#ifndef PMM1103SlaveTimeCalculation
#define PMM1103SlaveTimeCalculation
#include <Arduino.h>
#include <../PMMPeripherals/PMMRTC/PMMRTC.h>
#include <PMM1103DeviceLib/PMM1103SlaveDevice/PMM1103SlaveVariable/PMM1103SlaveVariable.h>

float PMMHRA();
float PMMReturnB();
float PMMSunTrueAngel();
float PMMCalculateElevation(float lat, float DeclinationRAD, float HRARAD);
float PMMCalculateAzmuith(float HRAVal, float HRARAD, float DeclinationRAD, float latRAD, float ElevationRAD);
float PMMDegreeToRadian(float degree);
float PMMRadianToDegree(float rad);
float PMMCalculateTrueAngel(float Azimuth, float ZenithRAD);
float PMMCalculateTrueAngelNRL(float Elevation, float AzimuthDeg);
float PMMCalculateTC();
int PMMSunSet(float DeclinationRAD, float latRAD);
int PMMSunRise(float DeclinationRAD, float latRAD);
#endif