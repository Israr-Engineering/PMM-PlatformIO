#ifndef PMM1103SlaveTest
#define PMM1103SlaveTest
#include <Arduino.h>
#include <projectConfigration.h>
#include <SPI.h>
#include <PMMEEPROMTrackerSettings/PMMEEPROMTrackerSettings.h>
#include <../PMMPeripherals/PMMRTC/PMMRTC.h>
#include <../PMMPeripherals/PMMMPU6050/PMMMPU6050.h>
#include <PMM1103DeviceLib/PMM1103SlaveDevice/PMM1103SlaveVariable/PMM1103SlaveVariable.h>
void PMM1103SlaveTestLoop();
extern byte PMM1103SlaveRelayOne, PMM1103SlaveRelayTwo, PMM1103SlaveSerialOneSelect, PMM1103SlaveSerialTwoSelect;

#endif