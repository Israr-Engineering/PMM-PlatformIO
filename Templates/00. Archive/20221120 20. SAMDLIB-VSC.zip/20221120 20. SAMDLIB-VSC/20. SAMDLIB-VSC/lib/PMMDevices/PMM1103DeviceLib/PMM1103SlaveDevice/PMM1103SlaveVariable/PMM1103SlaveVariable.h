#ifndef PMM1103SlaveVariable
#define PMM1103SlaveVariable
#include <Arduino.h>
#include <projectConfigration.h>
#include <SPI.h>
#include <PMMEEPROMTrackerSettings/PMMEEPROMTrackerSettings.h>
#include <../PMMPeripherals/PMMRTC/PMMRTC.h>
#include <../PMMPeripherals/PMMInternalRTC/PMMInternalRTC.h>
#include <../PMMPeripherals/PMMMPU6050/PMMMPU6050.h>
#include <PMMEEPROMModBus/PMMEEPROMModBus.h>
void PMM1103SlaveSaveSettings();
float PMM1103SlaveFloatToFloat(float value);
int32_t PMM1103SlaveintToLong(uint16_t value0, uint16_t value1);
float PMM1103SlaveintToFloat(uint16_t value0, uint16_t value1);
void PMM1103SlaveSaveSettings();

void PMM1103SlaveSaveMaxMinDegree();
void PMM1103SlaveSaveTrakingEqation();
void PMM1103SlaveDirectionSetting();
void PMM1103SlaveDirectionTolerence();
void PMM1103SlaveSaveTime();
void PMM1103SlaveSensorCalibration();
void PMM1103SlaveSaveMode();
void PMM1103SlaveChangeodbusSetting();
void PMM1103SlaveSaveCommunicationTime();
float PMM1103SlaveFloatToFloat2Decimal(float value);

extern String slaveId;
extern float xAxisCalibration, yAxisCalibration, zAxisCalibration;
extern float PMM1103RequiredMasterx, PMM1103RequiredMastery, PMM1103RequiredMasterz;
extern float PMM1103TollerentMasterx, PMM1103TollerentMastery, PMM1103TollerentMasterz;
extern int PMM1103MasterlostCommunicationTime, PMM1103ModeType,PMM1103SunSet,PMM1103SunRise;
extern float PMM1103MaxLimitSwitchDegree, PMM1103MinLimitSwitchDegree, PMM1103MaxDegree, PMM1103MinDegree;
extern float PMM1103TimeZone, PMM1103Longitude, PMM1103Latitude;


#endif
