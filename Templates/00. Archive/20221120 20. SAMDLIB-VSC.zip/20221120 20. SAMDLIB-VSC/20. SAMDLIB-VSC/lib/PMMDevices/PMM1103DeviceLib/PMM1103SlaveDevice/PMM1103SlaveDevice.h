#ifndef PMM1103SlaveDevice
#define PMM1103SlaveDevice

#include <Arduino.h>
#include <projectConfigration.h>
#include <SPI.h>
#include <PMMRTUSlave/modbusRTUWrappper.h>
#include <PMMEEPROMSerialParam/PMMEEPROMSerialParam.h>
#include <PMMEEPROMAuth/PMMEEPROMAuth.h>
#include <PMMEEPROMTrackerSettings/PMMEEPROMTrackerSettings.h>
#include <../PMMFlash/PMMFlashGeneralFunction/PMMFlashGeneralFunction.h>
#include <SparkFun SPI SerialFlash Arduino Library/src/SparkFun_SPI_SerialFlash.h>
#include <../PMMPeripherals/PMMBNO055/PMMBNO055.h>
#include <../PMMPeripherals/PMMMPU6050/PMMMPU6050.h>
#include <../PMMPeripherals/PMMRTC/PMMRTC.h>
#include <../PMMPeripherals/PMMInternalRTC/PMMInternalRTC.h>
#include <../PMMPeripherals/PMMLora/PMMLora.h>
#include <LoRa.h>
#include <ArduinoRS485.h> // ArduinoModbus depends on the ArduinoRS485 library
#include <ArduinoModbus.h>

#include <PMM1103DeviceLib/PMM1103SlaveDevice/PMM1103SlaveVariable/PMM1103SlaveVariable.h>
#include <PMM1103DeviceLib/PMM1103SlaveDevice/PMM1103SlaveMovment/PMM1103SlaveMovment.h>
#include <PMM1103DeviceLib/PMM1103SlaveDevice/PMM1103SlaveModbus/PMM1103SlaveModbus.h>
#include <PMM1103DeviceLib/PMM1103SlaveDevice/PMM1103SlaveTimeCalculation/PMM1103SlaveTimeCalculation.h>
// --- Global Functions
extern String ModelName;
extern byte PMM1103SlaveSensorInterruptPins;
extern float PMM1103Slavex, PMM1103Slavey, PMM1103Slavez;
extern bool PMM1103SlaveAutoManual;
extern bool PMM1103SlaveAutoManualMonitor;
extern byte PMM1103SlavelossOfPower;
extern int PMM1103MasterTimeing, PMM1103ModeType;
extern float PMMMPUOldReadingValuex, PMMMPUOldReadingValuey, PMMMPUOldReadingValuez, PMM1103HRA, PMM1103TrueAngel;

void PMMInitalize1103Slave();
void PMM1103SlaveLoop();
void PMMAlarmIO1103Slave();
void PMM1103SlaveAiToHoldingArray();
// float PMMHRA();
// float sunTrueAngel();
// float PMMCalculateDeclination(float B);
// float PMMCalculateElevation(float lat, float Declination, float HRARAD);
// float PMMCalculateAzmuith(float HRAVal, float HRARAD, float DeclinationRAD, float latRAD, float ElevationRAD);
// float PMMDegreeToRadian(float degree);
// float PMMRadianToDegree(float rad);

#endif