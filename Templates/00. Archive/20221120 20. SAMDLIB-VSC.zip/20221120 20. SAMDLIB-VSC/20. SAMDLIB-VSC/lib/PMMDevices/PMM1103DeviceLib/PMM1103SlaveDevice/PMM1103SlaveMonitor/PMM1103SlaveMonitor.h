#ifndef PMM1103SlaveMonitor
#define PMM1103SlaveMonitor
#include <Arduino.h>
#include <projectConfigration.h>
#include <SPI.h>
#include <PMM1103DeviceLib/PMM1103SlaveDevice/PMM1103SlaveVariable/PMM1103SlaveVariable.h>
#include <PMM1103DeviceLib/PMM1103SlaveDevice/PMM1103SlaveMovment/PMM1103SlaveMovment.h>

extern bool PMM1103SlaveAutoManualMonitor;
extern int PMM1103MasterTimeing;
extern float PMM1103Slavex, PMM1103Slavey, PMM1103Slavez;
extern float PMM1103RequiredMasterx, PMM1103RequiredMastery, PMM1103RequiredMasterz;
extern float PMM1103TollerentMasterx, PMM1103TollerentMastery, PMM1103TollerentMasterz;

void PMM1103SlaveMonitorLoop();

#endif