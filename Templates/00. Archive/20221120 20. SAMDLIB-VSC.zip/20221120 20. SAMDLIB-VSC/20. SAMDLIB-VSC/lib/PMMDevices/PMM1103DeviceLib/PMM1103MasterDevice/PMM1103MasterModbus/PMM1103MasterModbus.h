/**
 * Modbus Mapping
 *  -> 4000 - 4015 -> Read Holding Register
 *     4000 - 4001 -> X Axis Value
 *     4002 - 4003 -> Y Axis Value
 *     4004 - 4005 -> Z Axis Value
 *     4006 - 4007 -> Time In UTC
 *  -> 4016 - 4032 -> Write Multiple Holding Register
 *     4016 , 4017 -> Auto / Manual
 *     4018  , 4019 -> X Axis Value
 *     4020 , 4021 -> Y Axis Value
 *     4022 , 4023 -> Z Axis Value
 *     4024 , 4025 -> Save Axis Values
 *     4026 , 4027 -> X Axis Value Tallerent
 *     4028 , 4029 -> Y Axis Value Tallerent
 *     4030 , 4031 -> Z Axis Value Tallerent
 *     4032 , 4033 -> Save Axis Values
 *     4034 , 4034 -> Time in Unix
 *     4036 , 4037 -> Time Difference
 *     4038 , 4039 -> Save Time
 *     4040 , 4041 -> BNO055 Calibrate
 *     4042 , 4043 -> MPU XAxis
 *     4044 , 4045 -> MPU YAxis
 *     4046 , 4047 -> MPU ZAxis
 *     4048 , 4049 -> TimeIFTheirNoCommunication Convert To Auto
 *     4050 , 4051 -> Save Settings
 */


#ifndef PMM1103MasterModbus
#define PMM1103MasterModbus
#include <Arduino.h>
#include <projectConfigration.h>
#include <SPI.h>
#include <PMMRTUSlave/modbusRTUWrappper.h>
#include <PMMEEPROMSerialParam/PMMEEPROMSerialParam.h>
#include <PMMEEPROMAuth/PMMEEPROMAuth.h>
#include <PMMEEPROMTrackerSettings/PMMEEPROMTrackerSettings.h>
#include <../PMMFlash/PMMFlashGeneralFunction/PMMFlashGeneralFunction.h>
#include <SparkFun SPI SerialFlash Arduino Library/src/SparkFun_SPI_SerialFlash.h>
#include <../PMMPeripherals/PMMBNO055/PMMBNO055.h>
#include <../PMMPeripherals/PMMMPU6050/PMMMPU6050.h>
#include <../PMMPeripherals/PMMRTC/PMMRTC.h>
#include <../PMMPeripherals/PMMLora/PMMLora.h>
#include <LoRa.h>
#include <ArduinoRS485.h> // ArduinoModbus depends on the ArduinoRS485 library
#include <ArduinoModbus.h>


void PMMPrintAhmad();



#endif
