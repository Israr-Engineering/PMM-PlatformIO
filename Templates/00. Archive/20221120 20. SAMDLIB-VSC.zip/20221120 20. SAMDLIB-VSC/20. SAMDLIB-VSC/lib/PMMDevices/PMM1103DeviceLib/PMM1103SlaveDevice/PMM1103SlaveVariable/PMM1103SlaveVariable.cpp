#include <PMM1103DeviceLib/PMM1103SlaveDevice/PMM1103SlaveVariable/PMM1103SlaveVariable.h>

// --- IO Pinout
byte PMM1103SlaveRelayOne = A4;
byte PMM1103SlaveRelayTwo = A3;
byte PMM1103SlaveSerialOneSelect = 26;
byte PMM1103SlaveSerialTwoSelect = 9;
byte PMM1103SlaveSensorInterruptPins = 11;
// byte OrderWestBtn = A3;
byte PMM1103SlaveFeadBackBtn = 8;
byte PMM1103SlavefanControl = 2;
byte PMM1103SlavelossOfPower = 6;
byte PMM1103SlaveautoManualPin = 8;
byte PMM1103SlaveFeedbackPin = 5;
// Lora
byte PMM1103SlaveloraCS = A2;
byte PMM1103SlaveloraRST = 4;

byte PMM1103SlaveOrderWest = 12;
byte PMM1103SlaveOrderEast = 10;

int PMM1103Slavecounter = 0;
// Flash
byte PMM1103SlaveFlashCSAhmad = 9;

// --- Modbus Struct Info
struct AI PMM1103SlaveAiArray1103[8];
word PMM1103SlaveInputArray[16];
word PMM1103SlaveOutputConfigrationArray[64];
bool PMM1103SlaveAutoManual;
bool PMM1103SlaveAutoManualMonitor;
struct modBusCoils PMM1103SlaveOnputCoilModbus;
// static struct modBusCoils PMM1103MasterOutputCoilModbus;
struct modBusHolding PMM1103SlaveInputHolding;
struct modBusHolding PMM1103SlaveOutputHolding;
float PMM1103Slavex, PMM1103Slavey, PMM1103Slavez;
int lastMPUUPdatedValue;
int PMM1103MasterTimeing;

bool PMM1103Reached;
void PMM1103SlaveSaveSettings()
{

    PMM1103SlaveDirectionSetting();
    PMM1103SlaveDirectionTolerence();
    PMM1103SlaveSaveTime();
    PMM1103SlaveSensorCalibration();
    PMM1103SlaveSaveCommunicationTime();
    PMM1103SlaveChangeodbusSetting();
    PMM1103SlaveSaveMode();
    PMM1103SlaveSaveMaxMinDegree();
    PMM1103SlaveSaveTrakingEqation();
    // Reset Microcontroller 4060 , 4061
    bool RSTMicrocontroller = PMM1103SlaveintToFloat(PMM1103SlaveOutputConfigrationArray[44], PMM1103SlaveOutputConfigrationArray[45]) == 1;
    if (RSTMicrocontroller)
        NVIC_SystemReset();
}

// ============ Saving Modbus Functions
void PMM1103SlaveDirectionTolerence()
{
    // Modbus Addresses ==>>> 4026 -8 // Data Type Is Float

    bool saveTolerantDirectionSettings = PMM1103SlaveintToFloat(PMM1103SlaveOutputConfigrationArray[16], PMM1103SlaveOutputConfigrationArray[17]) == 1;

    if (saveTolerantDirectionSettings) // 4026 - 8
    {
        float PMM1103TollerentMasterxNew = PMM1103SlaveintToFloat(PMM1103SlaveOutputConfigrationArray[10], PMM1103SlaveOutputConfigrationArray[11]);
        float PMM1103TollerentMasteryNew = PMM1103SlaveintToFloat(PMM1103SlaveOutputConfigrationArray[12], PMM1103SlaveOutputConfigrationArray[13]);
        float PMM1103TollerentMasterzNew = PMM1103SlaveintToFloat(PMM1103SlaveOutputConfigrationArray[14], PMM1103SlaveOutputConfigrationArray[15]);
        if (PMM1103SlaveFloatToFloat2Decimal(PMM1103TollerentMasterxNew) != PMM1103SlaveFloatToFloat2Decimal(PMM1103TollerentMasterx) ||
            PMM1103SlaveFloatToFloat2Decimal(PMM1103TollerentMasteryNew) != PMM1103SlaveFloatToFloat2Decimal(PMM1103TollerentMastery) ||
            PMM1103SlaveFloatToFloat2Decimal(PMM1103TollerentMasterzNew) != PMM1103SlaveFloatToFloat2Decimal(PMM1103TollerentMasterz))
        {
            Debugprintln("Save Tolerant Direction");

            PMM1103TollerentMasterx = PMM1103SlaveFloatToFloat2Decimal(PMM1103TollerentMasterxNew);
            PMM1103TollerentMastery = PMM1103SlaveFloatToFloat2Decimal(PMM1103TollerentMasteryNew);
            PMM1103TollerentMasterz = PMM1103SlaveFloatToFloat2Decimal(PMM1103TollerentMasterzNew);
            // Save The Settings In EEPROM || TODO
            PMMSetMasterTrackerInfo();
        }
    }
}
void PMM1103SlaveDirectionSetting()
{
    // Modbus Addresses ==>>> 4018 -8 // Data Type Is Float
    // Get Required Position
    bool saveDirectionSettings = PMM1103SlaveintToFloat(PMM1103SlaveOutputConfigrationArray[8], PMM1103SlaveOutputConfigrationArray[9]) == 1;
    PMM1103SlaveOutputConfigrationArray[8]=0;
    PMM1103SlaveOutputConfigrationArray[9]=0;
    if (saveDirectionSettings) // 4018 - 8
    {
        float PMM1103RequiredMasterxNew = PMM1103SlaveintToFloat(PMM1103SlaveOutputConfigrationArray[2], PMM1103SlaveOutputConfigrationArray[3]);
        float PMM1103RequiredMasteryNew = PMM1103SlaveintToFloat(PMM1103SlaveOutputConfigrationArray[4], PMM1103SlaveOutputConfigrationArray[5]);
        float PMM1103RequiredMasterzNew = PMM1103SlaveintToFloat(PMM1103SlaveOutputConfigrationArray[6], PMM1103SlaveOutputConfigrationArray[7]);
        bool xAxisChanged = PMM1103SlaveFloatToFloat2Decimal(PMM1103RequiredMasterxNew) != PMM1103SlaveFloatToFloat2Decimal(PMM1103RequiredMasterx);
        bool yAxisChanged = PMM1103SlaveFloatToFloat2Decimal(PMM1103RequiredMasteryNew) != PMM1103SlaveFloatToFloat2Decimal(PMM1103RequiredMastery);
        bool zAxisChanged = PMM1103SlaveFloatToFloat2Decimal(PMM1103RequiredMasterzNew) != PMM1103SlaveFloatToFloat2Decimal(PMM1103RequiredMasterz);
        if (yAxisChanged)
        {
            SerialUSB.println("Save Direction");
            PMM1103RequiredMasterx = PMM1103SlaveFloatToFloat2Decimal(PMM1103RequiredMasterxNew);
            PMM1103RequiredMastery = PMM1103SlaveFloatToFloat2Decimal(PMM1103RequiredMasteryNew);
            PMM1103RequiredMasterz = PMM1103SlaveFloatToFloat2Decimal(PMM1103RequiredMasterzNew);
            // SerialUSB.println(PMM1103RequiredMastery, 6);
            // SerialUSB.println(PMM1103RequiredMasteryNew, 6);
            // Save The Settings In EEPROM
            // PMMSetMasterTrackerInfo();
            PMM1103Reached = false;
            SerialUSB.println("Changed ..");
            SerialUSB.println(PMM1103RequiredMastery);
        }
    }
}
void PMM1103SlaveSaveMaxMinDegree()
{
    /**
     *  ==>> Save Tracking Limits [data type float]
     *     4062 , 4063 -> Max Limit Switch Value {Alarm if exceeded} || Output Array index 46 , 47
     *     4064 , 4065 -> Min Limit Switch Value {Alarm if exceeded} || Output Array index 48 , 49
     *     4066 , 4067 -> Max degree for Tracking || Output Array index 50 , 51
     *     4068 , 4069 -> Min degree for Tracking || Output Array index 52 , 53
     *     4070 , 4071 -> Save Settigns           || Output Array index 54 , 55
     */

    bool saveModeType = PMM1103SlaveintToFloat(PMM1103SlaveOutputConfigrationArray[54], PMM1103SlaveOutputConfigrationArray[55]) == 1;
    float PMM1103MaxLimitSwitchDegreeNew, PMM1103MinLimitSwitchDegreeNew, PMM1103MaxDegreeNew, PMM1103MinDegreeNew;
    if (saveModeType)
    {

        PMM1103MaxLimitSwitchDegreeNew = PMM1103SlaveintToFloat(PMM1103SlaveOutputConfigrationArray[46], PMM1103SlaveOutputConfigrationArray[47]);
        PMM1103MinLimitSwitchDegreeNew = PMM1103SlaveintToFloat(PMM1103SlaveOutputConfigrationArray[48], PMM1103SlaveOutputConfigrationArray[49]);
        PMM1103MaxDegreeNew = PMM1103SlaveintToFloat(PMM1103SlaveOutputConfigrationArray[50], PMM1103SlaveOutputConfigrationArray[51]);
        PMM1103MinDegreeNew = PMM1103SlaveintToFloat(PMM1103SlaveOutputConfigrationArray[52], PMM1103SlaveOutputConfigrationArray[53]);
        if (PMM1103SlaveFloatToFloat2Decimal(PMM1103MaxLimitSwitchDegreeNew) != PMM1103SlaveFloatToFloat2Decimal(PMM1103MaxLimitSwitchDegree) || PMM1103SlaveFloatToFloat2Decimal(PMM1103MinLimitSwitchDegreeNew) != PMM1103SlaveFloatToFloat2Decimal(PMM1103MinLimitSwitchDegree) ||
            PMM1103SlaveFloatToFloat2Decimal(PMM1103MaxDegreeNew) != PMM1103SlaveFloatToFloat2Decimal(PMM1103MaxDegree) || PMM1103SlaveFloatToFloat2Decimal(PMM1103MinDegreeNew) != PMM1103SlaveFloatToFloat2Decimal(PMM1103MinDegree))
        {
            SerialUSB.println("Save Max Min");

            PMM1103MaxLimitSwitchDegree = PMM1103SlaveFloatToFloat2Decimal(PMM1103MaxLimitSwitchDegreeNew);
            PMM1103MinLimitSwitchDegree = PMM1103SlaveFloatToFloat2Decimal(PMM1103MinLimitSwitchDegreeNew);
            PMM1103MaxDegree = PMM1103SlaveFloatToFloat2Decimal(PMM1103MaxDegreeNew);
            PMM1103MinDegree = PMM1103SlaveFloatToFloat2Decimal(PMM1103MinDegreeNew);
            PMMSetMasterTrackerInfo();
        }
    }
}

void PMM1103SlaveSaveTrakingEqation()
{
    /*  ==>> Save solar time settings [data type float]
     * 4072 , 4073    ->longitude                            || Output Array index 56 , 57
     * 4074 , 4075    ->Latitude                             || Output Array index 58 , 59
     * 4076 , 4077    ->time Zone                            || Output Array index 60 , 61
     * 4078 , 4079    ->save solar time correction parameq   || Output Array index 62 , 63
     */
    float PMM1103TimeZoneNew, PMM1103LongitudeNew, PMM1103LatitudeNew;
    bool save = PMM1103SlaveintToFloat(PMM1103SlaveOutputConfigrationArray[62], PMM1103SlaveOutputConfigrationArray[63]) == 1;
    if (save)
    {

        PMM1103LongitudeNew = PMM1103SlaveFloatToFloat2Decimal(PMM1103SlaveintToFloat(PMM1103SlaveOutputConfigrationArray[56], PMM1103SlaveOutputConfigrationArray[57]));
        PMM1103LatitudeNew = PMM1103SlaveFloatToFloat2Decimal(PMM1103SlaveintToFloat(PMM1103SlaveOutputConfigrationArray[58], PMM1103SlaveOutputConfigrationArray[59]));
        PMM1103TimeZoneNew = PMM1103SlaveFloatToFloat2Decimal(PMM1103SlaveintToFloat(PMM1103SlaveOutputConfigrationArray[60], PMM1103SlaveOutputConfigrationArray[61]));

        if (PMM1103TimeZoneNew != PMM1103TimeZone || PMM1103LongitudeNew != PMM1103Longitude || PMM1103LatitudeNew != PMM1103Latitude)
        {
            SerialUSB.println("Save Tracking Equation");

            PMM1103TimeZone = PMM1103TimeZoneNew;
            PMM1103Longitude = PMM1103LongitudeNew;
            PMM1103Latitude = PMM1103LatitudeNew;
            PMMSetMasterTrackerInfo();
        }
    }
}
void PMM1103SlaveSaveTime()
{
    // Modbus Addresses ==>>> 4034 -6 // Data Type Is Long
    bool saveTimeSettings =
        PMM1103SlaveintToLong(PMM1103SlaveOutputConfigrationArray[22], PMM1103SlaveOutputConfigrationArray[23]) == 1;

    uint32_t timeZone = 0, timeInUTC = 0;
    if (saveTimeSettings)
    { // 4034 - 6
        uint32_t timeInUTCNew = PMM1103SlaveintToLong(PMM1103SlaveOutputConfigrationArray[18], PMM1103SlaveOutputConfigrationArray[19]);
        uint32_t timeZoneNew = PMM1103SlaveintToLong(PMM1103SlaveOutputConfigrationArray[20], PMM1103SlaveOutputConfigrationArray[21]);
        if (timeZone != timeZoneNew || timeInUTCNew != timeInUTC)
        {
            timeInUTC = timeInUTCNew;
            timeZone = timeZoneNew;
            PMMRTCSETUNIXTime(timeInUTC + timeZone);
            PMMInternalRTCSETUNIXTime(timeInUTC + timeZone);
        }
    }
}
void PMM1103SlaveSensorCalibration()
{
    bool calibrateBNO055 = PMM1103SlaveintToFloat(PMM1103SlaveOutputConfigrationArray[24], PMM1103SlaveOutputConfigrationArray[25]) == 1;
    if (calibrateBNO055) // 4040 - 8
    {
        if (lastMPUUPdatedValue + 5000 < millis())
        {
            // SerialUSB.println("Calibrate MPU");
            SerialUSB.println("Slave Sensore Calibration");
            float xAxisCalibrateValue = PMM1103SlaveintToFloat(PMM1103SlaveOutputConfigrationArray[26], PMM1103SlaveOutputConfigrationArray[27]);
            float yAxisCalibrateValue = PMM1103SlaveintToFloat(PMM1103SlaveOutputConfigrationArray[28], PMM1103SlaveOutputConfigrationArray[29]);
            float zAxisCalibrateValue = PMM1103SlaveintToFloat(PMM1103SlaveOutputConfigrationArray[30], PMM1103SlaveOutputConfigrationArray[31]);
            PMMMPUCalibrate(xAxisCalibrateValue, yAxisCalibrateValue, zAxisCalibrateValue);
            PMMSetMasterTrackerInfo();
            lastMPUUPdatedValue = millis();
            // Remove Saved
            PMM1103SlaveOutputConfigrationArray[24] = 0;
            PMM1103SlaveOutputConfigrationArray[25] = 0;
        }
    }
}
long int timing = 0;
void PMM1103SlaveSaveMode()
{
    // Save Mode Type 4056 , 4057 , 4058 , 4059
    bool saveModeType = PMM1103SlaveintToFloat(PMM1103SlaveOutputConfigrationArray[42], PMM1103SlaveOutputConfigrationArray[43]) == 1;

    if (saveModeType)
    {
        uint8_t newMode = int(PMM1103SlaveintToFloat(PMM1103SlaveOutputConfigrationArray[40], PMM1103SlaveOutputConfigrationArray[41]));
        // Check if their is new Mode
        if (PMM1103ModeType != newMode)
        {
            SerialUSB.println("Save New Mode");

            PMM1103ModeType = newMode;
            PMMSetMasterTrackerInfo();
            PMM1103Reached = false;
        }
    }
}
void PMM1103SlaveChangeodbusSetting()
{
    // Save Slave id  4052 , 4053 , 4054 ,4055
    bool saveSlaveid =
        PMM1103SlaveintToFloat(PMM1103SlaveOutputConfigrationArray[38], PMM1103SlaveOutputConfigrationArray[39]) == 1;
    if (saveSlaveid)
    {
        uint8_t newSlaveId = int(PMM1103SlaveintToFloat(PMM1103SlaveOutputConfigrationArray[36], PMM1103SlaveOutputConfigrationArray[37]));
        if (slaveId.toInt() != newSlaveId)
        {
            SerialUSB.println("Save Slave ID");

            slaveId = String(newSlaveId);
            PMMSetModbusSeting();
        }
    }
}
void PMM1103SlaveSaveCommunicationTime()
{
    // Communication Time 4048 - 4051
    bool saveSettings =
        PMM1103SlaveintToFloat(PMM1103SlaveOutputConfigrationArray[34], PMM1103SlaveOutputConfigrationArray[35]) == 1;
    if (saveSettings)
    {
        float PMM1103MasterlostCommunicationTimeNew = PMM1103SlaveintToFloat(PMM1103SlaveOutputConfigrationArray[32], PMM1103SlaveOutputConfigrationArray[33]);
        if (PMM1103MasterlostCommunicationTimeNew != PMM1103MasterlostCommunicationTime)
        {
            SerialUSB.println("Save Communication");

            PMM1103MasterlostCommunicationTime = PMM1103MasterlostCommunicationTimeNew;
            PMMSetMasterTrackerInfo();
        }
    }
}

// ****************** Global Function
float PMM1103SlaveintToFloat(uint16_t value0, uint16_t value1)
{
    union
    {
        float valueAsFloat;
        uint16_t valueAsInt[2];
    } floatToInt;

    floatToInt.valueAsInt[1] = value0;
    floatToInt.valueAsInt[0] = value1;
    return floatToInt.valueAsFloat;
}
int32_t PMM1103SlaveintToLong(uint16_t value0, uint16_t value1)
{
    union
    {
        float valueAsFloat;
        int32_t valueAsLong;
        uint16_t valueAsInt[2];
    } floatToInt;

    floatToInt.valueAsInt[1] = value0;
    floatToInt.valueAsInt[0] = value1;
    return floatToInt.valueAsLong;
}
// ==== Convert Float to Float with 1 Decimal Point
float PMM1103SlaveFloatToFloat(float value)
{
    return float(int(value * 10) / 10.0);
}
float PMM1103SlaveFloatToFloat2Decimal(float value)
{
    return float(int(value * 100) / 100.0);
}
