#include <PMM1103DeviceLib/PMM1103SlaveDevice/PMM1103SlaveModbus/PMM1103SlaveModbus.h>

void PMMInitModbusRTU1103Slave(int slaveid)
{
    // Init Serial Settings
    // initialSerialPort(Serial, portOne.baudRate, portOne.dataBit, portOne.parity, portOne.stopBit, portOne.interface);
    Serial1.begin(9600,SERIAL_8E1);
    // Initalize Slave Device
    PMMRTUSlaveStartConfig(Serial1, 9600, slaveid, PMM1103SlaveSerialTwoSelect); // Other Serial info is set on line 37
    PMMInitRTUSlaveRegister(slaveid, 3, 4000, 80);
    // Init holding reg
    PMM1103SlaveInputHolding.holingArray = PMM1103SlaveAiArray1103;
    PMM1103SlaveInputHolding.startAddress = 4000;
    PMM1103SlaveInputHolding.quentity = 16;
    PMM1103SlaveInputHolding.read = true;
    PMM1103SlaveInputHolding.write = false;
    PMM1103SlaveInputHolding.outputValue = PMM1103SlaveInputArray;
    // Output holding reg
    PMM1103SlaveOutputHolding.outputValue = PMM1103SlaveOutputConfigrationArray;
    PMM1103SlaveOutputHolding.startAddress = 4016;
    PMM1103SlaveOutputHolding.quentity = 64;
    PMM1103SlaveOutputHolding.read = false;
    PMM1103SlaveOutputHolding.write = true;
    PMM1103SlaveOutputHolding.configMode = true;
}

void PMMInitModbusTracker(){

}

void PMMModbusRTU1103Slave()
{
}
