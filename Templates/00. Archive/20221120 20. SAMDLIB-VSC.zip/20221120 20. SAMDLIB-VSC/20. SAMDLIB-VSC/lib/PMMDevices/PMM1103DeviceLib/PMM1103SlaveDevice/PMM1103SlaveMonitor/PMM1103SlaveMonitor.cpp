#include <PMM1103DeviceLib/PMM1103SlaveDevice/PMM1103SlaveMonitor/PMM1103SlaveMonitor.h>
void PMM1103SlaveMonitorLoop()
{
    // ====
    // SerialUSB.println("In Monitoring ..");
    while (true)
    {
        // Read Data From USB
        if (SerialUSB.available() > 0)
        {
            // SerialUSB.setTimeout(200);
            String readData = SerialUSB.readString();
            if (readData == "PMMSetManual")
            {
                SerialUSB.println("PMMInManualMod");
                PMM1103SlaveAutoManualMonitor = true;
            }
            else if (readData == "PMMSetAuto")
            {
                SerialUSB.println("PMMInAutoMod");
                PMM1103SlaveAutoManualMonitor = false;
            }
            else if (readData == "PMMGoWest")
            {
                PMMPositining1103SlaveStartWestMovment();
            }
            else if (readData == "PMMStopWest")
            {
                PMMPositining1103SlaveStopWestMovment();
            }
            else if (readData == "PMMStartEast")
            {
                PMMPositining1103SlaveStartEastMovment();
            }
            else if (readData == "PMMStopEast")
            {
                PMMPositining1103SlaveStopEastMovment();
            }
            else if (readData == "PMMGetTimeAndPosition")
            {
                String data = String(PMM1103MasterTimeing) + "," + String(PMM1103Slavex) + "," + String(PMM1103RequiredMasterx) + "," + String(PMM1103TollerentMasterx) + "," + String(PMM1103Slavey) + "," + String(PMM1103RequiredMastery) + "," + String(PMM1103TollerentMastery) + "," + String(PMM1103Slavez) + "," + String(PMM1103RequiredMasterz) + "," + String(PMM1103TollerentMasterz) + ",";
                SerialUSB.println(data);
            }
            else if (readData == "PMMGetOutFromMonitor")
            {
                break;
            }
        }
    }
}
