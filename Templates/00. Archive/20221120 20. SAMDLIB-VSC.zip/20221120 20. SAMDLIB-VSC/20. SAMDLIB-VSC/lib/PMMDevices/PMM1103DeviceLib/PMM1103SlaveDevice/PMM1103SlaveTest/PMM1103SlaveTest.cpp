#include <PMM1103DeviceLib/PMM1103SlaveDevice/PMM1103SlaveTest/PMM1103SlaveTest.h>

void PMM1103SlaveTestLoop()
{
    SerialUSB.println("PMM1103SlaveInTest");
    while (true)
    {
        // Read Data From USB
        if (SerialUSB.available() > 0)
        {
            // SerialUSB.setTimeout(200);
            String readData = SerialUSB.readString();
            if (readData == "PMMRTCTest")
            {

                String sendDate = PMMRTCCheck() ? "found" : "notfound";
                SerialUSB.println(sendDate);
            }
            else if (readData == "PMM1103MPUTest")
            {
                String sendDate = PMMMPUCheck() ? "found" : "notfound";
                SerialUSB.println(sendDate);
            }
            else if (readData == "PMM1103EEPROMTest")
            {
                String sendDate = PMMEEPROMCheck() ? "found" : "notfound";
                SerialUSB.println(sendDate);
            }
            else if (readData == "PMM1103RelayOneON")
            {
                pinMode(PMM1103SlaveRelayOne, OUTPUT);
                digitalWrite(PMM1103SlaveRelayOne, HIGH);
            }
            else if (readData == "PMM1103RelayOneOFF")
            {
                pinMode(PMM1103SlaveRelayOne, OUTPUT);
                digitalWrite(PMM1103SlaveRelayOne, LOW);
            }
            else if (readData == "PMM1103RelayTwoON")
            {
                pinMode(PMM1103SlaveRelayTwo, OUTPUT);
                digitalWrite(PMM1103SlaveRelayTwo, HIGH);
            }
            else if (readData == "PMM1103RelayTwoOFF")
            {
                pinMode(PMM1103SlaveRelayTwo, OUTPUT);
                digitalWrite(PMM1103SlaveRelayTwo, LOW);
            }
            else if (readData == "PMM1103FanRelay")
            {
                // Test Fan Relay
            }
            else if (readData == "PMM1103RS485_2_Test")
            {
                // Send Data Over USB
                Serial1.begin(9600);
                pinMode(PMM1103SlaveSerialTwoSelect, OUTPUT);
                digitalWrite(PMM1103SlaveSerialTwoSelect, HIGH);
                Serial1.println("PMM1103RS485_2_Test");
                delay(30);
                digitalWrite(PMM1103SlaveSerialTwoSelect, LOW);
                for (byte i = 0; i < 250; i++)
                {
                    if (Serial1.available() > 0)
                    {
                        String readData = Serial1.readString();
                        SerialUSB.println(readData);
                        break;
                    }
                    delay(50);
                }
            }
            else if (readData == "PMM1103SlaveOut")
            {
                SerialUSB.println("Out");
                break;
            }
        }
    }
}