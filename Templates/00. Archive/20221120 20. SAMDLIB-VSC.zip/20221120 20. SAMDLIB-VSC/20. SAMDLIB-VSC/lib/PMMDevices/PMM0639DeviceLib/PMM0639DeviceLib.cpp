#include <PMM0639DeviceLib/PMM0639DeviceLib.h>
extern struct AI aiArray[8];
extern struct AO aoArray[4];
// uint16_t modbusAO[8];

extern modBusCoils PMMInputCoilModbus;
extern modBusCoils PMMOutputCoilModbus;
extern modBusHolding PMMInputHolding;
extern modBusHolding PMMOutputHolding;
bool outputArrayBool0639[2];
bool inputArrayBool0639[2];
uint8_t outputArrayPins0639[2] = {A0, 25};
uint8_t inputArrayPins0639[2] = {8, 9};
void PMMInitalize0639()
{
    Debugprintln("0639 Device");
    // Configure Ai Pins
    // Configure more Ai Source ::https://forum.arduino.cc/t/arduino-zero-additional-analog-inputs/350356/5
    aiArray[0].pinNumber = A1;
    aiArray[1].pinNumber = A2;
    aiArray[2].pinNumber = A3;
    aiArray[3].pinNumber = A4;
    // Anitalize Ai
    for (uint8_t i = 0; i < 4; i++)
        // clear analogValues arrays
        memset(aiArray[i].analogValues, 0, 10 * sizeof(int16_t));
    ReadHoldingRegStartAddress = "4001";
    // Init holding reg
    PMMInputHolding.holingArray = aiArray;
    PMMInputHolding.startAddress = ReadHoldingRegStartAddress.toInt();
    PMMInputHolding.quentity = 4;
    PMMInputHolding.read = true;
    PMMInputHolding.write = false;
    // Output
    PMMOutputHolding.startAddress = ReadHoldingRegStartAddress.toInt() + 4;
    PMMOutputHolding.quentity = 4;
    PMMOutputHolding.read = false;
    PMMOutputHolding.write = true;
    // Output
    PMMInputCoilModbus.startAddress = 0;
    PMMInputCoilModbus.quentity = 2;
    PMMInputCoilModbus.read = true;
    PMMInputCoilModbus.write = false;
    PMMInputCoilModbus.boolArrayCurrent = inputArrayBool0639;
    // Configure Output Array
    PMMOutputCoilModbus.startAddress = 2;
    PMMOutputCoilModbus.quentity = 2;
    PMMOutputCoilModbus.read = false;
    PMMOutputCoilModbus.write = true;
    PMMOutputCoilModbus.boolArrayCurrent = outputArrayBool0639;

    // PMMOutputHolding.outputValue = modbusAO;
    // Init AD7411
    PMMAD7441.cs = 11;
    PMMAD7441.alertFlage = 3;
    PMMAD7441.rst = 1;
    PMMAD7441.ready = 4;
    PMMAD7441.EthCS = 10;

    pinMode(11, OUTPUT);
    digitalWrite(11, HIGH);
    initalizeEthernet();
    // Initalize WebServer
    if (webPageConfugration)
        PMMInitWebServer();
    initialSerialPort(Serial, portOne.baudRate, portOne.dataBit, portOne.parity, portOne.stopBit, portOne.interface);
    // Init PMMAD74412R
    PMMAD74412RInit(PMMAD7441);
    // 0 => TCP Slave , 1 => RTU Slave
    // Start in TCP Testing
    if (TCPORRTU == "0")
    { // TCP Slave
        initModBusTCP(slaveId.toInt());
        PMMInitRegister(1, 3, PMMInputHolding.startAddress, 16);
    }
    else if (TCPORRTU == "1")
    {
        Debugprintln("RTUSlave");                              // RTU Slave
        PMMRTUSlaveStartConfig(Serial, 9600, slaveId.toInt()); // Other Serial info is set on line 37
        PMMInitRTUSlaveRegister(1, 3, PMMInputHolding.startAddress, 16);
    }
}
void PMM0639Loop()
{
    // PMMAD74412AnalogWrite(PMMAD7441, aoArray, 2);
    // DigitalReadPins(inputArrayPins0639, PMMInputCoilModbus);
    // DigitalOutputWrite(outputArrayPins0639, PMMOutputCoilModbus);
    // if (TCPORRTU == "0") // TCP Slave
    //     PMMTCPSlaveLoop(1, PMMOutputCoilModbus, PMMInputCoilModbus, PMMOutputHolding, PMMInputHolding);
    // else if (TCPORRTU == "1") // RTU Slave
    //     PMMRTUSlaveLoop(1, PMMOutputCoilModbus, PMMInputCoilModbus, PMMOutputHolding, PMMInputHolding);
}