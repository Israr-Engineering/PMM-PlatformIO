#ifndef PMM0639DeviceLib
#define PMM0639DeviceLib
#include <Arduino.h>
#include <projectConfigration.h>
#include <PMMWebController/PMMWebController.h>
#include <PMMTCPServer/PMMTCPServer.h>
#include <PMMRTUSlave/modbusRTUWrappper.h>
#include <PMMModbusGateWay/PMMModbusGateWay.h>
#include <PMMEEPROMSerialParam/PMMEEPROMSerialParam.h>
#include <PMMUDPLib/PMMUDPLib.h>
#include <PMMEEPROMAuth/PMMEEPROMAuth.h>
#include <PMM74412R/PMM74412R.h>
extern struct AD7441 PMMAD7441;
extern bool webPageConfugration;
void PMMInitalize0639();
void PMM0639Loop();


#endif