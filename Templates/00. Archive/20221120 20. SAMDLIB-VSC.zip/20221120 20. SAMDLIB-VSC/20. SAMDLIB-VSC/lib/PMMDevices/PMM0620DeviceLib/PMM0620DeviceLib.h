#ifndef PMM0620DeviceLib
#define PMM0620DeviceLib
#include <Arduino.h>
#include <projectConfigration.h>
#include <PMMWebController/PMMWebController.h>
#include <PMMTCPServer/PMMTCPServer.h>
#include <PMMRTUSlave/modbusRTUWrappper.h>
#include <PMMModbusGateWay/PMMModbusGateWay.h>
#include <PMMEEPROMSerialParam/PMMEEPROMSerialParam.h>
#include <PMMUDPLib/PMMUDPLib.h>
#include <PMMEEPROMAuth/PMMEEPROMAuth.h>
#include <PMMIOLib/PMMIOLib.h>
extern bool webPageConfugration;
extern String slaveId;

extern String ReadCoilsStartAddress;
extern String ReadCoilsQuintity;
extern String  TCPORRTU;

extern modBusCoils PMMInputCoilModbus;
extern modBusCoils PMMOutputCoilModbus;
extern modBusHolding PMMInputHolding;
extern modBusHolding PMMOutputHolding;
void PMM0620Loop();
void PMMInitalize0620();
#endif