#include <PMM0620DeviceLib/PMM0620DeviceLib.h>

/***
 * The next step IO page send request handel it
 *
 *
 */

bool forcedArray0620[12] = {false};
bool forcedValue0620[12] = {false};
bool boolArrayCurrent0620[12] = {false};
bool boolArrayt0620[12] = {false};
uint8_t inputPins[12] = {18, 8, 9, 4, 3, 1, 0, 38, 6, 7, A5, 25};
void PMMInitalize0620()
{
    Debugprintln("0620 Device");
    // Congigure Inputs
    PMMInputCoilModbus.startAddress = ReadCoilsStartAddress.toInt();
    PMMInputCoilModbus.quentity = 12;
    PMMInputCoilModbus.read = true;
    PMMInputCoilModbus.write = false;
    PMMInputCoilModbus.boolArray = boolArrayt0620;
    PMMInputCoilModbus.boolArrayCurrent = boolArrayCurrent0620;
    PMMInputCoilModbus.forcedArray = forcedArray0620;
    PMMInputCoilModbus.forcedValue = forcedValue0620;
    DIPullUpSetup(12, inputPins);
    initalizeEthernet();
    // Initalize WebServer
    if (webPageConfugration)
        PMMInitWebServer();
    initialSerialPort(Serial, portOne.baudRate, portOne.dataBit, portOne.parity, portOne.stopBit, portOne.interface);
    // 0 => TCP Slave , 1 => RTU Slave
    // Start in TCP Testing
    TCPORRTU="1"; // Test Only
    if (TCPORRTU == "0")
    { // TCP Slave
        Debugprintln("TCP Slave");
        initModBusTCP(1);
        PMMInitRegister(1, slaveId.toInt(), ReadCoilsStartAddress.toInt(), 12);
    }
    else if (TCPORRTU == "1")
    {
        Debugprintln("RTUSlave");                              // RTU Slave
        PMMRTUSlaveStartConfig(Serial, 9600, slaveId.toInt()); // Other Serial info is set on line 37
        PMMInitRTUSlaveRegister(1, 1/*slaveId.toInt()*/,0/* ReadCoilsStartAddress.toInt()*/, 12);
    }

    Debugprintln("0620 Device Configured");
}
void PMM0620Loop()
{
    DigitalPullUPReadPins(inputPins, PMMInputCoilModbus);
    if (TCPORRTU == "0")
        PMMTCPSlaveLoop(1, PMMOutputCoilModbus, PMMInputCoilModbus, PMMOutputHolding, PMMInputHolding);
    else if (TCPORRTU == "1")
        PMMRTUSlaveLoop(1, PMMOutputCoilModbus, PMMInputCoilModbus, PMMOutputHolding, PMMInputHolding);
}