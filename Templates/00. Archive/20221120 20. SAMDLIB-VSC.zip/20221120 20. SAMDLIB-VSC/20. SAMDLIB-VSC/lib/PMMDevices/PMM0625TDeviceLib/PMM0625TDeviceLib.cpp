#include <PMM0625TDeviceLib/PMM0625TDeviceLib.h>
bool forcedArray0625T[8] = {false};
bool forcedValue0625T[8] = {false};
bool boolArrayCurrent0625T[8] = {false};
bool boolArrayt0625T[8] = {false};
uint8_t outputPins[8] = {9, 8, 3, 4, A5, A3, A2, A1};
void PMMInitalize0625T()
{
    if (PMM0626RDevice)
    {
        Debugprintln("0626R Device");
        outputPins[0] = 8;
        outputPins[1] = 9;
        outputPins[2] = 1;
        outputPins[3] = 3;
        outputPins[4] = A1;
        outputPins[5] = A2;
        outputPins[6] = A3;
        outputPins[7] = A4;
    }
    else if (PMM0625TDevice)
    {
        outputPins[4] = A4;
        Debugprintln("0625T Device");
    }
    else if (PMM0627Device)
    {
        Debugprintln("0627 Device");
        outputPins[0] = A2;
        outputPins[1] = A1;
        outputPins[2] = A4;
        outputPins[3] = A3;
        outputPins[4] = 9;
        outputPins[5] = 8;
        outputPins[6] = 3;
        outputPins[7] = 4;
        // outputPins[4] = A4;
      
    }
    // Congigure Inputs
    PMMOutputCoilModbus.startAddress = 0;
    PMMOutputCoilModbus.quentity = 8;
    PMMOutputCoilModbus.read = false;
    PMMOutputCoilModbus.write = true;
    PMMOutputCoilModbus.boolArray = boolArrayt0625T;
    PMMOutputCoilModbus.boolArrayCurrent = boolArrayCurrent0625T;
    PMMOutputCoilModbus.forcedArray = forcedArray0625T;
    PMMOutputCoilModbus.forcedValue = forcedValue0625T;
    PMMOutputCoilModbus.startAddress = WriteCoilsStartAddress.toInt();
    initalizeEthernet();
    DOSetup(8, outputPins);
    // Initalize WebServer
    if (webPageConfugration)
        PMMInitWebServer();
    initialSerialPort(Serial, portOne.baudRate, portOne.dataBit, portOne.parity, portOne.stopBit, portOne.interface);
    // 0 => TCP Slave , 1 => RTU Slave
    // Start in TCP Testing
    if (TCPORRTU == "0")
    { // TCP Slave
        Debugprintln("TCP Slave");
        initModBusTCP(1);
        PMMInitRegister(slaveId.toInt(), 1, PMMOutputCoilModbus.startAddress, 8);
    }
    else if (TCPORRTU == "1")
    {
        Debugprintln("RTUSlave");                              // RTU Slave
        PMMRTUSlaveStartConfig(Serial, 9600, slaveId.toInt()); // Other Serial info is set on line 37
        PMMInitRTUSlaveRegister(slaveId.toInt(), 1, PMMOutputCoilModbus.startAddress, 8);
    }
    Debugprintln("0625T Device Configured");
}
void PMM0625TLoop()
{
    DigitalOutputWrite(outputPins, PMMOutputCoilModbus);
    if (TCPORRTU == "0")
        PMMTCPSlaveLoop(slaveId.toInt(), PMMOutputCoilModbus, PMMInputCoilModbus, PMMOutputHolding, PMMInputHolding);
    else if (TCPORRTU == "1")
        PMMRTUSlaveLoop(slaveId.toInt(), PMMOutputCoilModbus, PMMInputCoilModbus, PMMOutputHolding, PMMInputHolding);
}
