#ifndef PMM0625TDeviceLib
#define PMM0625TDeviceLib
#include <Arduino.h>
#include <projectConfigration.h>
#include <PMMWebController/PMMWebController.h>
#include <PMMTCPServer/PMMTCPServer.h>
#include <PMMRTUSlave/modbusRTUWrappper.h>
#include <PMMModbusGateWay/PMMModbusGateWay.h>
#include <PMMEEPROMSerialParam/PMMEEPROMSerialParam.h>
#include <PMMUDPLib/PMMUDPLib.h>
#include <PMMEEPROMAuth/PMMEEPROMAuth.h>
#include <PMMIOLib/PMMIOLib.h>

extern bool webPageConfugration;
extern String slaveId;
extern String WriteCoilsStartAddress;
extern String WriteCoilsQuintity;
extern String TCPORRTU;
extern modBusCoils PMMInputCoilModbus;
extern modBusCoils PMMOutputCoilModbus;
extern modBusHolding PMMInputHolding;
extern modBusHolding PMMOutputHolding;
extern bool PMM0626RDevice;
extern bool PMM0625TDevice;
extern bool PMM0627Device;

void PMMInitalize0625T();
void PMM0625TLoop();
#endif