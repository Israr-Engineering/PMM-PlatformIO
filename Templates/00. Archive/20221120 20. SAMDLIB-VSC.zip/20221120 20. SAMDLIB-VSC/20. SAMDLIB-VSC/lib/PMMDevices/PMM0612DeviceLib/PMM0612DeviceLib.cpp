#include <PMM0612DeviceLib/PMM0612DeviceLib.h>
void PMMInitalize0612()
{
    // Get Settings
    bridgeOrModBus = ModbusOrUDP == "0" ? true : false;
    // Initalize Ethernet
    initalizeEthernet();
    // Initalize WebServer
    if (webPageConfugration)
        PMMInitWebServer();
    // Initalize Serial Port
    initialSerialPort(Serial, portOne.baudRate, portOne.dataBit, portOne.parity, portOne.stopBit, portOne.interface);
    Serial.setTimeout(10);
    // UDP Bridge Mode
    PMMUDPInit(Udp, UDPPort.toInt()); // UDP Port 1
    Debugprintln("UDP Bridge Mode");
}
