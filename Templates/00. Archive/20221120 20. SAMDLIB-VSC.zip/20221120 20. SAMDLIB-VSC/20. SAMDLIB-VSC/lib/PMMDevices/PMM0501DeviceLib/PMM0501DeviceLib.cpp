#include <PMM0501DeviceLib/PMM0501DeviceLib.h>
void PMMInitalize0501()
{
    // Get Settings
    bridgeOrModBus = ModbusOrUDP == "0" ? true : false;
    // Initalize Ethernet
    // Test Only as 0406
    // EthernetCS = 6;
    // Test Only as 0406

    initalizeEthernet();
    // Initalize WebServer
    // if (webPageConfugration)
    // PMMInitWebServer();
    // Initalize Serial Port
    initialSerialPort(Serial, portOne.baudRate, portOne.dataBit, portOne.parity, portOne.stopBit, portOne.interface);
    initialSerialPort(Serial1, portTwo.baudRate, portTwo.dataBit, portTwo.parity, portTwo.stopBit, portTwo.interface);
    // pinMode(9, OUTPUT);
    // Bridge Mode Or Converter
    if (bridgeOrModBus)
    {
        PMMGateWayinitalize();
        Debugprintln("ModBus Bridge Mode");
    }
    else
    {
        PMMUDPInit(Udp, UDPPort.toInt());   // UDP Port 1
        PMMUDPInit(Udp2, UDPPort2.toInt()); // UDP Port 2
        Debugprintln("UDP Bridge Mode");
    }
}