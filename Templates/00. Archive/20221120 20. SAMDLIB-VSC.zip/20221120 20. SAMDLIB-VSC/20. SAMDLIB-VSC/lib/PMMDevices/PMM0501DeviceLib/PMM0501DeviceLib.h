#ifndef PMM0501DeviceLib
#define PMM0501DeviceLib
#include <Arduino.h>
#include <projectConfigration.h>
#include <PMMWebController/PMMWebController.h>
#include <PMMTCPServer/PMMTCPServer.h>
#include <PMMRTUSlave/modbusRTUWrappper.h>
#include <PMMModbusGateWay/PMMModbusGateWay.h>
#include <PMMEEPROMSerialParam/PMMEEPROMSerialParam.h>
#include <PMMUDPLib/PMMUDPLib.h>
#include <PMMEEPROMAuth/PMMEEPROMAuth.h>

extern bool webPageConfugration;
extern SerialParameter portOne;
extern SerialParameter portTwo;
// UDP Parameter
extern String remoteIPAddress;
extern String UDPPort;
extern EthernetUDP Udp;
extern EthernetUDP Udp2;
extern bool bridgeOrModBus;

void PMMInitalize0501();

#endif