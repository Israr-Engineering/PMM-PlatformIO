#ifndef PMM0630DeviceLib
#define PMM0630DeviceLib
#include <Arduino.h>
#include <projectConfigration.h>
#include <PMMWebController/PMMWebController.h>
#include <PMMTCPServer/PMMTCPServer.h>
#include <PMMRTUSlave/modbusRTUWrappper.h>
#include <PMMModbusGateWay/PMMModbusGateWay.h>
#include <PMMEEPROMSerialParam/PMMEEPROMSerialParam.h>
#include <PMMUDPLib/PMMUDPLib.h>
#include <PMMEEPROMAuth/PMMEEPROMAuth.h>
#include <PMMADS8688/PMMADS8688.h>
// #include <ADS8688.h>


void PMMInitalize0630();
void PMM0630Loop();
// void analogReadCalibratoin(struct AI *ai, uint8_t quentity);
extern bool webPageConfugration;
extern String slaveId;
extern String ReadHoldingRegStartAddress;
extern String ReadHoldingRegQuintity;
#endif