#include <PMM0630DeviceLib/PMM0630DeviceLib.h>

extern struct AI aiArray[8];

extern modBusCoils PMMInputCoilModbus;
extern modBusCoils PMMOutputCoilModbus;
extern modBusHolding PMMInputHolding;
extern modBusHolding PMMOutputHolding;

void PMMInitalize0630()
{
    Debugprintln("0630 Device");
    // Configure Ai Pins
    // Configure more Ai Source ::https://forum.arduino.cc/t/arduino-zero-additional-analog-inputs/350356/5
    // Anitalize Ai
    for (uint8_t i = 0; i < 8; i++)
        // clear analogValues arrays
        memset(aiArray[i].analogValues, 0, 10 * sizeof(int16_t));
    // Init holding reg
    PMMInputHolding.holingArray = aiArray;
    PMMInputHolding.startAddress = ReadHoldingRegStartAddress.toInt();
    PMMInputHolding.quentity = 16;
    PMMInputHolding.read = true;
    PMMInputHolding.write = false;
    // Init ADS
    PMMInitADS8688();
    initalizeEthernet();
    // Initalize WebServer
    if (webPageConfugration)
        PMMInitWebServer();
    initialSerialPort(Serial, portOne.baudRate, portOne.dataBit, portOne.parity, portOne.stopBit, portOne.interface);
    SerialUSB.println();
    // 0 => TCP Slave , 1 => RTU Slave
    // Start in TCP Testing
    if (TCPORRTU == "0")
    { // TCP Slave
        initModBusTCP(1);
        PMMInitRegister(1, 3, 0, 16);
    }
    else if (TCPORRTU == "1")
    {
        Debugprintln("RTUSlave");                // RTU Slave
        PMMRTUSlaveStartConfig(Serial, 9600, 1); // Other Serial info is set on line 37
        PMMInitRTUSlaveRegister(1, 3, ReadHoldingRegStartAddress.toInt(), 16);
    }
}

void PMM0630Loop()
{
    // PMMADS8688Read(aiArray, 10);
    // delay(1000);

    //     if (TCPORRTU == "0") // TCP Slave
    //         PMMTCPSlaveLoop(1, PMMInputCoilModbus, PMMOutputCoilModbus, PMMInputHolding, PMMOutputHolding);
    //     else if (TCPORRTU == "1") // RTU Slave
    //         PMMRTUSlaveLoop(1, PMMInputCoilModbus, PMMOutputCoilModbus, PMMInputHolding, PMMOutputHolding);
}
