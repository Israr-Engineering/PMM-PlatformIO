#ifndef PMM0613DeviceLib
#define PMM0613DeviceLib

#include <Arduino.h>

#include <projectConfigration.h>
#include <PMMWebController/PMMWebController.h>
#include <PMMTCPServer/PMMTCPServer.h>
#include <PMMRTUSlave/modbusRTUWrappper.h>
#include <PMMModbusGateWay/PMMModbusGateWay.h>
#include <PMMEEPROMSerialParam/PMMEEPROMSerialParam.h>
#include <PMMUDPLib/PMMUDPLib.h>
#include <PMMEEPROMAuth/PMMEEPROMAuth.h>
#include <PID_v1.h>
#include <PMM74412R/PMM74412R.h>

extern struct PIDArray pidArray[4];
extern bool webPageConfugration;
extern SerialParameter portOne;
// UDP Parameter
extern String remoteIPAddress;
extern String UDPPort;
extern EthernetUDP Udp;

extern bool bridgeOrModBus;

void PMMInitalize0613();
void PMMLoop0613();
extern bool webPageConfugration;
extern String slaveId;
extern String ReadHoldingRegStartAddress;
extern String ReadHoldingRegQuintity;
extern modBusCoils PMMInputCoilModbus;
extern modBusCoils PMMOutputCoilModbus;
extern modBusHolding PMMInputHolding;
extern modBusHolding PMMOutputHolding;
extern struct AD7441 PMMAD7441;
extern uint16_t modbusAO[8];
#endif
