#include <PMM0613DeviceLib/PMM0613DeviceLib.h>
extern struct AI aiArray[8];
extern struct AO aoArray[4];
extern modBusCoils PMMInputCoilModbus;
extern modBusCoils PMMOutputCoilModbus;
extern modBusHolding PMMInputHolding;
extern modBusHolding PMMOutputHolding;

#define PIN_INPUT A1
#define PIN_OUTPUT 3
// Define Variables we'll be connecting to
double Setpoint, Input, Output;

// Specify the links and initial tuning parameters
double Kp = 2, Ki = 5, Kd = 1;
PID myPID(&Input, &Output, &Setpoint, Kp, Ki, Kd, DIRECT);
void PMMInitalize0613()
{
    Debugprintln("0613 Device");
    // Configure Ai Pins
    // Configure more Ai Source ::https://forum.arduino.cc/t/arduino-zero-additional-analog-inputs/350356/5
    aiArray[0].pinNumber = A1;
    aiArray[1].pinNumber = A2;
    aiArray[2].pinNumber = A3;
    aiArray[3].pinNumber = A4;
    // Anitalize Ai
    for (uint8_t i = 0; i < 4; i++)
        // clear analogValues arrays
        memset(aiArray[i].analogValues, 0, 10 * sizeof(int16_t));
    // Init holding reg
    PMMInputHolding.holingArray = aiArray;
    PMMInputHolding.startAddress = ReadHoldingRegStartAddress.toInt();
    PMMInputHolding.quentity = 8;
    PMMInputHolding.read = true;
    PMMInputHolding.write = false;
    // Output
    PMMOutputHolding.startAddress = WriteHoldingRegStartAddress.toInt() + 8;
    PMMOutputHolding.quentity = 8;
    PMMOutputHolding.read = false;
    PMMOutputHolding.write = true;
    PMMOutputHolding.outputValue = modbusAO;
    // Init AD7411
    PMMAD7441.cs = 11;
    PMMAD7441.alertFlage = 3;
    PMMAD7441.rst = 1;
    PMMAD7441.ready = 4;
    PMMAD7441.EthCS = 10;
    // PID Init
    pidArray[0].obj.initPid(&pidArray[0].input,&pidArray[0].output,&pidArray[0].setPoint,pidArray[0].kp,pidArray[0].ki,pidArray[0].kp,DIRECT);
    pidArray[1].obj.initPid(&pidArray[1].input,&pidArray[1].output,&pidArray[1].setPoint,pidArray[1].kp,pidArray[1].ki,pidArray[1].kp,DIRECT);
    pidArray[2].obj.initPid(&pidArray[2].input,&pidArray[2].output,&pidArray[2].setPoint,pidArray[2].kp,pidArray[2].ki,pidArray[2].kp,DIRECT);
    pidArray[3].obj.initPid(&pidArray[3].input,&pidArray[3].output,&pidArray[3].setPoint,pidArray[3].kp,pidArray[3].ki,pidArray[3].kp,DIRECT);

    pinMode(11, OUTPUT);
    digitalWrite(11, HIGH);
    initalizeEthernet();
    // Initalize WebServer
    if (webPageConfugration)
        PMMInitWebServer();
    initialSerialPort(Serial, portOne.baudRate, portOne.dataBit, portOne.parity, portOne.stopBit, portOne.interface);
    // Init PMMAD74412R
    PMMAD74412RInit(PMMAD7441);
    // 0 => TCP Slave , 1 => RTU Slave
    // Start in TCP Testing
    if (TCPORRTU == "0")
    { // TCP Slave
        initModBusTCP(slaveId.toInt());
        PMMInitRegister(1, 3, PMMInputHolding.startAddress, 16);
    }
    else if (TCPORRTU == "1")
    {
        Debugprintln("RTUSlave");                              // RTU Slave
        PMMRTUSlaveStartConfig(Serial, 9600, slaveId.toInt()); // Other Serial info is set on line 37
        PMMInitRTUSlaveRegister(1, 3, PMMInputHolding.startAddress, 16);
    }
    // Input = analogRead(PIN_INPUT);
    // Setpoint = 100;
    // myPID.SetMode(AUTOMATIC); // turn the PID on
}
void PMMLoop0613()
{
    // Input = analogRead(PIN_INPUT);
    // myPID.Compute();
    // SerialUSB.println(Output);
    // delay(1000);

    // Check the Website Reading
    // PMMAD74412AnalogWrite(PMMAD7441, aoArray, 4);
    // PMMModbusToAnalogOutput(modbusAO, aoArray);
    // PMMAnalogReadCalibratoin(aiArray, 4);
    // if (TCPORRTU == "0") // TCP Slave
    //     PMMTCPSlaveLoop(1, PMMOutputCoilModbus, PMMInputCoilModbus, PMMOutputHolding, PMMInputHolding);
    // else if (TCPORRTU == "1") // RTU Slave
    //     PMMRTUSlaveLoop(1, PMMOutputCoilModbus, PMMInputCoilModbus, PMMOutputHolding, PMMInputHolding);
}