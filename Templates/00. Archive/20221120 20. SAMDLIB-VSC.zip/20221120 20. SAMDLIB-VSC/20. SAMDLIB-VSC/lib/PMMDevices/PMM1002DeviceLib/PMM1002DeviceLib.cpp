#include <PMM1002DeviceLib/PMM1002DeviceLib.h>

/**
 * Todo :
 *  - Edit Webserver
 *  - UDP Communication
 *  - GSM
 *  - Alarm Buttons
 */
unsigned long  SendTime1002 = 0;
unsigned long communicationTime1002 = 0;

// Serial Mirror Buffer
char rcvMirrorBuffer1002[UDP_TX_PACKET_MAX_SIZE];
// Analog Switch Pins
struct AnalogSwitch analogSwitchOne1002;
struct Multiplexer multiplexer1002;
// Modbus Configration
struct modBusCoils inputCoilModbus1002;
struct modBusCoils outputCoilModbus1002;
struct modBusHolding inputHolding1002;
struct modBusHolding outputHolding1002;
bool analogSwitchOneInputResult1002[16]; // Save the Result of reading the input
// map the number of input with Which pin on the analog switch
// From 0-8 => Dip Switch & From 9-15 => is input from 1 - 7 {Note that the input is inverted due to optocoupler}
uint8_t analogSwitchOneInputOrder1002[16] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 15, 14, 13, 12, 11, 10, 9};
// map the number of input with Which pin on the analog switch
bool analogSwitchTwoInputResult1002[16]; // Save the Result of reading the input
// in the analogSwitchTwoInputResult index zero represent input 8 and index one represent input 9 etc .. , index 13 represtent alarm led
// analogSwitchTwoInputOrder : re arrange the bits so index zero is the input one || use this in the Rading loops
uint8_t analogSwitchTwoInputOrder1002[16] = {8, 7, 6, 5, 4, 3, 2, 1, 13, 0, 0, 0, 0, 0, 0, 0};
// HC595 outputArray;
HC595 OUTPUTArray1002;
bool outputArrayBool1002[16];
bool outputArrayTarget1002[16];
// Output From 1-16  is the Output / Not Used /Intrrupt/ Ethernet rst {Low to rst ethernet} / Ethern control{Relay}
bool outputArrayOutputOrder1002[32] = {15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, 16, 17, 18};
bool testArrayLow1002[32] = {
    HIGH, HIGH, HIGH, HIGH, HIGH, HIGH, HIGH, HIGH,
    LOW, LOW, HIGH, LOW, LOW, LOW, LOW, LOW, LOW,
    LOW, HIGH, LOW, LOW, LOW, LOW, LOW, HIGH,
    HIGH, HIGH, HIGH, HIGH, HIGH, HIGH, HIGH};
bool modbusOutputArray1002[16];
bool modbusInputArray1002[16] = {
    false,
    false,
    false,
    false,
    false,
    false,
    false,
    false,
    false,
    false,
    false,
    false,
    false,
    false,
    false,
    false,
};
// Just For Test purbose
// int devicetype0102 = 3;
void PMMInitalize1002()
{
    Debugprintln("0102 Device");

    // Initalize Analog Switches
    analogSwitchOne1002.dataPin = A2;
    analogSwitchOne1002.S0 = A1;
    analogSwitchOne1002.S1 = 7;
    analogSwitchOne1002.S2 = 6;
    analogSwitchOne1002.S3 = A4;
    analogSwitchOne1002.inputCount = 16;

    // Initalize Multiplexer
    multiplexer1002.numberOfChip = 4;
    multiplexer1002.numberOfOutput = 32;
    multiplexer1002.SERIn = 8;
    multiplexer1002.SRCLK = A5;
    multiplexer1002.RCLK = 9;
    multiplexer1002.SRCLKInv = A0;
    // Inetalize Modbus Variable
    // Configure input
    inputCoilModbus1002.startAddress = 8;
    inputCoilModbus1002.quentity = 8;
    inputCoilModbus1002.read = true;
    inputCoilModbus1002.write = false;
    inputCoilModbus1002.boolArrayCurrent = modbusInputArray1002;
    // Configure Output Array
    outputCoilModbus1002.startAddress = 0;
    outputCoilModbus1002.quentity = 8;
    outputCoilModbus1002.read = false;
    outputCoilModbus1002.write = true;
    outputCoilModbus1002.boolArrayCurrent = outputArrayBool1002;

    analogSwitchSetup(analogSwitchOne1002);
    multiplexerSetup(multiplexer1002, OUTPUTArray1002);
    // Enable Ethernet
    multiplexerOutput(multiplexer1002, OUTPUTArray1002, 0, 24, testArrayLow1002);
    initalizeEthernet();
    // Initalize WebServer
    if (webPageConfugration)
        PMMInitWebServer();
    // Initalize Serial Port
    initialSerialPort(Serial, portOne.baudRate, portOne.dataBit, portOne.parity, portOne.stopBit, portOne.interface);
    // Sel Mode {Their are four  Type TCP  , UDP Mirror, Serial  }
    // For Testing purpose we will specifay value for the device mode
    // 0 => TCP Slave , 1 => RTU Slave , 2 => UDP Mirrot
    // Start in TCP Testing
    if (selOperation == "TCPSlave")
    { // TCP Slave
        initModBusTCP(1);
        PMMInitRegister(1, 1, 0, 16);
    }
    else if (selOperation == "RTUSlave")
    {
        // RTU Slave
        PMMRTUSlaveStartConfig(Serial, 9600, 1); // Other Serial info is set on line 106
        PMMInitRTUSlaveRegister(1, 1, 0, 16);
    }
    else if (selOperation == "FiberMirror")
    { // UDP Mirror
        PMMUDPInit(Udp, 91);
    }
}
void PMM1002Loop()
{
    // Update Modbus
    if (selOperation == "TCPSlave")
        PMMTCPSlaveLoop(1, outputCoilModbus1002, inputCoilModbus1002, outputHolding1002, inputHolding1002);
    else if (selOperation == "RTUSlave")
        PMMRTUSlaveLoop(1, outputCoilModbus1002, inputCoilModbus1002, outputHolding1002, inputHolding1002);
    else if (selOperation == "FiberMirror")
        PMMUDPMirror02(outputCoilModbus1002, inputCoilModbus1002);
    else if (selOperation == "SerialMirror")
        PMMSerialMirror1002(Serial, outputCoilModbus1002, inputCoilModbus1002);
    // Read Input/Output
    // Read input
    analogSwitchReadAllInput(analogSwitchOne1002, analogSwitchOneInputResult1002);
    PMMReArrangeInputArray02();
    inputCoilModbus1002.boolArrayCurrent = modbusInputArray1002;
    // Update output
    PMMReArrangeOutputArray02(outputCoilModbus1002.boolArrayCurrent, outputArrayOutputOrder1002, outputArrayTarget1002);
    multiplexerOutput(multiplexer1002, OUTPUTArray1002, 0, 8, outputArrayTarget1002);
}
void PMMSerialMirror1002(Uart &serialPort, modBusCoils outputCoilModbus, modBusCoils inputCoilModbus)
{
    if (serialPort.available() > 0)
    {
        String readBuffer = serialPort.readStringUntil('\n');
        SerialUSB.println(readBuffer);
        readBuffer.toCharArray(rcvMirrorBuffer1002, readBuffer.length());
        for (int i = 0; i < 8; i++)
            outputCoilModbus.boolArrayCurrent[i] = rcvMirrorBuffer1002[i] == '1' ? true : false;
        serialPort.flush();
        communicationTime1002 = millis();
    }
    uint32_t samplMachineTimes = millis();
    if (samplMachineTimes >= (SendTime1002 + 500))
    {
        String dataToSend = "";
        for (int i = 0; i < 8; i++)
        {
            dataToSend += inputCoilModbus.boolArrayCurrent[i] == false ? '0' : '1';
        }
        serialPort.println(dataToSend);
        serialPort.flush();
        SendTime1002 = millis();
    }
    if (millis() >= communicationTime1002 + 3000)
    {
        // Connection is Closed
        // Turn Communication Led Error
        // Reopen all Relays
        char outputArray[8];
        for (uint8_t i = 0; i < 8; i++)
            outputArray[i] = LOW;
        PMMUDPToOutput2(outputArray, outputCoilModbus.boolArrayCurrent);
    }
}
void PMMUDPMirror02(modBusCoils outputCoilModbus, modBusCoils inputCoilModbus)
{
    char CharRemoteIPAddress[30] = "192.168.1.5";
    char inputArray[8];
    char outputArray[8];
    remoteIPAddress.toCharArray(CharRemoteIPAddress, (remoteIPAddress.length() + 1));
    PMMOutputToCharArray02(inputArray, inputCoilModbus);
    PMMUDPSend(Udp, 91, CharRemoteIPAddress, inputArray, 8);
    if (PMMUDPRecivedMsg(Udp, outputArray))
    {
        PMMUDPToOutput2(outputArray, outputCoilModbus.boolArrayCurrent);
        communicationTime1002 = millis();
    }
    if (millis() >= communicationTime1002 + 3000)
    {
        // Connection is Closed
        // Turn Communication Led Error
        // Reopen all Relays
        char outputArray[8];
        for (uint8_t i = 0; i < 8; i++)
            outputArray[i] = LOW;
        PMMUDPToOutput2(outputArray, outputCoilModbus.boolArrayCurrent);
    }
}
void PMMOutputToCharArray02(char *inputArray, modBusCoils tmpCoilModbus)
{
    for (int i = 0; i < 8; i++)
    {
        inputArray[i] = tmpCoilModbus.boolArrayCurrent[i];
    }
}
void PMMReArrangeOutputArray02(bool *outputArray, bool *outputArrayOutputOrder, bool *targetOutputArray)
{
    for (int i = 0; i < 8; i++)
    {

        targetOutputArray[7 - i] = outputArray[i];
    }
}
void PMMReArrangeInputArray02()
{

    // Input from 0-7
    modbusInputArray1002[0] = !analogSwitchOneInputResult1002[15];
    modbusInputArray1002[1] = !analogSwitchOneInputResult1002[14];
    modbusInputArray1002[2] = !analogSwitchOneInputResult1002[13];
    modbusInputArray1002[3] = !analogSwitchOneInputResult1002[12];
    modbusInputArray1002[4] = !analogSwitchOneInputResult1002[11];
    modbusInputArray1002[5] = !analogSwitchOneInputResult1002[10];
    modbusInputArray1002[6] = !analogSwitchOneInputResult1002[9];
    modbusInputArray1002[7] = !analogSwitchOneInputResult1002[8];
    // Dip switch
    modbusInputArray1002[8] = analogSwitchOneInputResult1002[0];
    modbusInputArray1002[9] = analogSwitchOneInputResult1002[1];
    modbusInputArray1002[10] = analogSwitchOneInputResult1002[2];
    modbusInputArray1002[11] = analogSwitchOneInputResult1002[3];
    modbusInputArray1002[12] = analogSwitchOneInputResult1002[4];
    modbusInputArray1002[13] = analogSwitchOneInputResult1002[5];
    modbusInputArray1002[14] = analogSwitchOneInputResult1002[6];
    modbusInputArray1002[15] = analogSwitchOneInputResult1002[7];
}
void PMMUDPToOutput2(char *UDPMsg, bool *boolArray)
{
    for (int i = 0; i < 8; i++)
    {
        boolArray[i] = UDPMsg[i];
    }
}