#ifndef PMM1002DeviceLib
#define PMM1002DeviceLib
#include <Arduino.h>
#include <projectConfigration.h>
#include <PMMWebController/PMMWebController.h>
#include <PMMTCPServer/PMMTCPServer.h>
#include <PMMRTUSlave/modbusRTUWrappper.h>
#include <PMMUDPLib/PMMUDPLib.h>
#include <PMMIOLib/PMMIOLib.h>
#include <PMMAnalogSwitch/PMMAnalogSwitch.h>
#include <PMMmultiplexer/PMMmultiplexer.h>
#include <HC595.h>

void PMMInitalize1002();
void PMM1002Loop();
void PMMUDPToOutput2(char *UDPMsg, bool *boolArray);
void PMMReArrangeOutputArray02(bool *outputArray, bool *outputArrayOutputOrder, bool *targetOutputArray);
void PMMSerialMirror1002(Uart &serialPort, modBusCoils outputCoilModbus, modBusCoils inputCoilModbus);
void PMMUDPMirror02(modBusCoils outputCoilModbus, modBusCoils inputCoilModbus);
void PMMOutputToCharArray02(char *inputArray, modBusCoils tmpCoilModbus);
void PMMUDPToOutput02(char *UDPMsg, bool *boolArray);
void PMMReArrangeInputArray02();
extern bool webPageConfugration;
extern EthernetUDP Udp;
extern SerialParameter portOne;
extern String selOperation;
#endif