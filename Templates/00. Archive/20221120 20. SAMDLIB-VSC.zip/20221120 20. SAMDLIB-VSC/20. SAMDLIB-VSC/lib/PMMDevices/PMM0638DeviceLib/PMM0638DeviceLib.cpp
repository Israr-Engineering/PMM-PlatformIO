#include <PMM0638DeviceLib/PMM0638DeviceLib.h>
extern struct AI aiArray[8];
extern struct AO aoArray[4];


extern modBusCoils PMMInputCoilModbus;
extern modBusCoils PMMOutputCoilModbus;
extern modBusHolding PMMInputHolding;
extern modBusHolding PMMOutputHolding;

// struct AD7441 tmpAD7441;
void PMMInitalize0638()
{
    Debugprintln("0638 Device");
    // Configure Ai Pins
    // Configure more Ai Source ::https://forum.arduino.cc/t/arduino-zero-additional-analog-inputs/350356/5
    aiArray[0].pinNumber = A1;
    aiArray[1].pinNumber = A2;
    aiArray[2].pinNumber = A3;
    aiArray[3].pinNumber = A4;
    // Anitalize Ai
    for (uint8_t i = 0; i < 4; i++)
        // clear analogValues arrays
        memset(aiArray[i].analogValues, 0, 10 * sizeof(int16_t));
    // Init holding reg
    PMMInputHolding.holingArray = aiArray;
    PMMInputHolding.startAddress = ReadHoldingRegStartAddress.toInt();
    PMMInputHolding.quentity = 8;
    PMMInputHolding.read = true;
    PMMInputHolding.write = false;
    // Output
    PMMOutputHolding.startAddress = WriteHoldingRegStartAddress.toInt() + 8;
    PMMOutputHolding.quentity = 8;
    PMMOutputHolding.read = false;
    PMMOutputHolding.write = true;
    PMMOutputHolding.outputValue = modbusAO;
    // Init AD7411
    PMMAD7441.cs = 11;
    PMMAD7441.alertFlage = 3;
    PMMAD7441.rst = 1;
    PMMAD7441.ready = 4;
    PMMAD7441.EthCS = 10;

    pinMode(11, OUTPUT);
    digitalWrite(11, HIGH);
    initalizeEthernet();
    // Initalize WebServer
    if (webPageConfugration)
        PMMInitWebServer();
    initialSerialPort(Serial, portOne.baudRate, portOne.dataBit, portOne.parity, portOne.stopBit, portOne.interface);
    // Init PMMAD74412R
    PMMAD74412RInit(PMMAD7441);
    // 0 => TCP Slave , 1 => RTU Slave
    // Start in TCP Testing
    if (TCPORRTU == "0")
    { // TCP Slave
        initModBusTCP(slaveId.toInt());
        PMMInitRegister(1, 3, PMMInputHolding.startAddress, 16);
    }
    else if (TCPORRTU == "1")
    {
        Debugprintln("RTUSlave");                              // RTU Slave
        PMMRTUSlaveStartConfig(Serial, 9600, slaveId.toInt()); // Other Serial info is set on line 37
        PMMInitRTUSlaveRegister(1, 3, PMMInputHolding.startAddress, 16);
    }
}
void PMM0638Loop()
{
    // Check the Website Reading
    PMMAD74412AnalogWrite(PMMAD7441, aoArray, 4);
    PMMModbusToAnalogOutput(modbusAO, aoArray);
    PMMAnalogReadCalibratoin(aiArray, 4);
    if (TCPORRTU == "0") // TCP Slave
        PMMTCPSlaveLoop(1, PMMOutputCoilModbus, PMMInputCoilModbus, PMMOutputHolding, PMMInputHolding);
    else if (TCPORRTU == "1") // RTU Slave
        PMMRTUSlaveLoop(1, PMMOutputCoilModbus, PMMInputCoilModbus, PMMOutputHolding, PMMInputHolding);
}
void PMMModbusToAnalogOutput(uint16_t *Output, AO *tmpAO)
{
    uint8_t index = 0;
    for (uint8_t i = 0; i < 4; i++)
    {
        if (!tmpAO[i].forced)
        {
            tmpAO[i].floatToInt.valueAsInt[0] = Output[index];
            index++;
            tmpAO[i].floatToInt.valueAsInt[1] = Output[index];
            index++;
            tmpAO[i].valueOnADC = map_float(tmpAO[i].floatToInt.valueAsFloat, 0, 11, 0, 8191); // Convert it to float
        }
    }
}

float map_float(float x, long in_min, long in_max, long out_min, long out_max)
{
    return (float)(x - in_min) * (out_max - out_min) / (float)(in_max - in_min) + out_min;
}