#ifndef PMM0638DeviceLib
#define PMM0638DeviceLib
#include <Arduino.h>
#include <projectConfigration.h>
#include <PMMWebController/PMMWebController.h>
#include <PMMTCPServer/PMMTCPServer.h>
#include <PMMRTUSlave/modbusRTUWrappper.h>
#include <PMMModbusGateWay/PMMModbusGateWay.h>
#include <PMMEEPROMSerialParam/PMMEEPROMSerialParam.h>
#include <PMMUDPLib/PMMUDPLib.h>
#include <PMMEEPROMAuth/PMMEEPROMAuth.h>
#include <PMM74412R/PMM74412R.h>

void PMMInitalize0638();
void PMM0638Loop();
void analogReadCalibratoin(struct AI *ai, uint8_t quentity);
void PMMModbusToAnalogOutput(uint16_t *Output, AO *tmpAO);
float map_float(float x, long in_min, long in_max, long out_min, long out_max);
extern bool webPageConfugration;
extern String slaveId;
extern String ReadHoldingRegStartAddress;
extern String ReadHoldingRegQuintity;
extern modBusCoils PMMInputCoilModbus;
extern modBusCoils PMMOutputCoilModbus;
extern modBusHolding PMMInputHolding;
extern modBusHolding PMMOutputHolding;
extern struct AD7441 PMMAD7441;
extern uint16_t modbusAO[8];
#endif