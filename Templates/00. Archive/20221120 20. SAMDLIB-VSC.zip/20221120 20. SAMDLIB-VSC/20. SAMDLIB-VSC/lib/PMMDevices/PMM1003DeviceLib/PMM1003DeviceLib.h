#ifndef PMM1003DeviceLib
#define PMM1003DeviceLib
#include <Arduino.h>
#include <projectConfigration.h>
#include <PMMWebController/PMMWebController.h>
#include <PMMTCPServer/PMMTCPServer.h>
#include <PMMRTUSlave/modbusRTUWrappper.h>
#include <PMMUDPLib/PMMUDPLib.h>
#include <PMMIOLib/PMMIOLib.h>
#include <PMMAnalogSwitch/PMMAnalogSwitch.h>
#include <PMMmultiplexer/PMMmultiplexer.h>
#include <HC595.h>

void PMMInitalize1003();
void PMM1003Loop();
void PMMReArrangeOutputArray(bool *outputArray, bool *outputArrayOutputOrder, bool *targetOutputArray);
void PMM0103LedControl(bool *outputArray, bool *inputArray, bool *targetOutputArray);
void PMMUDPMirror(modBusCoils outputCoilModbus, modBusCoils inputCoilModbus);
void PMMOutputToCharArray(char *inputArray, modBusCoils tmpCoilModbus);
void PMMSerialMirror(Uart &serialPort, modBusCoils outputCoilModbus, modBusCoils inputCoilModbus);
void PMMUDPToOutput(char *UDPMsg, bool *boolArray);
void PMMReArrangeInputArray();
extern bool webPageConfugration;
extern EthernetUDP Udp;
extern String selOperation;
extern String remoteIPAddress;

#endif