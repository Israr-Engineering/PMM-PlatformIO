#include <PMM1003DeviceLib/PMM1003DeviceLib.h>

/**
 * Todo :
 *  - UDP Communication
 *  - GSM
 *  - Alarm Buttons
 */

// Analog Switch Pins
struct AnalogSwitch analogSwitchOne;
struct AnalogSwitch analogSwitchTwo;
struct Multiplexer multiplexer;
struct Multiplexer testMultiplexer;
// Modbus Configration
struct modBusCoils inputCoilModbus;
struct modBusCoils outputCoilModbus;
struct modBusHolding inputHolding;
struct modBusHolding outputHolding;
int SendTime = 0;
int communicationTime = 0;
// Serial Mirror Buffer
char rcvMirrorBuffer[UDP_TX_PACKET_MAX_SIZE];
bool analogSwitchOneInputResult[16]; // Save the Result of reading the input
// map the number of input with Which pin on the analog switch
// From 0-8 => Dip Switch & From 9-15 => is input from 1 - 7 {Note that the input is inverted due to optocoupler}
uint8_t analogSwitchOneInputOrder[16] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 15, 14, 13, 12, 11, 10, 9};
// map the number of input with Which pin on the analog switch
bool analogSwitchTwoInputResult[16]; // Save the Result of reading the input
// in the analogSwitchTwoInputResult index zero represent input 8 and index one represent input 9 etc .. , index 13 represtent alarm led
// analogSwitchTwoInputOrder : re arrange the bits so index zero is the input one || use this in the Rading loops
uint8_t analogSwitchTwoInputOrder[16] = {8, 7, 6, 5, 4, 3, 2, 1, 13, 0, 0, 0, 0, 0, 0, 0};
// HC595 outputArray;
HC595 OUTPUTArray;
bool outputArrayBool[30];
bool outputArrayTarget[64];
// Output From 1-16  is the Output / Not Used /Intrrupt/ Ethernet rst {Low to rst ethernet} / Ethern control{Relay}
bool outputArrayOutputOrder[30] = {15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, 16, 17, 18};
bool testArrayLow[56] = {
    LOW, LOW, LOW, LOW, LOW, LOW, LOW, LOW,
    LOW, LOW, LOW, LOW, LOW, LOW, LOW, LOW,
    LOW, LOW, HIGH, LOW, LOW, LOW, LOW, LOW,
    LOW, LOW, LOW, LOW, LOW, LOW, LOW, LOW,
    LOW, LOW, LOW, LOW, LOW, LOW, LOW, LOW,
    LOW, LOW, LOW, LOW, LOW, LOW, LOW, LOW,
    LOW, LOW, LOW, LOW, LOW, LOW, LOW, LOW

};

bool modbusOutputArray[16];
bool modbusInputArray[16] = {
    false,
    false,
    false,
    false,
    false,
    false,
    false,
    false,
    false,
    false,
    false,
    false,
    false,
    false,
    false,
    false};
char CharRemoteIPAddress[30] = "192.168.1.5";

// Just For Test purbose
/**
 * devicetype = 0 => Modbus TCP Slave
 * devicetype = 1 => Modbus RTU Slave
 * devicetype = 2 => UDP Mirror
 * devicetype = 3 => Serial Mirror
 */

void PMMInitalize1003()
{
    Debugprintln("0103 Device");
    // Initalize Analog Switches
    analogSwitchOne.dataPin = A2;
    analogSwitchOne.S0 = A1;
    analogSwitchOne.S1 = 7;
    analogSwitchOne.S2 = 6;
    analogSwitchOne.S3 = A4;
    analogSwitchOne.inputCount = 16;
    analogSwitchTwo.dataPin = 38;
    analogSwitchTwo.S0 = 13;
    analogSwitchTwo.S1 = 11;
    analogSwitchTwo.S2 = 3;
    analogSwitchTwo.S3 = 4;
    analogSwitchTwo.inputCount = 16;
    // Initalize Multiplexer
    multiplexer.numberOfChip = 8;
    multiplexer.numberOfOutput = 64;
    multiplexer.SERIn = 8;
    multiplexer.SRCLK = A5;
    multiplexer.RCLK = 9;
    multiplexer.SRCLKInv = A0;
    // Inetalize Modbus Variable
    // Configure input
    inputCoilModbus.startAddress = 16;
    inputCoilModbus.quentity = 16;
    inputCoilModbus.read = true;
    inputCoilModbus.write = false;
    inputCoilModbus.boolArrayCurrent = modbusInputArray;
    // Configure Output Array
    outputCoilModbus.startAddress = 0;
    outputCoilModbus.quentity = 16;
    outputCoilModbus.read = false;
    outputCoilModbus.write = true;
    outputCoilModbus.boolArrayCurrent = outputArrayBool;

    analogSwitchSetup(analogSwitchOne);
    analogSwitchSetup(analogSwitchTwo);
    multiplexerSetup(multiplexer, OUTPUTArray);
    // Enable Ethernet
    multiplexerOutput(multiplexer, OUTPUTArray, 0, 64, testArrayLow);
    initalizeEthernet();
    // Initalize WebServer
    if (webPageConfugration)
        PMMInitWebServer();
    // Initalize Serial Port
    initialSerialPort(Serial, portOne.baudRate, portOne.dataBit, portOne.parity, portOne.stopBit, portOne.interface);
    // Sel Mode {Their are four  Type TCP  , UDP Mirror, Serial  }
    // For Testing purpose we will specifay value for the device mode
    // 0 => TCP Slave , 1 => RTU Slave , 2 => UDP Mirrot
    // Start in TCP Testing
    if (selOperation == "TCPSlave")
    { // TCP Slave
        initModBusTCP(1);
        PMMInitRegister(1, 1, 0, 32);
    }
    else if (selOperation == "RTUSlave")
    {                                            // RTU Slave
        PMMRTUSlaveStartConfig(Serial, 9600, 1); // Other Serial info is set on line 123
        PMMInitRTUSlaveRegister(1, 1, 0, 32);
    }
    else if (selOperation == "FiberMirror")
        PMMUDPInit(Udp, 91);
    // remoteIPAddress = "192.168.1.5";
    remoteIPAddress.toCharArray(CharRemoteIPAddress, (remoteIPAddress.length() + 1));
}
void PMM1003Loop()
{
    // Update Modbus
    if (selOperation == "TCPSlave")
        PMMTCPSlaveLoop(1, outputCoilModbus, inputCoilModbus, outputHolding, inputHolding);
    else if (selOperation == "RTUSlave")
        PMMRTUSlaveLoop(1, outputCoilModbus, inputCoilModbus, outputHolding, inputHolding);
    else if (selOperation == "FiberMirror") // UDP Mirror
        PMMUDPMirror(outputCoilModbus, inputCoilModbus);
    else if (selOperation == "SerialMirror")
        PMMSerialMirror(Serial, outputCoilModbus, inputCoilModbus);
    // Read Input/Output
    // Read input
    analogSwitchReadAllInput(analogSwitchOne, analogSwitchOneInputResult);
    analogSwitchReadAllInput(analogSwitchTwo, analogSwitchTwoInputResult);
    PMMReArrangeInputArray();
    inputCoilModbus.boolArrayCurrent = modbusInputArray;
    // Update output
    PMMReArrangeOutputArray(outputCoilModbus.boolArrayCurrent, outputArrayOutputOrder, outputArrayTarget);
    PMM0103LedControl(outputArrayTarget, inputCoilModbus.boolArrayCurrent, outputArrayTarget);
    multiplexerOutput(multiplexer, OUTPUTArray, 0, 64, outputArrayTarget);
}
void PMMUDPMirror(modBusCoils outputCoilModbus, modBusCoils inputCoilModbus)
{
    // remoteIPAddress.toCharArray(CharRemoteIPAddress, (remoteIPAddress.length() + 1));
    // SerialUSB.println(remoteIPAddress);
    char inputArray[16];
    char outputArray[16];
    PMMOutputToCharArray(inputArray, inputCoilModbus);
    PMMUDPSend(Udp, 91, CharRemoteIPAddress, inputArray, 16);
    if (PMMUDPRecivedMsg(Udp, outputArray))
    {
        PMMUDPToOutput(outputArray, outputCoilModbus.boolArrayCurrent);
        communicationTime = millis();
    }
    if (millis() >= communicationTime + 3000)
    {
        // Connection is Closed
        // Turn Communication Led Error
        // Reopen all Relays
        char outputArray[16];
        for (uint8_t i = 0; i < 16; i++)
            outputArray[i] = LOW;
        PMMUDPToOutput(outputArray, outputCoilModbus.boolArrayCurrent);
    }
}
void PMMSerialMirror(Uart &serialPort, modBusCoils outputCoilModbus, modBusCoils inputCoilModbus)
{
    if (serialPort.available() > 0)
    {
        String readBuffer = serialPort.readStringUntil('\n');
        readBuffer.toCharArray(rcvMirrorBuffer, readBuffer.length());
        for (int i = 0; i < 16; i++)
            outputCoilModbus.boolArrayCurrent[i] = rcvMirrorBuffer[i] == '1' ? true : false;
        serialPort.flush();
        communicationTime = millis();
    }
    uint32_t samplMachineTimes = millis();
    if (samplMachineTimes >= (SendTime + 500))
    {
        String dataToSend = "";
        for (int i = 0; i < 16; i++)
        {
            dataToSend += inputCoilModbus.boolArrayCurrent[i] == false ? '0' : '1';
        }
        serialPort.println(dataToSend);
        SendTime = millis();
    }
    if (millis() >= communicationTime + 3000)
    {
        // Connection is Closed
        // Turn Communication Led Error
        // Reopen all Relays
        char outputArray[16];
        for (uint8_t i = 0; i < 16; i++)
            outputArray[i] = LOW;
        PMMUDPToOutput(outputArray, outputCoilModbus.boolArrayCurrent);
    }
}
void PMMOutputToCharArray(char *inputArray, modBusCoils tmpCoilModbus)
{
    for (int i = 0; i < 16; i++)
    {
        inputArray[i] = tmpCoilModbus.boolArrayCurrent[i];
    }
}
void PMMReArrangeOutputArray(bool *outputArray, bool *outputArrayOutputOrder, bool *targetOutputArray)
{
    for (int i = 0; i < 16; i++)
    {

        targetOutputArray[15 - i] = outputArray[i];
    }
}
void PMM0103LedControl(bool *outputArray, bool *inputArray, bool *targetOutputArray)
{
    // ETHERNET AND RST Control
    targetOutputArray[16] = LOW;
    targetOutputArray[17] = LOW;
    targetOutputArray[18] = HIGH;
    targetOutputArray[19] = LOW;
    targetOutputArray[20] = LOW;
    targetOutputArray[21] = LOW;
    targetOutputArray[22] = LOW;
    targetOutputArray[23] = LOW;

    // LED Output
    targetOutputArray[24] = outputArray[0]; // outputArray[1]; // OUTPUT 16
    targetOutputArray[25] = outputArray[1]; // OUTPUT 15
    targetOutputArray[26] = outputArray[2]; // OUTPUT 14
    targetOutputArray[27] = outputArray[3]; // OUTPUT 13
    targetOutputArray[28] = outputArray[4]; // OUTPUT 12
    targetOutputArray[30] = outputArray[5]; // OUTPUT 11 38
    targetOutputArray[48] = outputArray[6]; // OUTPUT 11

    targetOutputArray[49] = outputArray[7];  // OUTPUT 9
    targetOutputArray[50] = outputArray[8];  // OUTPUT 8
    targetOutputArray[51] = outputArray[9];  // outputArray[11];  // OUTPUT 7
    targetOutputArray[52] = outputArray[10]; // outputArray[12];  // OUTPUT 6
    targetOutputArray[53] = outputArray[11]; // outputArray[13];  // OUTPUT 4
    targetOutputArray[54] = outputArray[12]; // outputArray[14];  // OUTPUT 3
    targetOutputArray[55] = outputArray[13]; // OUTPUT 2
    // targetOutputArray[56] = outputArray[14]; // NOTHING
    targetOutputArray[38] = outputArray[14]; // OUTPUT 11
    // Input Signals
    targetOutputArray[47] = inputArray[0];  // INPUT 1
    targetOutputArray[46] = inputArray[1];  // INPUT 2
    targetOutputArray[45] = inputArray[2];  // INPUT 3
    targetOutputArray[44] = inputArray[3];  // INPUT 4
    targetOutputArray[43] = inputArray[4];  // INPUT 5
    targetOutputArray[42] = inputArray[5];  // INPUT 6
    targetOutputArray[41] = inputArray[6];  // INPUT 7
    targetOutputArray[63] = inputArray[7];  // INPUT 8
    targetOutputArray[62] = inputArray[8];  // INPUT 9
    targetOutputArray[61] = inputArray[9];  // INPUT 10
    targetOutputArray[60] = inputArray[10]; // INPUT 11
    targetOutputArray[59] = inputArray[11]; // INPUT 12
    targetOutputArray[58] = inputArray[12]; // INPUT 13
    targetOutputArray[57] = inputArray[13]; // INPUT 14
    targetOutputArray[31] = inputArray[14]; // INPUT 15
    targetOutputArray[29] = inputArray[15]; // INPUT 16

    // Unkown Signal
    targetOutputArray[39] = HIGH; // NOTHING
    targetOutputArray[40] = HIGH; // NOTHING

    // Signal Leds
    targetOutputArray[32] = HIGH; // UNKOWN 5
    targetOutputArray[33] = HIGH; // UNKOWN 4
    targetOutputArray[34] = HIGH; // UNKOWN 3
    targetOutputArray[35] = HIGH; // UNKOWN 2
    targetOutputArray[36] = HIGH; // UNKOWN 1
    targetOutputArray[37] = HIGH; // UNKOWN 0
}
void PMMReArrangeInputArray()
{

    // Input from 0-7
    modbusInputArray[0] = !analogSwitchOneInputResult[15];
    modbusInputArray[1] = !analogSwitchOneInputResult[14];
    modbusInputArray[2] = !analogSwitchOneInputResult[13];
    modbusInputArray[3] = !analogSwitchOneInputResult[12];
    modbusInputArray[4] = !analogSwitchOneInputResult[11];
    modbusInputArray[5] = !analogSwitchOneInputResult[10];
    modbusInputArray[6] = !analogSwitchOneInputResult[9];

    modbusInputArray[7] = !analogSwitchTwoInputResult[8];
    modbusInputArray[8] = !analogSwitchTwoInputResult[7];
    modbusInputArray[9] = !analogSwitchTwoInputResult[6];
    modbusInputArray[10] = !analogSwitchTwoInputResult[5];
    modbusInputArray[11] = !analogSwitchTwoInputResult[4];
    modbusInputArray[12] = !analogSwitchTwoInputResult[3];
    modbusInputArray[13] = !analogSwitchTwoInputResult[2];
    modbusInputArray[14] = !analogSwitchTwoInputResult[1];
    modbusInputArray[15] = !analogSwitchTwoInputResult[0];

    // LOW, LOW, HIGH, LOW, LOW, LOW, LOW, LOW,
}
void PMMUDPToOutput(char *UDPMsg, bool *boolArray)
{
    for (int i = 0; i < 16; i++)
    {
        boolArray[i] = UDPMsg[i];
    }
}