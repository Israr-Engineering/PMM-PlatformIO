#include <Arduino.h>
#include <PMMEEPROMGeneralFunction/PMMEEPROMGeneralFunction.h>
#include <projectConfigration.h>
#ifndef PMMGlobalFunction
#define PMMGlobalFunction

extern bool inDebugMode ; // For Serial Debug Info
void Debugprintln(String);
void Debugprint(String);

#endif