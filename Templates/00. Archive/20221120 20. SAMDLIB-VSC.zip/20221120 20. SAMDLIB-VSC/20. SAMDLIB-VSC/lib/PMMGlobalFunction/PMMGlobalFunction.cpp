#include <PMMGlobalFunction.h>
void Debugprintln(String toPrint)
{
    if (true)
        SerialUSB.println(toPrint);
}
void Debugprint(String toPrint)
{
     if (true)
        SerialUSB.print(toPrint);
}