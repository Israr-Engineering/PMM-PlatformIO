#include <PMMTCPServer/PMMTCPServer.h>

/**
 * ToDo :
 * remove unused variable
 * Make Initalize Ethernet in better place
 * change Check TCP Connection to better name
 * Add 0501 Functions Here
 */

// === Configure MODBUS TCP
EthernetServer EthServer(502);
ModbusTCPServer modbusTCPServer;
IPAddress MODBUSControllerIP;
IPAddress MODBUSSubNetMaskIP;
IPAddress MODBUSControllerDNS;
IPAddress MODBUSGatWayIP;
int TCPrequestLength = 0;
uint8_t TCPReuestrequest[260];
uint8_t TCPquentity = 0;
int printTimingInfo = 0;

/**
 * initalizeEthernet : init the TCP Connection and get the IP Address subnets &
 * Mac Address From the EEPROM
 */
void  initalizeEthernet()
{
  Debugprintln("Entered ...");
  Debugprintln(controllerIPAddress);
  MODBUSControllerIP.fromString(controllerIPAddress);
  MODBUSSubNetMaskIP.fromString(subNetMask);
  MODBUSControllerDNS.fromString(DNS);
  MODBUSGatWayIP.fromString(GatWay);
  Ethernet.init(EthernetCS);
  SerialUSB.println(EthernetCS);
  // Ethernet.begin(mac, MODBUSControllerIP, MODBUSControllerDNS, MODBUSGatWayIP, MODBUSSubNetMaskIP);
  byte macs[] = {0x46, 0x46, 0x46, 0x46, 0x46, 0x01};
  Ethernet.begin(macs, MODBUSControllerIP, MODBUSControllerDNS, MODBUSGatWayIP, MODBUSSubNetMaskIP);
  EthServer.begin();
  if (Ethernet.hardwareStatus() == EthernetNoHardware)
    Debugprintln("Ethernet shield was not found.  Sorry, can't run without hardware. :(");
  if (Ethernet.linkStatus() == LinkOFF)
    Debugprintln("Ethernet cable is not connected.");
  Debugprintln("Ethernet Init!");
}
/**
 *
 */
// void PMMCheckEthernetStatus()
// {
//   if (Ethernet.hardwareStatus() == EthernetNoHardware)
//   {

//     SerialUSB.println("EthernetNoHardware");
//     SerialUSB.println("Reset Ethernet");
//     pinMode(A5,OUTPUT);
//     digitalWrite(A5,LOW);
//     delay(50);
//     digitalWrite(A5,HIGH);
//     SerialUSB.println("Reconfig Ethernet");
//     Ethernet.begin(mac, MODBUSControllerIP, MODBUSControllerDNS, MODBUSGatWayIP, MODBUSSubNetMaskIP);
//     SerialUSB.println("Configured ReConfigured");
//   }
// }

void PMMCheckEthernetStatus()
{

  if (millis() > printTimingInfo + 1080000)
  {
    printTimingInfo = millis();
    // SerialUSB.println(Ethernet.isResponding());
    // SerialUSB.println("Reset Ethernet");
    PMMEthernetSoftReset();
    Ethernet.begin(mac, MODBUSControllerIP, MODBUSControllerDNS, MODBUSGatWayIP, MODBUSSubNetMaskIP);
  }
}

void PMMEthernetSoftReset()
{
  Ethernet.PMMSoftReset();
}

/**
 * initModBusTCP : init the TCP Connection and get the IP Address subnets &
 * Mac Address From the EEPROM
 */
void initModBusTCP(int slave_id)
{
  int init = modbusTCPServer.begin(slave_id);
  if (init == 1)
    Debugprintln("MODBUS TCP Success!");
  else
    Debugprintln("ERROR IN TCP CONNECTION !!");
}
/**
 * initRegisters : initalize the ModBus TCP Registers
 * uint8_t slaveId : TCP Slave ID
 * uint8_t type : the type of register to configure 1=> Coil , 2 Input Status , 3 Holding reqister , 4 Input Register
 * uint16_t startAddress : registers start Address
 * uint8_t quintity : Number of register
 */
void PMMInitRegister(uint8_t slaveId, uint8_t type, uint16_t startAddress, uint8_t quintity)
{

  Debugprintln("Start Register initalizing");
  if (type == 1)
  {
    modbusTCPServer.configureCoils(startAddress, quintity, slaveId);
    Debugprintln("Congigure Coils Start From " + quintity);
    Debugprint(String(startAddress));
    Debugprint(" Quintity");
    Debugprintln(String(quintity));
  }
  else if (type == 3)
  {

    modbusTCPServer.configureHoldingRegisters(startAddress, quintity, slaveId);
    Debugprint("Congigure HoldingRegisters Start From ");
    Debugprintln(String(startAddress));
    Debugprint("Quintity");
    Debugprintln(String(quintity));
  }
  Debugprintln("End");
}

void PMMTCPSlaveLoop(uint8_t devicesSlaveid, modBusCoils &outputCoils, modBusCoils &inputCoils, modBusHolding &outputHolding, modBusHolding &inputHolding)
{
  EthernetClient client = EthServer.available();
  uint8_t slaveid = 0;
  uint8_t functionCode = 0;
  uint16_t startAddress = 0;
  TCPquentity = 0;
  if (client.connected())
  {
    modbusTCPServer.accept(client);
    PMMModBUSTCPSlavePoll(slaveid, functionCode, startAddress, TCPquentity);
    if (slaveid == devicesSlaveid)
    {
      PMMTCPSlaveReadCoils(devicesSlaveid, functionCode, startAddress, TCPquentity, outputCoils);
      PMMWriteSlaveReadCoils(devicesSlaveid, functionCode, startAddress, TCPquentity, inputCoils);
      PMMWTCPriteSlaveWriteHolding(devicesSlaveid, functionCode, startAddress, TCPquentity, inputHolding);
      PMMWTCPriteSlaveReadHolding(devicesSlaveid, functionCode, startAddress, TCPquentity, outputHolding);
    }
    else
    {
      // Not the same slave
      modbusTCPServer.hasError = true;
      modbusTCPServer.errorCode = 0xE0; // Invalide Slave ID
    }
    PMMTCPSlvaeConnectionEnd(devicesSlaveid);
  }
}

void PMMModBUSTCPSlavePoll(uint8_t &slaveid, uint8_t &functionCode, uint16_t &startAddress, uint8_t &quentity)
{
  TCPrequestLength = modbus_receive(modbusTCPServer._mb, TCPReuestrequest);
  slaveid = TCPReuestrequest[6];
  functionCode = TCPReuestrequest[7];
  startAddress = TCPReuestrequest[9] + TCPReuestrequest[8] * 16 * 16;
  quentity = TCPReuestrequest[11] + TCPReuestrequest[10] * 16 * 16;
}
void PMMTCPSlvaeConnectionEnd(int slaveid)
{
  if (TCPrequestLength <= 0)
    return;
  if (!modbusTCPServer.hasError)
    modbus_reply(modbusTCPServer._mb, TCPReuestrequest, TCPrequestLength, &modbusTCPServer._mbMappings[slaveid], slaveid);
  else
  {
    modbus_reply_exception(modbusTCPServer._mb, TCPReuestrequest, modbusTCPServer.errorCode);
    modbusTCPServer.hasError = false;
  }
}
void PMMTCPSlaveReadCoils(uint8_t &slaveid, uint8_t &functionCode, uint16_t &startAddress, uint8_t &quentity, modBusCoils &outputCoils)
{
  // Make sure its Output
  if (functionCode != 15 && functionCode != 5)
    return;
  if (functionCode == 5)
    quentity = 1;
  // Illegal data Address
  bool IllegaldataAddress = (outputCoils.startAddress + outputCoils.quentity < startAddress + quentity);
  if (IllegaldataAddress)
  {
    modbusTCPServer.hasError = true;
    modbusTCPServer.errorCode = 0x02;
    return;
  }
  int arrayindex = 0;
  while (quentity > 0)
  {
    if (quentity > 16)
    {
      uint16_t output = modbusTCPServer.coilsRead(startAddress, 16, slaveid);
      for (uint8_t i = 0; i < 16; i++)
      {
        outputCoils.boolArrayCurrent[arrayindex] = bitRead(output, i);
        arrayindex++;
      }
      quentity -= 16;
      startAddress += 16;
    }
    else
    {
      uint16_t output = modbusTCPServer.coilsRead(startAddress, quentity, slaveid);
      for (uint8_t i = 0; i < quentity; i++)
      {
        outputCoils.boolArrayCurrent[arrayindex] = bitRead(output, i);
        arrayindex++;
      }
      quentity = 0;
      startAddress += quentity;
    }
  }
}
void PMMWriteSlaveReadCoils(uint8_t &slaveid, uint8_t &functionCode, uint16_t &startAddress, uint8_t &quentity, modBusCoils &inputCoils)
{
  if (functionCode != 1)
    return;
  bool IllegaldataAddress = (inputCoils.startAddress + inputCoils.quentity < startAddress + quentity);
  if (IllegaldataAddress)
  {
    modbusTCPServer.hasError = true;
    modbusTCPServer.errorCode = 0x02;
    return;
  }
  for (uint8_t i = 0; i < quentity; i++)
  {
    modbusTCPServer.coilWrite(startAddress + i, inputCoils.boolArray[i], slaveid);
  }
}
void PMMWTCPriteSlaveWriteHolding(uint8_t &slaveid, uint8_t &functionCode, uint16_t &startAddress, uint8_t &quentity, modBusHolding &inputHolding)
{
  if (functionCode != 3)
    return;
  bool IllegaldataAddress = (inputHolding.startAddress + inputHolding.quentity < startAddress + quentity);
  if (IllegaldataAddress)
  {
    modbusTCPServer.hasError = true;
    modbusTCPServer.errorCode = 0x02;
    return;
  }
  uint8_t holdingArrayIndex = 0;
  for (uint8_t i = 0; i < quentity; i++)
  {
    modbusTCPServer._mbMappings[slaveid].tab_registers[i] = inputHolding.holingArray[holdingArrayIndex].floatToInt.valueAsInt[0];
    i++;
    modbusTCPServer._mbMappings[slaveid].tab_registers[i] = inputHolding.holingArray[holdingArrayIndex].floatToInt.valueAsInt[1];
    holdingArrayIndex++;
  }
}

void PMMWTCPriteSlaveReadHolding(uint8_t &slaveid, uint8_t &functionCode, uint16_t &startAddress, uint8_t &quentity, modBusHolding &inputHolding)
{
  if (functionCode != 16)
    return;
  bool IllegaldataAddress = ((inputHolding.startAddress + 8) + inputHolding.quentity < startAddress + quentity);
  if (IllegaldataAddress)
  {
    modbusTCPServer.hasError = true;
    modbusTCPServer.errorCode = 0x02;
    return;
  }
  for (uint8_t i = 0; i < quentity; i++)
  {
    inputHolding.outputValue[i] = modbusTCPServer._mbMappings[slaveid].tab_registers[startAddress + i];
  }
}

void checkTCPConnection(uint8_t &slaveid, uint8_t &functionCode,
                        int &startAddress, int &quentity)
{
  /**
   * checkTCPConnection : Check if their is ModBus TCP Request & Return the
   * Slave id & the Function code
   */
  uint8_t startAddressleastSegDigite = 0;
  uint8_t startAddressmostSegDidit = 0;
  uint8_t quatnityAddressleastSegDigite = 0;
  uint8_t quatnityAddressmostSegDidit = 0;
  EthernetClient client = EthServer.available();
  if (client.connected())
  {
    modbusTCPServer.accept(client);
    hexaToDecimal(startAddressleastSegDigite, startAddressmostSegDidit,
                  startAddress);
    hexaToDecimal(quatnityAddressleastSegDigite, quatnityAddressmostSegDidit,
                  quentity);
  }
  else
  {
    slaveid = 0;
    functionCode = 0;
    startAddress = 0;
    quentity = 0;
  }
}

void writeHoldeingRegister(int address, uint16_t value)
{
  modbusTCPServer.holdingRegisterWrite(address, value);
}
void TCPCoilWrite(int address, uint8_t value)
{
  // modbusTCPServer.coilWrite(address, value);
}
void TCPCoilsWrite(int address, int numberOfcoils, uint16_t value)
{
  // modbusTCPServer.coilsWrite(address, numberOfcoils, value);
}
void TCPInputHoldingWrite(int address, uint8_t value)
{
  modbusTCPServer.inputRegisterWrite(address, value);
}
int TCPCoilRead(int address)
{
  return (modbusTCPServer.coilRead(address));
}
int TCPCoilsRead(int address, int numberOfCoils)
{
  return 0; //(modbusTCPServer.coilsRead(address, numberOfCoils));
}
int TCPHoldingRegRead(int address)
{
  return (modbusTCPServer.holdingRegisterRead(address));
}
void hexaToDecimal(uint8_t leastSegDigite, uint8_t mostSegDidit,
                   int &returnData)
{
  returnData = leastSegDigite + mostSegDidit * 16 * 16;
}
