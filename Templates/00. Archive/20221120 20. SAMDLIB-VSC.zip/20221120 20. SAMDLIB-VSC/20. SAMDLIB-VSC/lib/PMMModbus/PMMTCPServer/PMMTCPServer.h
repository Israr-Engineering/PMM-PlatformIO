
#ifndef PMMTCPServer
#define PMMTCPServer
#include <Arduino.h>
#include <SPI.h>
#include <Ethernet.h>
#include <ArduinoRS485.h> // ArduinoModbus depends on the ArduinoRS485 library
#include <ArduinoModbus.h>
#include <projectConfigration.h>
#include <PMMGlobalFunction.h>

extern uint8_t resetButton;
extern uint8_t EthernetCS;
extern String controllerIPAddress;
extern String subNetMask;
extern String DNS;
extern String GatWay;
extern String remoteIPAddress;
extern String UDPPort;
extern String MACAddressString;
extern String controllerSerialNumber;
extern byte mac[6];
extern bool inDebugMode;
extern bool IODevice;
extern bool modBusSlaveDO;

extern String readCoilAdd;
extern String ReadCoilQuint;
extern String ReadHoldingAdd;
extern String ReadHoldingQuint;

void initModBusTCP(int slave_id);
void initRegisters();
void checkTCPConnection(uint8_t &slaveid, uint8_t &functionCode,
                        int &startAddress, int &quentity);
// void writeHoldeingRegister(int address, uint16_t value);
void writeHoldeingRegister(int address, uint16_t value);
void TCPCoilWrite(int address, uint8_t value);
void TCPCoilsWrite(int address, int numberOfcoils, uint16_t value);
int TCPCoilRead(int address);
int TCPCoilsRead(int address, int numberOfCoils);
int TCPHoldingRegRead(int address);
void TCPInputHoldingWrite(int address, uint8_t value);
void hexaToDecimal(uint8_t leastSegDigite, uint8_t mostSegDidit,
                   int &returnData);
void initalizeEthernet();

// PMM New Connection

void PMMTCPSlaveLoop(uint8_t devicesSlaveid, modBusCoils &outputCoils, modBusCoils &inputCoils, modBusHolding &outputHolding, modBusHolding &inputHolding);
void PMMInitRegister(uint8_t slaveId, uint8_t type, uint16_t startAddress, uint8_t quintity);
void initModBusTCP(int slave_id);
void PMMCheckEthernetStatus();
void PMMModBUSTCPSlavePoll(uint8_t &slaveid, uint8_t &functionCode, uint16_t &startAddress, uint8_t &quentity);
void PMMTCPSlvaeConnectionEnd(int slaveid);
void PMMTCPSlaveReadCoils(uint8_t &slaveid, uint8_t &functionCode, uint16_t &startAddress, uint8_t &quentity, modBusCoils &outputCoils);
void PMMWriteSlaveReadCoils(uint8_t &slaveid, uint8_t &functionCode, uint16_t &startAddress, uint8_t &quentity, modBusCoils &inputCoils);
void PMMWTCPriteSlaveWriteHolding(uint8_t &slaveid, uint8_t &functionCode, uint16_t &startAddress, uint8_t &quentity, modBusHolding &inputCoils);
void PMMWTCPriteSlaveReadHolding(uint8_t &slaveid, uint8_t &functionCode, uint16_t &startAddress, uint8_t &quentity, modBusHolding &inputHolding);
void PMMCheckEthernetStatus();
void PMMEthernetSoftReset();
#endif