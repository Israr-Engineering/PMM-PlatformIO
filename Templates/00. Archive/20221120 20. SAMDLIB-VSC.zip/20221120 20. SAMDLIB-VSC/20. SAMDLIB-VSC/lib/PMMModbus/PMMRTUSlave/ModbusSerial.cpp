/*
ModbusSerial.cpp - Source for Modbus Serial Library
Copyright (C) 2014 André Sarmento Barbosa
*/
#include "ModbusSerial.h"

ModbusSerial::ModbusSerial()
{
}

bool ModbusSerial::setSlaveId(byte slaveId)
{
  _slaveId = slaveId;
  return true;
}

byte ModbusSerial::getSlaveId()
{
  return _slaveId;
}

#ifndef __AVR_ATmega32U4__
#ifndef DEBUG_MODE
bool ModbusSerial::config(HardwareSerial *port, long baud, int txPin)
{
  this->_port = port;
  this->_txPin = txPin;
  // (*port).begin(baud);

  if (txPin >= 0)
  {
    pinMode(txPin, OUTPUT);
    digitalWrite(txPin, LOW);
  }

  // Modbus states that a baud rate higher than 19200 must use a fixed 750 us
  // for inter character time out and 1.75 ms for a frame delay for baud rates
  // below 19200 the timing is more critical and has to be calculated.
  // E.g. 9600 baud in a 11 bit packet is 9600/11 = 872 characters per second
  // In milliseconds this will be 872 characters per 1000ms. So for 1 character
  // 1000ms/872 characters is 1.14583ms per character and finally modbus states
  // an inter-character must be 1.5T or 1.5 times longer than a character. Thus
  // 1.5T = 1.14583ms * 1.5 = 1.71875ms. A frame delay is 3.5T.
  // Thus the formula is T1.5(us) = (1000ms * 1000(us) * 1.5 * 11bits)/baud
  // 1000ms * 1000(us) * 1.5 * 11bits = 16500000 can be calculated as a constant

  if (baud > 19200)
    _t15 = 750;
  else
    _t15 = 16500000 / baud; // 1T * 1.5 = T1.5

  /* The modbus definition of a frame delay is a waiting period of 3.5 character times
  between packets. This is not quite the same as the frameDelay implemented in
  this library but does benifit from it.
  The frameDelay variable is mainly used to ensure that the last character is
  transmitted without truncation. A value of 2 character times is chosen which
  should suffice without holding the bus line high for too long.*/

  _t35 = _t15 * 3.5;

  return true;
}
#endif

#ifdef DEBUG_MODE
bool ModbusSerial::config(HardwareSerial *port,
                          HardwareSerial *DebugSerialPort, long baud, int txPin)
{
  this->_port = port;
  this->_txPin = txPin;
  //(*port).begin(baud);

  DebugPort = DebugSerialPort;

  if (txPin >= 0)
  {
    pinMode(txPin, OUTPUT);
    digitalWrite(txPin, LOW);
  }

  if (baud > 19200)
    _t15 = 750;
  else
    _t15 = 16500000 / baud; // 1T * 1.5 = T1.5

  _t35 = _t15 * 3.5;

  return true;
}
#endif

#ifdef USE_SOFTWARE_SERIAL
bool ModbusSerial::config(SoftwareSerial *port, long baud, int txPin)
{
  this->_port = port;
  this->_txPin = txPin;
  (*port).begin(baud);

  delay(2000);

  if (txPin >= 0)
  {
    pinMode(txPin, OUTPUT);
    digitalWrite(txPin, LOW);
  }

  if (baud > 19200)
    _t15 = 750;
  else
    _t15 = 16500000 / baud; // 1T * 1.5 = T1.5

  _t35 = _t15 * 3.5;

  return true;
}
#endif
#endif

#ifdef __AVR_ATmega32U4__
#ifdef DEBUG_MODE
bool ModbusSerial::config(HardwareSerial *port,
                          Serial_ *DebugSerialPort, long baud, int txPin)
{
  this->_port = port;
  this->_txPin = txPin;
  (*port).begin(baud);

  DebugPort = DebugSerialPort;

  if (txPin >= 0)
  {
    pinMode(txPin, OUTPUT);
    digitalWrite(txPin, LOW);
  }

  if (baud > 19200)
    _t15 = 750;
  else
    _t15 = 16500000 / baud; // 1T * 1.5 = T1.5

  _t35 = _t15 * 3.5;

  return true;
}
#else
bool ModbusSerial::config(Serial_ *port, long baud, int txPin)
{
  this->_port = port;
  this->_txPin = txPin;
  (*port).begin(baud);
  while (!(*port))
    ;

  if (txPin >= 0)
  {
    pinMode(txPin, OUTPUT);
    digitalWrite(txPin, LOW);
  }

  if (baud > 19200)
    _t15 = 750;
  else
    _t15 = 16500000 / baud; // 1T * 1.5 = T1.5

  _t35 = _t15 * 3.5;

  return true;
}
#endif
#endif

bool ModbusSerial::receive(byte *frame)
{
  // first byte of frame = address
  byte address = frame[0];
  // Last two bytes = crc
  // u_int crc = ((frame[_len - 2] << 8) | frame[_len - 1]); // Joghaimi Remove
  int crc = ((frame[_len - 2] << 8) | frame[_len - 1]); // Joghaimi
  // SerialUSB.print("\\ ** ");
  // SerialUSB.print(frame[_len - 2]);
  // SerialUSB.print(" ");
  // SerialUSB.print(frame[_len - 1]);

  // Slave Check
  if (address != 0xFF && address != this->getSlaveId())
  {

    return false;
  }
  // CRC Check
  // After 28 Register Error Accure 
  // if (crc != this->calcCrc(_frame[0], _frame + 1, _len - 3))
  // {
  //   SerialUSB.print("ERROR");
  //   return false;
  // }
  // PDU starts after first byte
  // framesize PDU = framesize - address(1) - crc(2)
  // for (int i = 0; i < 16; i++)
  // {
  // SerialUSB.print(frame[i], HEX);
  // SerialUSB.print(" * ");
  // }
  // SerialUSB.println();
  this->receivePDU(frame + 1);
  // No reply to Broadcasts
  if (address == 0xFF)
  {
    _reply = MB_REPLY_OFF;
    ;
  }

  return true;
}

bool ModbusSerial::send(byte *frame)
{
  byte i;

  if (this->_txPin >= 0)
  {
    digitalWrite(this->_txPin, HIGH);
    delay(1);
  }

  for (i = 0; i < _len; i++)
  {
    (*_port).write(frame[i]);
  }

  (*_port).flush();
  delayMicroseconds(_t35);

  if (this->_txPin >= 0)
  {
    digitalWrite(this->_txPin, LOW);
  }
}

bool ModbusSerial::sendPDU(byte *pduframe)
{
  if (this->_txPin >= 0)
  {
    digitalWrite(this->_txPin, HIGH);
    delay(1);
  }

  delayMicroseconds(_t35);

  // Send slaveId
  (*_port).write(_slaveId);

  // Send PDU
  byte i;
  for (i = 0; i < _len; i++)
  {
    (*_port).write(pduframe[i]);
  }

  // Send CRC
  word crc = calcCrc(_slaveId, _frame, _len);
  (*_port).write(crc >> 8);
  (*_port).write(crc & 0xFF);

  (*_port).flush();
  delayMicroseconds(_t35);

  if (this->_txPin >= 0)
  {
    digitalWrite(this->_txPin, LOW);
  }

#ifdef DEBUG_MODE
  (*DebugPort).println("SENT Serial RESPONSE");
  (*DebugPort).print(_slaveId);
  (*DebugPort).print(':');
  for (int i = 0; i < _len; i++)
  {
    (*DebugPort).print(_frame[i]);
    (*DebugPort).print(':');
  }
  (*DebugPort).print(crc >> 8);
  (*DebugPort).print(':');
  (*DebugPort).print(crc & 0xFF);
  (*DebugPort).print(':');
  (*DebugPort).println();
  (*DebugPort).println(F("-----------------"));
#endif
}

// ==== >>> Joghaimi
bool ModbusSerial::task(uint8_t &slaveid, uint8_t &thefunctionCode, uint16_t &startAddress, uint16_t &quentity)
{
  _len = 0;

  while ((*_port).available() > _len)
  {
    _len = (*_port).available();
    delayMicroseconds(_t15);
  }

  if (_len == 0)
  {
    free(_frame);
    _len = 0;
    return false;
  }

  byte i;
  _frame = (byte *)malloc(_len);
  for (i = 0; i < _len; i++)
  {
    _frame[i] = (*_port).read();
    // SerialUSB.print(_frame[i], HEX);
    // SerialUSB.print(" - ");
  }

  // SerialUSB.println();
  slaveid = _frame[0];
  thefunctionCode = _frame[1];
  startAddress = _frame[3] + _frame[2] * 16 * 16;
  quentity = _frame[5] + _frame[4] * 16 * 16;

  if (this->receive(_frame))
  {

    if (_reply == MB_REPLY_NORMAL)
    {
      this->sendPDU(_frame);
      // SerialUSB.print(" - ");
    }
    else if (_reply == MB_REPLY_ECHO)
    {
      this->send(_frame);
      // SerialUSB.print(" * ");
    }
  }
  else
  {
    // SerialUSB.print(" / ");
  }
  free(_frame);
  _len = 0;
  // SerialUSB.print(" _ ");
  return true;
}

bool ModbusSerial::task(int &functioncode)
{
  _len = 0;

  while ((*_port).available() > _len)
  {
    _len = (*_port).available();
    delayMicroseconds(_t15);
  }

  if (_len == 0)
  {
    free(_frame);
    _len = 0;
    return false;
  }

  byte i;
  _frame = (byte *)malloc(_len);
  for (i = 0; i < _len; i++)
  {
    _frame[i] = (*_port).read();
  }
  functioncode = _frame[1];
  // SerialUSB.println("======***********====");
  // byte _slaveId = _frame[0];
  // byte functioncode = _frame[1];
  // uint16_t startAddress = _frame[3] + _frame[2] * 16 * 16;
  // uint16_t quentity = _frame[5] + _frame[4] * 16 * 16;

#ifdef DEBUG_MODE
  (*DebugPort).println(F("GOT Serial CMD"));
  for (int i = 0; i < _len; i++)
  {
    (*DebugPort).print(_frame[i], DEC);
    (*DebugPort).print(":");
    //(*DebugPort).println(sendbuffer[i], HEX);
  }
  (*DebugPort).println();
  (*DebugPort).println(F("-----------------"));
#endif

  if (this->receive(_frame))
  {

    if (_reply == MB_REPLY_NORMAL)
    {
      this->sendPDU(_frame);
      // SerialUSB.println("Normal");
    }
    else if (_reply == MB_REPLY_ECHO)
    {
      this->send(_frame);
      // SerialUSB.println("Msh Normal");
    }
  }
  free(_frame);
  _len = 0;
  return true;
}
// Joghaimi
// bool ModbusSerial::PMMcalcCrc(byte address, uint16_t *pduFrame, byte pduLen, byte CRCHigh, byte CRCLow)
// {

//   uint16_t crc = 0xFFFF;
//   for (int pos = 0; pos < pduLen; pos++)
//   {
//     crc ^= (uint16_t)pduFrame[pos]; // XOR byte into least sig. byte of crc

//     for (int i = 8; i != 0; i--)
//     { // Loop over each bit
//       if ((crc & 0x0001) != 0)
//       {            // If the LSB is set
//         crc >>= 1; // Shift right and XOR 0xA001
//         crc ^= 0xA001;
//       }
//       else         // Else LSB is not set
//         crc >>= 1; // Just shift right
//     }
//   }
//   union
//   {
//     byte valueAsByte[2];
//     int valusAsInt;
//   } byteToInt;
//   byteToInt.valueAsByte[0] = CRCHigh;
//   byteToInt.valueAsByte[1] = CRCHigh;
//   // Note, this number has low and high bytes swapped, so use it accordingly (or swap bytes)
//   return crc;

//   /*
//    byte CRCHi = 0xFF, CRCLo = 0x0FF, Index;
//    Index = CRCHi ^ address;
//    CRCHi = CRCLo ^ _auchCRCHi[Index];
//    CRCLo = _auchCRCLo[Index];

//    while (pduLen--)
//    {
//      Index = CRCHi ^ *pduFrame++;
//      CRCHi = CRCLo ^ _auchCRCHi[Index];
//      CRCLo = _auchCRCLo[Index];
//    }
//    SerialUSB.print("---");
//    SerialUSB.print(CRCHi);
//    SerialUSB.print("-");
//    SerialUSB.print(CRCHigh);
//    SerialUSB.print("---");
//    SerialUSB.print(CRCLow);
//    SerialUSB.print("-");
//    SerialUSB.print(CRCLo);
//    SerialUSB.print("---");
//    if (CRCHi == CRCHigh && CRCLow == CRCLo)
//      return true;
//    else
//      return false;*/
// }

word ModbusSerial::calcCrc(byte address, byte *pduFrame, byte pduLen)
{
  
  byte CRCHi = 0xFF, CRCLo = 0x0FF, Index;

  Index = CRCHi ^ address;
  CRCHi = CRCLo ^ _auchCRCHi[Index];
  CRCLo = _auchCRCLo[Index];

  while (pduLen--)
  {
    Index = CRCHi ^ *pduFrame++;
    CRCHi = CRCLo ^ _auchCRCHi[Index];
    CRCLo = _auchCRCLo[Index];
  }


  return (CRCHi << 8) | CRCLo;
}


// The Working One

// word ModbusSerial::calcCrc(byte address, byte *pduFrame, byte pduLen)
// {
//   byte CRCHi = 0xFF, CRCLo = 0x0FF, Index;

//   Index = CRCHi ^ address;
//   CRCHi = CRCLo ^ _auchCRCHi[Index];
//   CRCLo = _auchCRCLo[Index];

//   while (pduLen--)
//   {
//     Index = CRCHi ^ *pduFrame++;
//     CRCHi = CRCLo ^ _auchCRCHi[Index];
//     CRCLo = _auchCRCLo[Index];
//   }
//   union
//   {
//     byte valueAsByte[2];
//     int valusAsInt;
//   } byteToInt;
//   byteToInt.valueAsByte[0] = CRCLo;
//   byteToInt.valueAsByte[1] = CRCHi;
//   SerialUSB.print(" ");
//   SerialUSB.print(CRCLo);
//   SerialUSB.print(" ");
//   SerialUSB.print(CRCHi);
//   SerialUSB.println(" ** /");

//   return (CRCHi << 8) | CRCLo;
// }
