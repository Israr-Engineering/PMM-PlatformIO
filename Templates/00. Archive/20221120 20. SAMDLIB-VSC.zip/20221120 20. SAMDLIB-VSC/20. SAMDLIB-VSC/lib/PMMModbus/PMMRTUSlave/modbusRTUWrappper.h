#ifndef modbusRTUWrappper
#define modbusRTUWrappper
#include <Arduino.h>
#include <PMMGlobalFunction.h>

// Modbus Configration
void PMMRTUSlaveStartConfig(Uart &serialPort, long baudRate, byte slaveid);
void PMMRTUSlaveStartConfig(Uart &serialPort, long baudRate, byte slaveid, byte enablePin);
void PMMInitRTUSlaveRegister(uint8_t slaveId, uint8_t type, uint16_t startAddress, uint8_t quintity);
void PMMRTUSlaveInitHoldingRegister(int startAddress, int numberOfHoldingReg);
void PMMRTUSlaveInitCoils(int numberOfcoils, int startAddress);

// Modbus Read/Write
void PMMRTUSlaveLoop(uint8_t devicesSlaveid, modBusCoils &outputCoils, modBusCoils &inputCoils, modBusHolding &outputHolding, modBusHolding &inputHolding);
bool PMMRTUSlaveLoop(uint8_t devicesSlaveid, modBusCoils &outputCoils, modBusCoils &inputCoils, modBusHolding &outputHolding, modBusHolding &inputHolding, bool hasReturnValue);

void PMMRTUSlaveStartCommunication(int &functionCode);
void PMMRTUSlaveReadCoils(int startAddress, int numberOfcoils, bool *outputArray);
void PMMRTUSlaveWriteCoils(int startAddress, int numberOfcoils, bool *outputArray);

void PMMRTUSlaveReadHoldingWrite(int startAddress, int numberOfHoldingReg, modBusHolding &HoldingRegArray);
void PMMRTUSlaveReadHoldingWrite(modBusHolding &HoldingRegArray);

void PMMRTUSlaveReadHoldingRead(modBusHolding OutputValues);
void PMMRTUSlaveReadHoldingRead(int startAddress, int numberOfHoldingReg, word HoldingRegArray[]);
// void PMMRTUSlaveReadHoldingRead(int startAddress, int numberOfHoldingReg, modBusHolding &HoldingRegArray);

extern bool modBusSlaveDO;
extern bool modBusSlaveDI;

#endif