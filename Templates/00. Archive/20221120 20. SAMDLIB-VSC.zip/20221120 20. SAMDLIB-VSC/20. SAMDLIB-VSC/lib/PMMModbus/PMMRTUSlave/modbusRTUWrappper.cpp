#include <PMMRTUSlave/modbusRTUWrappper.h>
#include <PMMRTUSlave/Modbus.h>
#include <PMMRTUSlave/ModbusSerial.h>

/**
 * To Do
 * Rearange folders and its names names
 * remove unused variable
 * make all of the functioan accessable from outSide
 * Make ModbusRTUCommunication Better
 */

ModbusSerial modbus;
bool ModbusState;

uint8_t PMMRTUSlaveid;
uint8_t PMMRTUFunctionCode;
uint16_t PMMRTUStartAddress;
uint16_t PMMRTUQuentity;
uint16_t bufferArray[81];

// word ahmad[16];
/**
 * Configue ModBus Slave Proceger
 *   - Call  PMMRTUSlaveStartConfig
 *   - Configure the registers using the following methods
 */
void PMMRTUSlaveStartConfig(Uart &serialPort, long baudRate, byte slaveid)
{
   // Note that the serial configration must be set before this part
   // serialPort.setTimeout(1);
   modbus.config(&serialPort, baudRate, 26);
   modbus.setSlaveId(slaveid);
}
void PMMRTUSlaveStartConfig(Uart &serialPort, long baudRate, byte slaveid, byte enablePin)
{
   // Note that the serial configration must be set before this part
   // serialPort.setTimeout(1);
   modbus.config(&serialPort, baudRate, enablePin);
   modbus.setSlaveId(slaveid);
}
/**
 * @brief Configure RTU Slave Addresses
 * @param slaveId
 * @param type
 * @param startAddress
 * @param quintity
 */
void PMMInitRTUSlaveRegister(uint8_t slaveId, uint8_t type, uint16_t startAddress, uint8_t quintity)
{
   Debugprintln("Start Register initalizing");
   if (type == 1)
   {
      PMMRTUSlaveInitCoils(quintity, startAddress);
      Debugprint("Congigure Coils Start From ");
      Debugprint(String(startAddress));
      Debugprint(" Quintity ");
      Debugprintln(String(quintity));
   }
   else if (type == 3)
   {
      PMMRTUSlaveInitHoldingRegister(startAddress, quintity);
      Debugprint("Congigure HoldingRegisters Start From ");
      Debugprint(String(startAddress));
      Debugprint(" Quintity ");
      Debugprintln(String(quintity));
   }
}
void PMMRTUSlaveInitCoils(int numberOfcoils, int startAddress)
{
   // Note : For Now Add coil start from 1 Always & startAddress is the offset only
   for (int i = 0; i < numberOfcoils; i++)
   {
      modbus.addCoil(startAddress + i);
   }
}
void PMMRTUSlaveInitHoldingRegister(int startAddress, int numberOfHoldingReg)
{
   // Note : For Now Add Holdingreg start from 40001 Always & startAddress is the offset only
   for (int i = 0; i < numberOfHoldingReg; i++)
   {
      modbus.addHreg(startAddress + i);
   }
}
void PMMRTUSlaveInitInputRegister(int startAddress, int numberOfInputRegister)
{
   startAddress = 30001;
   // Note : For Now Add input Regester start from 30001 Always & startAddress is the offset only
   for (int i = 0; i < numberOfInputRegister; i++)
   {
      modbus.addIreg(startAddress + i);
      // modbus.addIsts(startAddress + i); // Test
   }
}
void PMMRTUSlaveInitInputStatus(int startAddress, int numberOfInputStatus)
{
   // Note : For Now Add input Regester start from 30001 Always & startAddress is the offset only
   for (int i = 0; i < numberOfInputStatus; i++)
   {
      modbus.addIsts(startAddress + i);
   }
}

/*Read Write Proceger*/
void PMMRTUSlaveLoop(uint8_t devicesSlaveid, modBusCoils &outputCoils, modBusCoils &inputCoils, modBusHolding &outputHolding, modBusHolding &inputHolding)
{
   int functionCode = 0;
   PMMRTUFunctionCode = 0;
   PMMRTUSlaveStartCommunication(functionCode);
   if (ModbusState)
   {
      // SerialUSB.println(PMMRTUFunctionCode);
      if (PMMRTUFunctionCode == 1)
         PMMRTUSlaveWriteCoils(inputCoils.startAddress, inputCoils.quentity, inputCoils.boolArray);
      if (PMMRTUFunctionCode == 15)
         PMMRTUSlaveReadCoils(outputCoils.startAddress, outputCoils.quentity, outputCoils.boolArrayCurrent);
      if (PMMRTUFunctionCode == 3)
         // PMMRTUSlaveReadHoldingWrite(inputHolding.startAddress, inputHolding.quentity, inputHolding);
         PMMRTUSlaveReadHoldingWrite(inputHolding);
      if (PMMRTUFunctionCode == 16)
         PMMRTUSlaveReadHoldingRead(outputHolding);
      // PMMRTUSlaveReadHoldingRead(outputHolding.startAddress, outputHolding.quentity, outputHolding.outputValue);
   }
}






//====>> APPlay only in tracker -- Joghaimi
/// @brief Read/Write Modbus Slave
/// @param devicesSlaveid
/// @param outputCoils
/// @param inputCoils
/// @param outputHolding
/// @param inputHolding
/// @return Modbus State
bool PMMRTUSlaveLoop(uint8_t devicesSlaveid, modBusCoils &outputCoils, modBusCoils &inputCoils, modBusHolding &outputHolding, modBusHolding &inputHolding, bool hasReturnValue)
{
   int functionCode = 0;
   PMMRTUFunctionCode = 0;
   PMMRTUSlaveStartCommunication(functionCode);
   if (ModbusState)
   {

      // Full Read Holding Register 
      // ReadOut Holding Register
      if (PMMRTUFunctionCode == 1)
         PMMRTUSlaveWriteCoils(inputCoils.startAddress, inputCoils.quentity, inputCoils.boolArray);
      if (PMMRTUFunctionCode == 15)
         PMMRTUSlaveReadCoils(outputCoils.startAddress, outputCoils.quentity, outputCoils.boolArrayCurrent);
      if (PMMRTUFunctionCode == 3)
         PMMRTUSlaveReadHoldingWrite(inputHolding);
      if (PMMRTUFunctionCode == 16 || PMMRTUFunctionCode == 6)
         PMMRTUSlaveReadHoldingRead(outputHolding);
   }
   return ModbusState;
}

void PMMRTUSlaveStartCommunication(int &functionCode)
{

   ModbusState = modbus.task(PMMRTUSlaveid, PMMRTUFunctionCode, PMMRTUStartAddress, PMMRTUQuentity);
   if (PMMRTUFunctionCode == 6)
      PMMRTUQuentity = 1;
}
void PMMRTUSlaveReadCoils(int startAddress, int numberOfcoils, bool *outputArray)
{

   if (ModbusState)
   {
      for (int i = 0; i < numberOfcoils; i++)
         outputArray[i] = modbus.Coil(startAddress + i);
   }
}
void PMMRTUSlaveWriteCoils(int startAddress, int numberOfcoils, bool *outputArray)
{
   if (ModbusState)
      for (int i = 0; i < numberOfcoils; i++)
         modbus.Coil(startAddress + i, outputArray[i]);
}

// The New Form
void PMMRTUSlaveReadHoldingWrite(modBusHolding &HoldingRegArray)
{
   if (ModbusState)
   {
      byte startIndex = PMMRTUStartAddress - HoldingRegArray.startAddress;
      for (int i = 0; i < PMMRTUQuentity; i++, startIndex++)
         modbus.Hreg(PMMRTUStartAddress + i, HoldingRegArray.outputValue[startIndex]);
   }
}

// The New Form
void PMMRTUSlaveReadHoldingRead(modBusHolding OutputValues)
{
   if (ModbusState)
   {
      byte startIndex = PMMRTUStartAddress - OutputValues.startAddress;
      for (int i = 0; i < PMMRTUQuentity; i++, startIndex++)
         OutputValues.outputValue[startIndex] = modbus.Hreg(PMMRTUStartAddress + i);
   }
}
// The Old Form
void PMMRTUSlaveReadHoldingRead(int startAddress, int numberOfHoldingReg, word HoldingRegArray[])
{
   if (ModbusState)
   {
      byte startIndex = PMMRTUStartAddress - startAddress;

      for (int i = startIndex; i < PMMRTUQuentity; i++)
      {
         HoldingRegArray[i] = modbus.Hreg(PMMRTUStartAddress + i);
      }
   }
}
// The Old Form
void PMMRTUSlaveReadHoldingWrite(int startAddress, int numberOfHoldingReg, modBusHolding &HoldingRegArray)
{

   uint8_t arrayindex = 0;
   startAddress = 1;
   for (int i = 0; i < numberOfHoldingReg; i++)
   {
      modbus.Hreg(startAddress + i, HoldingRegArray.holingArray[arrayindex].floatToInt.valueAsInt[0]);
      i++;
      modbus.Hreg(startAddress + i, HoldingRegArray.holingArray[arrayindex].floatToInt.valueAsInt[1]);
      arrayindex++;
   }
}