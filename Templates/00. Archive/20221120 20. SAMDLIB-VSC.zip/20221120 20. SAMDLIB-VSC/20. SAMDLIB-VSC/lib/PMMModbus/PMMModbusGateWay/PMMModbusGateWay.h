
#include <Arduino.h>
#include <SPI.h>
#include <Ethernet.h>
#include <ArduinoRS485.h> // ArduinoModbus depends on the ArduinoRS485 library
#include <ArduinoModbus.h>
#include <projectConfigration.h>
#include <ModbusMaster.h>
#ifndef PMMModbusGateWay
#define PMMModbusGateWay

extern uint8_t resetButton;
extern uint8_t EthernetCS;
extern String controllerIPAddress;
extern String subNetMask;
extern String DNS;
extern String GatWay;
extern String remoteIPAddress;
extern String UDPPort;
extern String MACAddressString;
extern String controllerSerialNumber;
extern byte mac[6];
extern bool inDebugMode;
extern String readCoilAdd;
extern String ReadCoilQuint;
extern String ReadHoldingAdd;
extern String ReadHoldingQuint;
extern bool PMM0501Device;
extern bool PMM0406Device;

void PMMGateWayinitalize();
void PMMGateWayLoop();
void PMMModBUSTCPPoll(uint8_t &slaveid, uint8_t &functionCode, uint16_t &startAddress, uint8_t &quentity);
void PMMTCPConnectionEnd(int slaveid);
// uint8_t PMMTCPRTUBridgegetSerialAndRTUSlaveId(UARTClass &uartPort, int slaveid); // Uncoment this For Duw
void PMMReturnErrorCode(int ErrorCode);
void PMMReturnNoErrorCode();
// void PMMCheckIfConfigerd(uint8_t functionCode, int startAddress, uint8_t id);
void PMMCheckIfConfigerd(uint8_t functionCode, int startAddress, uint16_t quentity, uint8_t id);
uint8_t PMMTCPRTUBridgegetSerialAndRTUSlaveId(Stream &uartPort, int slaveid);
void clearMovingData(uint16_t registerAddress, uint16_t salveid);

// GateWay Functiona
void PMMTCPRTUBridgReadInputRegister(uint8_t salveid, uint8_t RTUsalveid, Stream &serialPort, uint16_t startAddress, uint8_t quntity, uint8_t functionCode);
void PMMTCPRTUBridgWriteMultibleCoils(uint8_t salveid, uint8_t RTUsalveid, Stream &serialPort, uint16_t startAddress, uint8_t quntity, uint8_t functionCode);
void PMMTCPRTUBridgReadMultibleCoils(uint8_t salveid, uint8_t RTUsalveid, Stream &serialPort, uint16_t startAddress, uint8_t quntity, uint8_t functionCode);
void PMMTCPRTUBridgeWriteHoldingReg(uint8_t salveid, uint8_t RTUsalveid, Stream &serialPort, uint16_t startAddress, uint8_t quntity, uint8_t functionCode);
void PMMTCPRTUBridgeReadHoldingReg(uint8_t salveid, uint8_t RTUsalveid, Stream &serialPort, uint16_t startAddress, uint8_t, uint8_t functionCode);
#endif
