#include <PMMModbusGateWay/PMMModbusGateWay.h>

/****
 * PMM GateWay : Gatway From TCP Master To RTU Slave
 * in case of Arduino Due Some changes need to be Add
 *  - Uncoment from .h & CPP PMMTCPRTUBridgegetSerialAndRTUSlaveId
 *  - Remove Serial in all reading write function and replace it with RTUsalveid parameter
 *
 */
// === Configure MODBUS TCP
EthernetServer EthrServer(502);
ModbusTCPServer PMMmodbusTCPServer;
IPAddress PMMMODBUSControllerIP;
IPAddress PMMMODBUSSubNetMaskIP;
IPAddress PMMMODBUSControllerDNS;
IPAddress PMMMODBUSGatWayIP;
uint8_t request[260];
int holdingRegStartAddres[128];
int coilStartAddres[128];
int inputRegister[128];
int requestLength = 0;
ModbusMaster RTUMaster;
uint8_t RTUSlaveID;
uint8_t slaveid = 0;
uint8_t functionCode = 0;
uint16_t startAddress = 0;
uint8_t quentity = 0;
int dec = 0;
int timming = 0;

void PMMGateWayinitalize()
{
    /**
     * gateWayinitalize : init the TCP Connection and get the IP Address subnets &
     * Mac Address From the EEPROM
     */
    PMMMODBUSControllerIP.fromString(controllerIPAddress);
    PMMMODBUSSubNetMaskIP.fromString(subNetMask);
    PMMMODBUSControllerDNS.fromString(DNS);
    PMMMODBUSGatWayIP.fromString(GatWay);
    Ethernet.init(EthernetCS);
    Ethernet.begin(mac, PMMMODBUSControllerIP, PMMMODBUSControllerDNS, PMMMODBUSGatWayIP, PMMMODBUSSubNetMaskIP);
    EthrServer.begin();
    uint8_t init = PMMmodbusTCPServer.begin(3);
    for (byte i = 1; i < 129; i++)
    {
        holdingRegStartAddres[i] = -125;
        coilStartAddres[i] = -125;
        inputRegister[i] = -125;
    }
    // memset(holdingRegStartAddres, -125, 128);
    // memset(coilStartAddres, -125, 128);
    // memset(inputRegister, -125, 128);
    // SerialUSB.println("=======");

    SerialUSB.println(holdingRegStartAddres[0]);
    SerialUSB.println(holdingRegStartAddres[33]);
    if (init == 1 && inDebugMode)
    {
        SerialUSB.println("MODBUS TCP Success!");
    }
    else if (init != 1 && inDebugMode)
    {
        SerialUSB.println("ERROR IN TCP CONNECTION !!");
    }
}
bool Requested = false;
void PMMGateWayLoop()
{
    /**
     * checkTCPConnection : Check if their is ModBus TCP Request & Return the
     * Slave id & the Function code
     */
    EthernetClient client = EthrServer.available();
    slaveid = 0;
    functionCode = 0;
    startAddress = 0;
    quentity = 0;
    Uart UARTPort = Serial;
    if (client.connected())
    {
        PMMmodbusTCPServer.accept(client);

        PMMModBUSTCPPoll(slaveid, functionCode, startAddress, quentity);
        RTUSlaveID = PMMTCPRTUBridgegetSerialAndRTUSlaveId(UARTPort, slaveid); // Uncoment this For Due
        PMMTCPRTUBridgeReadHoldingReg(slaveid, RTUSlaveID, UARTPort, startAddress, quentity, functionCode);
        PMMTCPRTUBridgeWriteHoldingReg(slaveid, RTUSlaveID, UARTPort, startAddress, quentity, functionCode);
        PMMTCPRTUBridgReadMultibleCoils(slaveid, RTUSlaveID, UARTPort, startAddress, quentity, functionCode);
        PMMTCPRTUBridgWriteMultibleCoils(slaveid, RTUSlaveID, UARTPort, startAddress, quentity, functionCode);
        PMMTCPRTUBridgReadInputRegister(slaveid, RTUSlaveID, UARTPort, startAddress, quentity, functionCode);
        PMMTCPConnectionEnd(slaveid);
    }
}
// Communication Functions
void PMMReturnErrorCode(int ErrorCode)
{
    PMMmodbusTCPServer.hasError = true;
    PMMmodbusTCPServer.errorCode = ErrorCode;
}
void PMMReturnNoErrorCode()
{
    PMMmodbusTCPServer.hasError = false;
}
void PMMModBUSTCPPoll(uint8_t &slaveid, uint8_t &functionCode, uint16_t &startAddress, uint8_t &quentity)
{
    requestLength = modbus_receive(PMMmodbusTCPServer._mb, request);
    slaveid = request[6];
    functionCode = request[7];
    startAddress = request[9] + request[8] * 16 * 16;
    quentity = request[11] + request[10] * 16 * 16;
    if (slaveid > 0)
        PMMCheckIfConfigerd(functionCode, startAddress, quentity, slaveid);
}
void PMMTCPConnectionEnd(int slaveid)
{
    if (requestLength <= 0)
        return;
    if (!PMMmodbusTCPServer.hasError)
        modbus_reply(PMMmodbusTCPServer._mb, request, requestLength, &PMMmodbusTCPServer._mbMappings[slaveid], slaveid);
    else
    {
        modbus_reply_exception(PMMmodbusTCPServer._mb, request, PMMmodbusTCPServer.errorCode);
        PMMReturnNoErrorCode();
    }
}
void PMMCheckIfConfigerd(uint8_t functionCode, int startAddress, uint16_t quentity, uint8_t id)
{

    if (functionCode == 3 || functionCode == 6 || functionCode == 16)
    {
        bool checkIfInRange = (startAddress + quentity <= holdingRegStartAddres[id] + 125) &&
                              (startAddress >= holdingRegStartAddres[id]);
        if (!checkIfInRange)
        {
            PMMmodbusTCPServer.configureHoldingRegisters(startAddress, 125, id);
            holdingRegStartAddres[id] = startAddress;
        }
    }
    else if (functionCode == 1 || functionCode == 5 || functionCode == 15)
    {
        bool checkIfInRange = (startAddress + quentity <= coilStartAddres[id] + 125) &&
                              (startAddress >= coilStartAddres[id]);
        if (!checkIfInRange)
        {
            if (startAddress + quentity > (coilStartAddres[id] + 125))
            {
                PMMmodbusTCPServer.configureCoils(startAddress, 125, id);
                coilStartAddres[id] = startAddress;
            }
        }
    }
    else if (functionCode == 4)
    {
        bool checkIfInRange = (startAddress + quentity <= inputRegister[id] + 125) &&
                              (startAddress >= inputRegister[id]);
        if (!checkIfInRange)
        {
            PMMmodbusTCPServer.configureInputRegisters(startAddress, 125, id);
            inputRegister[id] = startAddress;
        }
    }
}
// PMMGATEWAY Function
void PMMTCPRTUBridgeReadHoldingReg(uint8_t salveid, uint8_t RTUsalveid, Stream &serialPort, uint16_t startAddress, uint8_t quntity, uint8_t functionCode)
{
    /**
     * TCP - RTU Converter
     * Function code 0x3
     * Read Holding reg From RTU and Write it on the TCP
     * @param uint8_t salveid :RTU Slave id or TCP Slave id
     * @param serialPort RTU Serial port
     */
    // Initalize ModBus RTU Master
    // RTUsalveid = 1; // Joghaimi
    if (functionCode != 3)
        return;
    if (PMM0501Device)
    {
        if (dec < 32)
            RTUMaster.begin(RTUsalveid, Serial); // Checked || Confirned
        else if (dec < 64)
            RTUMaster.begin(RTUsalveid, Serial1); //  Checked || Confirned
    }
    else if (PMM0406Device)
    {

        if (dec < 32)
            RTUMaster.begin(RTUsalveid, Serial2); // Checked || Confirned
        else if (dec < 64)
            RTUMaster.begin(RTUsalveid, Serial); //  Checked || Confirned
        else if (dec < 96)
            RTUMaster.begin(RTUsalveid, Serial1); //  Checked || Confirned
        else
            RTUMaster.begin(RTUsalveid, Serial3); // Checked || Confirned
    }
    // SerialUSB.print("0");
    // SerialUSB.print(startAddress);
    // SerialUSB.print(quntity);
    // Read Multibe Holding reg || it returen the ErrorCode
    uint8_t resposneCode = RTUMaster.readHoldingRegisters(startAddress, quntity);
    // SerialUSB.print("0");

    // Return Error code if their any
    if (resposneCode != 0)
        PMMReturnErrorCode(resposneCode);
    // Return Response Directly to TCP Buffer

    for (int i = 0; i < quntity; i++)
        PMMmodbusTCPServer._mbMappings[salveid].tab_registers[startAddress + i - holdingRegStartAddres[salveid]] = RTUMaster._u16ResponseBuffer[i];
    // === The Worked one
    // PMMmodbusTCPServer._mbMappings[salveid].tab_registers = RTUMaster._u16ResponseBuffer;
    // === Try Two
    // memcpy((PMMmodbusTCPServer._mbMappings[salveid].tab_registers + (startAddress - holdingRegStartAddres[salveid])),
    //        RTUMaster._u16ResponseBuffer, quntity);
}
void PMMTCPRTUBridgeWriteHoldingReg(uint8_t salveid, uint8_t RTUsalveid, Stream &serialPort, uint16_t startAddress, uint8_t quntity, uint8_t functionCode)
{
    /**
     * TCP - RTU Converter
     * Function code 0x16
     * Read Holding reg From TCP and Write it on the RTU
     * @param uint8_t salveid :RTU Slave id or TCP Slave id
     * @param serialPort RTU Serial port
     */
    // Initalize ModBus RTU Master
    // RTUsalveid = 1; // Joghaimi

    if (functionCode != 16 && functionCode != 6)
        return;
    if (functionCode == 6)
        quntity = 1;
    if (PMM0501Device)
    {
        if (dec < 32)
            RTUMaster.begin(RTUsalveid, Serial); // Checked || Confirned
        else if (dec < 64)
            RTUMaster.begin(RTUsalveid, Serial1); //  Checked || Confirned
    }
    else if (PMM0406Device)
    {
        if (dec < 32)
            RTUMaster.begin(RTUsalveid, Serial2); // Checked || Confirned
        else if (dec < 64)
            RTUMaster.begin(RTUsalveid, Serial); //  Checked || Confirned
        else if (dec < 96)
            RTUMaster.begin(RTUsalveid, Serial1); //  Checked || Confirned
        else
            RTUMaster.begin(RTUsalveid, Serial3); // Checked || Confirned
    }
    uint8_t resposneCode = 0;
    uint8_t registerAddress = 0;

    for (int i = 0; i < quntity; i++)
    {
        registerAddress = startAddress + i - PMMmodbusTCPServer._mbMappings[salveid].start_registers;
        RTUMaster._u16TransmitBuffer[i] = PMMmodbusTCPServer._mbMappings[salveid].tab_registers[registerAddress];
    }
    resposneCode = RTUMaster.writeMultipleRegisters(startAddress, quntity);
    // Return Error code if their any
    if (resposneCode != 0)
    {
        // SerialUSB.println(resposneCode);
        PMMReturnErrorCode(resposneCode);
    }
}
// Void Clear
void PMMTCPRTUBridgReadMultibleCoils(uint8_t salveid, uint8_t RTUsalveid, Stream &serialPort, uint16_t startAddress, uint8_t quntity, uint8_t functionCode)
{
    /**
     * TCP - RTU Converter
     * Function code 0x15
     * Read Multible Coils From TCP and Write it on the RTU
     * @param uint8_t salveid :RTU Slave id or TCP Slave id
     * @param serialPort RTU Serial port
     */
    // Initalize ModBus RTU Master
    // RTUsalveid = 1; // Joghaimi

    if (functionCode != 15 && functionCode != 5)
        return;
    if (functionCode == 5)
        quntity = 1;

    if (PMM0501Device)
    {
        if (dec < 32)
            RTUMaster.begin(RTUsalveid, Serial); // Checked || Confirned
        else if (dec < 64)
            RTUMaster.begin(RTUsalveid, Serial1); //  Checked || Confirned
    }
    else if (PMM0406Device)
    {
        if (dec < 32)
            RTUMaster.begin(RTUsalveid, Serial2); // Checked || Confirned
        else if (dec < 64)
            RTUMaster.begin(RTUsalveid, Serial); //  Checked || Confirned
        else if (dec < 96)
            RTUMaster.begin(RTUsalveid, Serial1); //  Checked || Confirned
        else
            RTUMaster.begin(RTUsalveid, Serial3); // Checked || Confirned
    }
    // Get Data From TCP
    uint8_t resposneCode = 0;
    while (quntity > 0)
    {
        if (quntity > 16)
        {
            RTUMaster.setTransmitBuffer(0, PMMmodbusTCPServer.coilsRead(startAddress, 16, salveid));
            resposneCode = RTUMaster.writeMultipleCoils(startAddress, 16);
            quntity -= 16;
            startAddress += 16;
        }
        else
        {
            RTUMaster.setTransmitBuffer(0, PMMmodbusTCPServer.coilsRead(startAddress, quntity, salveid));
            resposneCode = RTUMaster.writeMultipleCoils(startAddress, quntity);
            quntity = 0;
            startAddress += quntity;
        }
    }
    // Return ERROR if their RTU Error
    if (resposneCode != 0)
        PMMReturnErrorCode(resposneCode);
}
void PMMTCPRTUBridgWriteMultibleCoils(uint8_t salveid, uint8_t RTUsalveid, Stream &serialPort, uint16_t startAddress, uint8_t quntity, uint8_t functionCode)
{
    /**
     * TCP - RTU Converter
     * Function code 0x01
     * Read Multible Coils From RTU and Write it on the TCP
     * @param uint8_t salveid :RTU Slave id or TCP Slave id
     * @param serialPort RTU Serial port
     */
    // Initalize ModBus RTU Master
    // RTUsalveid = 1; // Joghaimi

    if (functionCode != 1)
        return;
    if (PMM0501Device)
    {
        if (dec < 32)
            RTUMaster.begin(RTUsalveid, Serial); // Checked || Confirned
        else if (dec < 64)
            RTUMaster.begin(RTUsalveid, Serial1); //  Checked || Confirned
    }
    else if (PMM0406Device)
    {
        if (dec < 32)
            RTUMaster.begin(RTUsalveid, Serial2); // Checked || Confirned
        else if (dec < 64)
            RTUMaster.begin(RTUsalveid, Serial); //  Checked || Confirned
        else if (dec < 96)
            RTUMaster.begin(RTUsalveid, Serial1); //  Checked || Confirned
        else
            RTUMaster.begin(RTUsalveid, Serial3); // Checked || Confirned
    }
    uint8_t resposneCode = 0;
    // Get Data From RTU
    RTUMaster.clearResponseBuffer();
    resposneCode = RTUMaster.readCoils(startAddress, quntity);
    uint16_t numberOfIteration = ceil((quntity) / 16) + 1;
    for (uint8_t i = 0; i < numberOfIteration; i++)
    {
        PMMmodbusTCPServer.coilsWrite(startAddress + (i * 16), 16, RTUMaster.getResponseBuffer(i), salveid);
    }
    // Return ERROR if their RTU Error
    if (resposneCode != 0)
        PMMReturnErrorCode(resposneCode);
}
void PMMTCPRTUBridgReadInputRegister(uint8_t salveid, uint8_t RTUsalveid, Stream &serialPort, uint16_t startAddress, uint8_t quntity, uint8_t functionCode)
{
    /**
     * TCP - RTU Converter
     * Function code 0x04
     * Read Input From RTU and Write it on the TCP
     * @param uint8_t salveid :RTU Slave id or TCP Slave id
     * @param serialPort RTU Serial port
     * @param startAddress
     * @param quntity
     */
    // Initalize ModBus RTU Master
    // RTUsalveid = 1; // Joghaimi

    if (functionCode != 4)
        return;

    if (PMM0501Device)
    {
        if (dec < 32)
            RTUMaster.begin(RTUsalveid, Serial); // Checked || Confirned
        else if (dec < 64)
            RTUMaster.begin(RTUsalveid, Serial1); //  Checked || Confirned
    }
    else if (PMM0406Device)
    {
        if (dec < 32)
            RTUMaster.begin(RTUsalveid, Serial2); // Checked || Confirned
        else if (dec < 64)
            RTUMaster.begin(RTUsalveid, Serial); //  Checked || Confirned
        else if (dec < 96)
            RTUMaster.begin(RTUsalveid, Serial1); //  Checked || Confirned
        else
            RTUMaster.begin(RTUsalveid, Serial3); // Checked || Confirned
    }
    uint8_t resposneCode = 0;
    // Make RTU Request
    resposneCode = RTUMaster.readInputRegisters(startAddress, quntity);
    for (int i = 0; i < quntity; i++)
    {
        PMMmodbusTCPServer._mbMappings[salveid].tab_input_registers[startAddress + i - PMMmodbusTCPServer._mbMappings[salveid].start_input_registers] = RTUMaster.getResponseBuffer(i);
    }
    // memcpy(PMMmodbusTCPServer._mbMappings[salveid].tab_input_registers + (startAddress - inputRegister[salveid]), RTUMaster._u16ResponseBuffer, quntity);

    // (PMMmodbusTCPServer._mbMappings[salveid].tab_input_registers + (startAddress - PMMmodbusTCPServer._mbMappings[salveid].start_input_registers)),
    //        RTUMaster._u16ResponseBuffer, quntity)
    // Return ERROR if their RTU Error
    if (resposneCode != 0)
        PMMReturnErrorCode(resposneCode);
}
// Uncoment This For Due
uint8_t PMMTCPRTUBridgegetSerialAndRTUSlaveId(Stream &uartPort, int slaveid)
{

    /**
     *  getSerialAndSlaveId : it get the real slave id and the port attached to it
     *  @param  uartPort : in this pointer we save the Serial port
     *  @param  slaveid : the TCP slave ID
     *  @param  dec: in this pointer we save the number of decremunt
     */
    /*
     *  COM1 1  - 31
     *  COM2 32 - 63
     *  COM3 64 - 95
     *  COM4 96
     */
    // slaveid = 1; // Joghaimi

    if (PMM0501Device)
    {

        if (slaveid <= 32)
        {
            uartPort = Serial;
            dec = 0;
        }
        if (slaveid > 32)
        {
            uartPort = Serial1;
            dec = 32;
        }
    }
    else if (PMM0406Device)
    {
        if (slaveid <= 32)
        {
            uartPort = Serial;
            dec = 0;
        }
        else if (slaveid >= 33 && slaveid <= 64)
        {
            uartPort = Serial1;
            dec = 32;
        }
        else if (slaveid >= 65 && slaveid <= 96)
        {
            uartPort = Serial2;
            dec = 64;
        }
        else
        {
            uartPort = Serial3;
            dec = 96;
        }
    }
    return slaveid - dec;
}
