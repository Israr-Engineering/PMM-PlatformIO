

#ifndef PMMRTUMaster
#define PMMRTUMaster
#include <Arduino.h>
#include <ModbusMaster.h>
#include <Ethernet.h>
// #include <IOLib.h>
void initModBusRTU();
void initalizeModBusMaster();
void RTUCommunication();
void initModBusRTUSlaves();
void writToModBus();
void readRTU();
void readRTUCoils();
uint8_t readInputRegister(uint16_t portNumber, ModbusMaster &modBusMaster, uint16_t startAddress, uint16_t numberOfregister);
void initHoldingFunction(ModbusMaster &refSe, int startAddress, int EndAddress, int TCPSlaveAddress);
uint8_t initCoilFunction(uint16_t portNumber, ModbusMaster &modBusMaster,uint16_t RTUSlaveID, uint16_t startAddress,uint16_t endAddress, int TCPSlave);
bool checkResponse(uint8_t resbonse, ModbusMaster &modBusMaster);
uint8_t initReadRegisterFunction(uint16_t portNumber,ModbusMaster &modBusMaster,int startAddress,uint16_t numberOfregister);
void writeCoilFunction(ModbusMaster &modBusMaster, uint16_t address,uint16_t value);
void writeMultibleCoilFunction(ModbusMaster &modBusMaster, uint16_t address, uint16_t numberOfCoil, uint16_t value);
void readCoils(uint8_t slaveid);
void writeHoldingRegFunction(ModbusMaster &modBusMaster, int address, uint16_t value);
void readRegister();
void getCommand(int slaveID);
extern uint16_t outputState;

#endif
