#include <PMMRTUMaster/PMMRTUMaster.h>

/**
 * ToDo in this place ->
 * initalizeModBusMaster:
 *   - Change the Serial to be changable
 *   - change the RTUSlaveID to be changable
 * RTUCommunication:
 *   - Remove unused variables
 * Make all print depend on in debug variable
 * Rearange the code and do all comments
 */

ModbusMaster modbusMasterRTU;
uint16_t RTURSPONSE[15] = {255};            // FOR Coils
uint16_t RTURHoldingRegSPONSE[500] = {255}; // TODO Maximum Number Of register read in the same Time
uint16_t RTURInputRegSPONSE[500] = {255};
int RTUSlaveID = 1;   // TODO Make Slave address changable
int startAddress = 0; // TODO Make startAddress changable
uint16_t quanitity = 8;
void initalizeModBusMaster()
{
    /**
     * Initalize ModBus Slave : Use This Function on the RTU Devices
     * Always Call This function after Initalise Serial ports
     */
    Serial.begin(9600);
    modbusMasterRTU.begin(RTUSlaveID, Serial);
}
void PMMInitalizeModBusMaster(byte PMMRTUMasterId, Stream &PMMRTUMastePort, byte PMMRTUMasterEnablePin)
{
    // TODO Joghaimi
}

void RTUCommunication()
{
    // Read Coils
    initCoilFunction(1, modbusMasterRTU, RTUSlaveID, startAddress, quanitity, 0); // This Well Save Data In RTURSPONSE and return the number of array Element
    // Save The Response in External Int
    outputState = RTURSPONSE[0];
    SerialUSB.println(outputState);
}

bool checkResponse(uint8_t resbonse, ModbusMaster &modBusMaster)
{
    /***
     * checkResponse is check the Response of the RTU
     * Return true if the request is correct
     * return false if the request has error and print the Error on the Serial
     *PORT
     * @param resbonse is the Code Number
     * @param modBusMaster is modBusMaster obj
     **/
    if (resbonse == modBusMaster.ku8MBIllegalFunction)
    {
        // Serial.println("IllegalFunction");
        return false;
    }
    else if (resbonse == modBusMaster.ku8MBSlaveDeviceFailure)
    {
        // Serial.println("Slave Device Failure");
        return false;
    }
    else if (resbonse == modBusMaster.ku8MBInvalidCRC)
    {
        // Serial.println("Invalid CRC");
        return false;
    }
    else if (resbonse == modBusMaster.ku8MBResponseTimedOut)
    {
        // Serial.println("ResponseTimedOut");
        return false;
    }
    else if (resbonse == modBusMaster.ku8MBIllegalDataValue)
    {
        // Serial.println("IllegalDataValue");
        return false;
    }
    else if (resbonse == modBusMaster.ku8MBInvalidSlaveID)
    {
        // Serial.println("InvalidSlaveID");
        return false;
    }
    else if (resbonse == modBusMaster.ku8MBInvalidFunction)
    {
        // Serial.println("InvalidFunction");
        return false;
    }
    else if (resbonse == modBusMaster.ku8MBSuccess)
    {
        return true;
    }
    else
    {
        return false;
    }
}
uint8_t initCoilFunction(uint16_t portNumber, ModbusMaster &modBusMaster,
                         uint16_t RTUSlaveID, uint16_t startAddress,
                         uint16_t numberOfCoil, int TCPSlave)
{
    /***
     * initCoilFunction For reading Coils From RTU and save the response in
     * RTURSPONSE Array
     * @param uint16_t portNumber : the Serial Port that has the slave in it
     * @param ModbusMaster modBusMaster : RTU Obj
     * @param uint16_t RTUSlaveID   : RTU Slave ID
     * @param uint16_t startAddress : Staring Coil Address
     * @param uint16_t numberOfCoil : Number of coils to Read
     * @param TCPSlave
     **/
    modBusMaster.clearResponseBuffer();
    RTURSPONSE[15] = {255};
    uint8_t res = modBusMaster.readCoils(startAddress, numberOfCoil);
    uint8_t i = 0;
    if (checkResponse(res, modBusMaster))
    {
        uint16_t numberOfIteration = ceil((numberOfCoil) / 16) + 1;
        for (i = 0; i < numberOfIteration; i++)
        {
            RTURSPONSE[i] = modBusMaster.getResponseBuffer(i);
        }
    }
    return i;
}
uint8_t initReadRegisterFunction(uint16_t portNumber,
                                 ModbusMaster &modBusMaster, int startAddress,
                                 uint16_t numberOfregister)
{
    /***
     * initReadRegisterFunction For Reading Holding Reg From RTU And save the
     * Reponse in RTURHoldingRegSPONSE Array
     * @param  portNumber : the Serial Port that has the slave in it
     * @param  modBusMaster : RTU Obj
     * @param  startAddress : Staring Holding Reg Address
     * @param  numberOfregister : Number of Register to Read
     * Maximum NumberOf reading THE same Time is 100 Reg
     *
     * */
    if (numberOfregister > 100)
    {
        // Serial.println("Max read Function at the same time is 100");
        return 0;
    }
    uint8_t res =
        modBusMaster.readHoldingRegisters(startAddress, numberOfregister);
    uint8_t i = 0;

    if (checkResponse(res, modBusMaster))
    {
        for (i = 0; i < numberOfregister; i++)
        {
            RTURHoldingRegSPONSE[i] = modBusMaster.getResponseBuffer(i);
        }
    }
    return i;
}

void writeCoilFunction(ModbusMaster &modBusMaster, uint16_t address,
                       uint16_t value)
{
    /***
     * writeCoilFunction For Reading Coil Reg From TCP And Writeit onthe RTU
     * @param ModbusMaster modBusMaster : RTU Obj
     * @param uint16_t address : Coil Address
     * @param uint16_t value : Coil Value
     *
     **/
    modBusMaster.writeSingleCoil(address, value);
}

void writeMultibleCoilFunction(ModbusMaster &modBusMaster, uint16_t address,
                               uint16_t numberOfCoil, uint16_t value)
{
    /***
     * writeMultibleCoilFunction For Reading Coil Reg From TCP And Write it on the
     *RTU
     * @param ModbusMaster modBusMaster : RTU Obj
     * @param uint16_t address : Coil Address
     * @param uint16_t value : Coil Value
     * @param uint16_t numberOfCoil
     *
     **/
    modBusMaster.setTransmitBuffer(0, value);
    modBusMaster.writeMultipleCoils(address, numberOfCoil);
}

void writeHoldingRegFunction(ModbusMaster &modBusMaster, int address,
                             uint16_t value)
{
    /***
     * writeCoilFunction For Reading Holding Reg From TCP And Write it onthe RTU
     * @param ModbusMaster modBusMaster : RTU Obj
     * @param uint16_t address : Holding reg Address
     * @param uint16_t value : Holding reg Value
     *
     **/
    modBusMaster.writeSingleRegister(address, value);
}

uint8_t readInputRegister(uint16_t portNumber, ModbusMaster &modBusMaster,
                          uint16_t startAddress, uint16_t numberOfregister)
{
    /***
     * readInputRegister For Reading Holding Reg From TCP And Write it onthe RTU
     * @param ModbusMaster modBusMaster : RTU Obj
     * @param uint16_t startAddress     : Address for InputReg
     * @param uint16_t numberOfregister :numberOfregister
     * **/

    modBusMaster.clearResponseBuffer();
    uint8_t res = modBusMaster.readInputRegisters(startAddress, numberOfregister);
    uint8_t i = 0;
    if (checkResponse(res, modBusMaster))
    {
        for (i = 0; i < numberOfregister; i++)
        {
            RTURInputRegSPONSE[i] = modBusMaster.getResponseBuffer(i);
        }
    }
    return i;
}
