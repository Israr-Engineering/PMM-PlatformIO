#include <PMMADS8688/PMMADS8688.h>
ADS8688 bank = ADS8688(A3); // Instantiate ADS8688 with PIN 10 as default CS
void PMMInitADS8688()
{
    // Init ADS
    SPI.begin();
    bank.setChannelSPD(0b11111111);
    bank.setGlobalRange(R1); // set range for all channels
    bank.autoRst();
}
void PMMADS8688Read(AI *tmpArray, uint8_t ethCs)
{
    digitalWrite(ethCs, HIGH);
    digitalWrite(A3, LOW);
    for (byte i = 0; i < 8; i++)
    {
        tmpArray[i].floatToInt.valueAsFloat = bank.I2V(bank.noOp(), R1);
        SerialUSB.println(tmpArray[i].floatToInt.valueAsFloat);
    }

    digitalWrite(A3, HIGH);
    digitalWrite(ethCs, LOW);
}