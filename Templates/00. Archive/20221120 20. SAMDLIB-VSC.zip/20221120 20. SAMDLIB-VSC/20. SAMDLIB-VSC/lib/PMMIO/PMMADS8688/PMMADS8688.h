#ifndef PMM74412R
#define PMM74412R
#include <Arduino.h>
#include <projectConfigration.h>
#include <PMMIOLib/PMMIOLib.h>
#include <Arduino.h>
#include <SPI.h>
#include <ADS8688.h>
void PMMInitADS8688();
void PMMADS8688Read(AI *tmpArray, uint8_t ethCs);

#endif