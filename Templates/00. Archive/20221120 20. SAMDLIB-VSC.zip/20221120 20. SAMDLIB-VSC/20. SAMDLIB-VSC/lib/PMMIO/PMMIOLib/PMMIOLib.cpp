#include <PMMUDPLib/PMMUDPLib.h>

// SetUp Functions
void DOSetup(uint8_t DOPinCount, uint8_t *pinArray)
{
    for (int i = 0; i < DOPinCount; i++)
    {
        pinMode(pinArray[i], OUTPUT);
    }
}
void DISetup(uint8_t DIPinCount, uint8_t *pinArray)
{
    for (int i = 0; i < DIPinCount; i++)
    {
        pinMode(pinArray[i], INPUT);
    }
}

void DIPullUpSetup(uint8_t DIPinCount, uint8_t *pinArray)
{
    for (int i = 0; i < DIPinCount; i++)
    {
        pinMode(pinArray[i], INPUT_PULLUP);
    }
}

void AISetup(uint8_t AIPinCount, uint8_t *pinArray);
void AOSetup(uint8_t AOPinCount, uint8_t *pinArray);
void DigitalReadPins(uint8_t DOPinCount, uint8_t *pinArray, bool *DRead)
{
    for (uint8_t i = 0; i < DOPinCount; i++)
    {
        DRead[i] = digitalRead(pinArray[i]);
    }
}
void DigitalPullUPReadPins(uint8_t *pinArray, modBusCoils IOStruct)
{
    for (uint8_t i = 0; i < IOStruct.quentity; i++)
    {
        IOStruct.boolArrayCurrent[i] = !digitalRead(pinArray[i]);
        if (IOStruct.forcedArray[i] == true)
            IOStruct.boolArray[i] = IOStruct.forcedValue[i];
        else
            IOStruct.boolArray[i] = IOStruct.boolArrayCurrent[i];
    }
}
void DigitalReadPins(uint8_t *pinArray, modBusCoils IOStruct)
{
    for (uint8_t i = 0; i < IOStruct.quentity; i++)
    {
        IOStruct.boolArrayCurrent[i] = digitalRead(pinArray[i]);
        if (IOStruct.forcedArray[i] == true)
            IOStruct.boolArray[i] = IOStruct.forcedValue[i];
        else
            IOStruct.boolArray[i] = IOStruct.boolArrayCurrent[i];
    }
}
void DigitalOutputWrite(uint8_t *pinArray, modBusCoils IOStruct)
{
    for (uint8_t i = 0; i < IOStruct.quentity; i++)
    {

        if (IOStruct.forcedArray[i] == true)
            IOStruct.boolArray[i] = IOStruct.forcedValue[i];
        else
            IOStruct.boolArray[i] = IOStruct.boolArrayCurrent[i];
        digitalWrite(pinArray[i], IOStruct.boolArray[i]);
    }
}

void PMMAnalogReadCalibratoin(struct AI *ai, uint8_t quentity)
{
    for (uint8_t i = 0; i < quentity; i++)
    {
        // sub last reading
        ai[i].total = ai[i].total - ai[i].analogValues[ai[i].numberOfreading];
        // Read new value
        // specifay resolution
        analogReadResolution(12);
        ai[i].analogValues[ai[i].numberOfreading] = analogRead(ai[i].pinNumber);
        // add it to the total
        ai[i].total += ai[i].analogValues[ai[i].numberOfreading];
        ai[i].numberOfreading++;
        if (ai[i].numberOfreading >= 30)
            ai[i].numberOfreading = 0;
        // Analog Value
        ai[i].floatToInt.valueAsFloat = ai[i].total / 30.0;
        ai[i].floatToInt.valueAsFloat = (ai[i].floatToInt.valueAsFloat - ai[i].offset) * ai[i].factorValue;
        if (ai[i].floatToInt.valueAsFloat < 0 && !ai[i].canBeNegative)
            ai[i].floatToInt.valueAsFloat = 0;
        delay(1);
    }
}