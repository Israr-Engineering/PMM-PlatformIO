#ifndef PMMIOLib
#define PMMIOLib
#include <Arduino.h>
#include <projectConfigration.h>
// #include <Ethernet.h>

void DOSetup(uint8_t DOPinCount, uint8_t *pinArray);
void DISetup(uint8_t DIPinCount, uint8_t *pinArray);
void DIPullUpSetup(uint8_t DIPinCount, uint8_t *pinArray);
void AISetup(uint8_t AIPinCount, uint8_t *pinArray);
void AOSetup(uint8_t AOPinCount, uint8_t *pinArray);
void DigitalReadPins(uint8_t DOPinCount, uint8_t *pinArray, bool *DRead);
void DigitalWritePins(uint8_t DOPinCount, uint8_t *pinArray, bool *DWrite);
void DigitalPullUPReadPins(uint8_t *pinArray, modBusCoils IOStruct);
void DigitalOutputWrite(uint8_t *pinArray, modBusCoils IOStruct);
void DigitalReadPins(uint8_t *pinArray, modBusCoils IOStruct);
void PMMAnalogReadCalibratoin(struct AI *ai, uint8_t quentity);

#endif