#include <PMMmultiplexer/PMMmultiplexer.h>

void multiplexerSetup(Multiplexer &multiplexer, HC595 &outputArray)
{
    // Initalize The IO
    uint8_t outputPins[] = {multiplexer.RCLK, multiplexer.SERIn, multiplexer.SRCLK, multiplexer.SRCLKInv};
    DOSetup(4, outputPins);
    digitalWrite(multiplexer.SRCLKInv, HIGH); // PULL the SRCLKInv High to enable the device
    outputArray.setUp(multiplexer.numberOfChip, multiplexer.RCLK, multiplexer.SRCLK, multiplexer.SERIn);
}
void multiplexerOutput(Multiplexer &multiplexer, HC595 &outputArrayObj, uint8_t startFrom, uint8_t numberOfOutput, bool *outputArray)
{

    for (int i = 0; i < numberOfOutput; i++)
    {
        outputArrayObj.setPin(i + startFrom, outputArray[i]);
    }
}