#ifndef PMMmultiplexer
#define PMMmultiplexer
#include <Arduino.h>
#include <projectConfigration.h>
#include <PMMIOLib/PMMIOLib.h>
#include <projectConfigration.h>
#include <HC595.h>
void multiplexerSetup(Multiplexer &multiplexer , HC595 &outputArray);
void multiplexerOutput(Multiplexer &multiplexer, HC595 &outputArrayObj, uint8_t startFrom, uint8_t numberOfOutput, bool *outputArray);
#endif