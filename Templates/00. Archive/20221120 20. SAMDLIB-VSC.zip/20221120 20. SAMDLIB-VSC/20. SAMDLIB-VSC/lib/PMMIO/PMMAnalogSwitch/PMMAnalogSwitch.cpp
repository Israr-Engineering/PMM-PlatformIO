#include <PMMAnalogSwitch/PMMAnalogSwitch.h>

/**
 * @brief Use the Function if you have analog switch on the circuit and you need to read it
 * @return * void
 */
void analogSwitchSetup(AnalogSwitch tmpAnalogSwitch)
{
    // Define IO
    pinMode(tmpAnalogSwitch.dataPin, INPUT);
    uint8_t outputPins[] = {tmpAnalogSwitch.S0, tmpAnalogSwitch.S1, tmpAnalogSwitch.S2, tmpAnalogSwitch.S3};
    DOSetup(4, outputPins);
}
/**
 * @brief Read All input and return it on the input Array
 *
 * @param inputCount number of inputs in Analog Switch : should be 16 by default
 * @param dataPin the pin that we will read from it
 * @param S0
 * @param S1
 * @param S2
 * @param S3
 * @param inputArray where we will save the data
 */
void analogSwitchReadAllInput(AnalogSwitch tmpAnalogSwitch, bool *inputArray)
{

    for (uint8_t i = 0; i < tmpAnalogSwitch.inputCount; i++)
    {
        byte toByte = i & 0b00001111; // Take the last Four  number
        digitalWrite(tmpAnalogSwitch.S0, (toByte & 0b00000001));
        digitalWrite(tmpAnalogSwitch.S1, (toByte >> 1) & 0b00000001);
        digitalWrite(tmpAnalogSwitch.S2, (toByte >> 2) & 0b00000001);
        digitalWrite(tmpAnalogSwitch.S3, (toByte >> 3) & 0b00000001);
        inputArray[i] = digitalRead(tmpAnalogSwitch.dataPin);
    }
}
/**
 * @brief Read Specific input from Analog Switch
 * @return bool the pin value
 */
bool analogSwitchReadSpecificInput(AnalogSwitch tmpAnalogSwitch, uint8_t pinNumber)
{
    byte toByte = pinNumber & 0b00001111; // Take the last Four  number
    digitalWrite(tmpAnalogSwitch.S0, (toByte & 0b00000001));
    digitalWrite(tmpAnalogSwitch.S1, (toByte >> 1) & 0b00000001);
    digitalWrite(tmpAnalogSwitch.S2, (toByte >> 2) & 0b00000001);
    digitalWrite(tmpAnalogSwitch.S3, (toByte >> 3) & 0b00000001);
    return digitalRead(tmpAnalogSwitch.dataPin);
}