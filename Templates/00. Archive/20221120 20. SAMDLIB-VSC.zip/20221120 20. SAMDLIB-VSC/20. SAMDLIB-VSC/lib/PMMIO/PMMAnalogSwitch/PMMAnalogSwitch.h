#ifndef PMMAnalogSwitch
#define PMMAnalogSwitch
#include <Arduino.h>
#include <projectConfigration.h>
#include <PMMIOLib/PMMIOLib.h>
void analogSwitchSetup(AnalogSwitch tmpAnalogSwitch);
void analogSwitchReadAllInput(AnalogSwitch tmpAnalogSwitch, bool *inputArray);
bool analogSwitchReadSpecificInput(AnalogSwitch tmpAnalogSwitch, uint8_t pinNumber);
#endif