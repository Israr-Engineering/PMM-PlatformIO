#include <PMM74412R/PMM74412R.h>

/*
 * declaration of AD74412R pins
 * reset alarm flag
 */

void PMMAD74412RInit(AD7441 tmpAD7441)
{
    // Configure Pins
    pinMode(tmpAD7441.cs, OUTPUT);
    pinMode(tmpAD7441.rst, OUTPUT);
    pinMode(tmpAD7441.alertFlage, INPUT);
    pinMode(tmpAD7441.ready, INPUT);
    // RST Alarms
    digitalWrite(tmpAD7441.rst, HIGH);
    SPI.begin();
    SPI.beginTransaction(SPISettings(SPI_SPEED, MSBFIRST, SPI_MODE1));
    // reset alarm flag || This device at start will rise alarm flag
    PMMAD74412RWrite(tmpAD7441, ALERT_STATUS_REGISTER, CLEAR_COMMAND);
    PMMAD74412RWrite(tmpAD7441, ALERT_MASK_REGISTER, CLEAR_COMMAND);
}
uint16_t PMMAD74412Read(AD7441 tmpAD7441)
{
    uint16_t Read_Value = 0;
    SPI.beginTransaction(SPISettings(SPI_SPEED, MSBFIRST, SPI_MODE1));

    digitalWrite(tmpAD7441.EthCS, HIGH); // Disable Eth
    digitalWrite(tmpAD7441.cs, LOW);     // Hold SPI Pins
    delayMicroseconds(1);
    uint8_t value1 = SPI.transfer(0x00); // Why the response is saved here
    uint8_t value2 = SPI.transfer(0x00);
    uint8_t value3 = SPI.transfer(0x00);
    uint8_t value4 = SPI.transfer(0x00); // Why the response is saved here
    delayMicroseconds(1);
    digitalWrite(tmpAD7441.cs, HIGH);   // Hold SPI Pins
    digitalWrite(tmpAD7441.EthCS, LOW); // Enable Eth

    SPI.endTransaction();
    Read_Value |= (value2 << 8) + value3;
    return (Read_Value);
}
/*
 * write register function
 *
 */
void PMMAD74412RWrite(AD7441 tmpAD7441, uint8_t regAddress, uint16_t data)
{

    uint8_t tx_data[4] = {regAddress, data >> 8, data, CRC_equ(tx_data, 3)}; //
    // Init SPI Transaction
    SPI.beginTransaction(SPISettings(SPI_SPEED, MSBFIRST, SPI_MODE1));
    digitalWrite(tmpAD7441.cs, LOW);
    digitalWrite(tmpAD7441.EthCS, HIGH); // Disable Eth
    delayMicroseconds(1);
    SPI.transfer(regAddress);          // Reg Address
    SPI.transfer(data >> 8);           // Data to write on register
    SPI.transfer(data);                // Data to write on register
    SPI.transfer(CRC_equ(tx_data, 3)); // CRC
    delayMicroseconds(1);
    digitalWrite(tmpAD7441.cs, HIGH);   // Release SPI Pins
    digitalWrite(tmpAD7441.EthCS, LOW); // Release SPI Pins
    SPI.endTransaction();
}
/*
 * read from register is divided into two stages
 * select  READ_SELECT_REGISTER first and the register to read
 * thin read function
 */
uint16_t PMMAD74412ReadWrite(AD7441 tmpAD7441, uint16_t REGISTER)
{
    PMMAD74412RWrite(tmpAD7441, READ_SELECT_REGISTER, REGISTER);
    return (PMMAD74412Read(tmpAD7441));
}

/*
 * this function is used to write an analog output value
 * we can produce voltage output and current output using this function
 */
void PMMAD74412AnalogWrite(AD7441 tmpAD7441, AO *tmpAO, uint8_t numberOfOutput)
{

    uint8_t CH_FUNC_SETUP;
    uint8_t OUTPUT_CONFIG;
    uint8_t DAC_CODE;
    uint8_t type = Voltage_Output;

    for (uint8_t i = 0; i < numberOfOutput; i++)
    {
        type = tmpAO[i].isVoltage == true ? Voltage_Output : Current_Output; // Select Current || Voltage
        CH_FUNC_SETUP = i + 1;                                               // Select Channel Type Voltage || Current
        OUTPUT_CONFIG = i + 18;                                              // Output Specification
        DAC_CODE = i + 22;                                                   // Select the required register to write the analog value

        if (PMMAD74412ReadWrite(tmpAD7441, CH_FUNC_SETUP) != (type))
            PMMAD74412RWrite(tmpAD7441, CH_FUNC_SETUP, type);
        if (PMMAD74412ReadWrite(tmpAD7441, DAC_CODE) != (tmpAO[i].valueOnADC))
            PMMAD74412RWrite(tmpAD7441, DAC_CODE, tmpAO[i].valueOnADC);
        if (PMMAD74412ReadWrite(tmpAD7441, CH_FUNC_SETUP) != (type))
            PMMAD74412RWrite(tmpAD7441, CH_FUNC_SETUP, type);
        if (PMMAD74412ReadWrite(tmpAD7441, OUTPUT_CONFIG) != (Current_Limit_30mA | CLR_EN | SLEW_LIN_RATE_240kHz | SLEW_LIN_STEP_1820 | SLEW_EN))
            PMMAD74412RWrite(tmpAD7441, OUTPUT_CONFIG, Current_Limit_30mA | CLR_EN | SLEW_LIN_RATE_240kHz | SLEW_LIN_STEP_1820 | SLEW_EN);
        // write a value to selected channel
        PMMAD74412RWrite(tmpAD7441, DAC_CODE, tmpAO[i].valueOnADC);
    }
}

/*
 * the CRC is a 8-LSB in each packets
 * this function calculate the CRC value for each value that we want to write
 */
static uint8_t CRC_equ(uint8_t *data_in, uint8_t n_bytes)
{

    uint32_t crc_code = 0x107;
    uint8_t i = 31;
    uint32_t data_out = 0;
    uint8_t cnt;

    for (cnt = 0; cnt < n_bytes; cnt++)
    {
        data_out |= *data_in;
        data_in++;
        data_out <<= 8;
    }
    // SerialUSB.print("tx_data ::");
    // SerialUSB.println(data_out, HEX);
    while (i >= 8)
    {
        if ((data_out & ((uint32_t)1 << i)) != 0)
        {
            data_out ^= (crc_code << (i - 8));
        }

        i--;
    }
    // SerialUSB.print("CRC CODE ::");
    // SerialUSB.println(data_out, HEX);

    return (uint8_t)data_out;
}
