#ifndef PMM74412R
#define PMM74412R
#include <Arduino.h>
#include <projectConfigration.h>
#include <PMMIOLib/PMMIOLib.h>
#include <Arduino.h>
#include <SPI.h>
// #include <PMM74412R/PMM74412R.h>

/*
 * SPI Configuration
 */
#define SPI_SPEED 8000000

/*
 * Registers
 */
#define NOP 0x00

#define CH_FUNC_SETUP_1_REGISTER 0x01
#define CH_FUNC_SETUP_2_REGISTER 0x02
#define CH_FUNC_SETUP_3_REGISTER 0x03
#define CH_FUNC_SETUP_4_REGISTER 0x04

#define ADC_CONFIG_1_REGISTER 0x05
#define ADC_CONFIG_2_REGISTER 0x06
#define ADC_CONFIG_3_REGISTER 0x07
#define ADC_CONFIG_4_REGISTER 0x08

#define DIN_CONFIG_1_REGISTER 0x09
#define DIN_CONFIG_2_REGISTER 0x0A
#define DIN_CONFIG_3_REGISTER 0x0B
#define DIN_CONFIG_4_REGISTER 0x0C

#define GPO_PARALLEL_REGISTER 0x0D

#define GPO_CONFIG_1_REGISTER 0x0E
#define GPO_CONFIG_2_REGISTER 0x0F
#define GPO_CONFIG_3_REGISTER 0x10
#define GPO_CONFIG_4_REGISTER 0x11

#define OUTPUT_CONFIG_1_REGISTER 0x12
#define OUTPUT_CONFIG_2_REGISTER 0x13
#define OUTPUT_CONFIG_3_REGISTER 0x14
#define OUTPUT_CONFIG_4_REGISTER 0x15

#define DAC_CODE_1_REGISTER 0x16
#define DAC_CODE_2_REGISTER 0x17
#define DAC_CODE_3_REGISTER 0x18
#define DAC_CODE_4_REGISTER 0x19

#define DAC_CLR_CODE_1_REGISTER 0x1A
#define DAC_CLR_CODE_2_REGISTER 0x1B
#define DAC_CLR_CODE_3_REGISTER 0x1C
#define DAC_CLR_CODE_4_REGISTER 0x1D

#define DAC_ACTIVE_1_REGISTER 0x1E
#define DAC_ACTIVE_2_REGISTER 0x1F
#define DAC_ACTIVE_3_REGISTER 0x20
#define DAC_ACTIVE_4_REGISTER 0x21

#define DIN_THRESH_REGISTER 0x22
#define ADC_CONV_CTRL_REGISTER 0x23
#define DIAG_ASSIGN_REGISTER 0x24
#define DIN_COMP_OUT_REGISTER 0x25

#define ADC_RESULT_1_REGISTER 0x26
#define ADC_RESULT_2_REGISTER 0x27
#define ADC_RESULT_3_REGISTER 0x28
#define ADC_RESULT_4_REGISTER 0x29

#define DIAG_RESULT_1_REGISTER 0x2A
#define DIAG_RESULT_2_REGISTER 0x2B
#define DIAG_RESULT_3_REGISTER 0x2C
#define DIAG_RESULT_4_REGISTER 0x2D

#define ALERT_STATUS_REGISTER 0x2E
#define LIVE_STATUS_REGISTER 0x2F
#define ALERT_MASK_REGISTER 0x3C
#define READ_SELECT_REGISTER 0x41
#define ADC_CONV_CTRL_80SPS_REGISTER 0x42
#define THERM_RST_REGISTER 0x43
#define CMD_KEY_REGISTER 0x44
#define SCRATCH_REGISTER 0x45
#define SILICON_REV_REGISTER 0x46

/*
 * Commands
 */
#define RESET_COMMAND 0x0000
#define RESET_DIN_CONFIG_COMMAND 0x000B
#define RESET_ALERT_STATUS_COMMAND 0x8000
#define RESET_SILICON_REV_COMMAND 0x0008
#define CLEAR_COMMAND 0xFFFF

/*
 * CH_FUNC_SETUP
 */
#define High_Impedance 0b00000000
#define Voltage_Output 0b00000001
#define Current_Output 0b00000010
#define Voltage_Vnput 0b00000011
#define Current_Input_Externally_Powered 0b00000100
#define Current_Input_Loop_Powered 0b00000101
#define Resistance_Measurement 0b00000110
#define Digital_Input_Logic 0b00000111
#define Digital_Input_Loop_Powered 0b00001000

/*
 * CH_FUNC_SETUP
 */
#define Current_Limit_30mA 0b00000000
#define Current_Limit_7m5A 0b00000001

#define CLR_EN 0b00000010

#define SLEW_LIN_RATE_4kHz 0b00000000
#define SLEW_LIN_RATE_64kHz 0b00000100
#define SLEW_LIN_RATE_150kHz 0b00001000
#define SLEW_LIN_RATE_240kHz 0b00001100

#define SLEW_LIN_STEP_64 0b00000000
#define SLEW_LIN_STEP_120 0b00010000
#define SLEW_LIN_STEP_500 0b00100000
#define SLEW_LIN_STEP_1820 0b00110000

#define SLEW_Dis 0b00000000
#define SLEW_EN 0b01000000

/*
 * CMD_KEY_REGISTER
 */
#define Software_Reset_Key1 0x15FA // To trigger a software reset, write this key followed by Software Reset Key2. The SPI writes must be back to back.
#define Software_Reset_Key2 0xAF51 // To trigger a software reset, write Software Reset Key1 followed by this key. The SPI writes must be back to back.
#define LDAC_key 0x953A            // A DAC update is triggered on all channels when this key is entered, which is equivalent to asserting the LDAC pin.
#define DAC_clear 0x73D1           // When entering this key, the DAC_CLR_CODEx registers for a channel are sent to the DAC, provided that the clear function is enabled in the OUTPUT_CONFIGx registers.

void PMMAD74412RInit(AD7441 tmpAD7441);
void PMMAD74412RWrite(AD7441 tmpAD7441, uint8_t regAddress, uint16_t data);
uint16_t PMMAD74412Read(AD7441 tmpAD7441);
uint16_t PMMAD74412ReadWrite(AD7441 tmpAD7441, uint16_t REGISTER);
// void PMMAD74412AnalogWrite(AD7441 tmpAD7441, AO *tmpAO);
void PMMAD74412AnalogWrite(AD7441 tmpAD7441, AO *tmpAO, uint8_t numberOfOutput);
static uint8_t CRC_equ(uint8_t *data_in, uint8_t n_bytes);

#endif