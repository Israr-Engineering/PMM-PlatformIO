#ifndef PMMIOAjax
#define PMMIOAjax
#include <Arduino.h>
#include <projectConfigration.h>

extern bool PMM6032Device;
extern bool PMM0620Device;
extern bool PMM0625TDevice;
extern bool PMM0626RDevice;
extern bool PMM0627Device;
extern bool PMM0638Device;
extern bool PMM0639Device;
extern bool PMM0613Device;
extern AI aiArray[8];
extern struct AO aoArray[4];

void PMMAjaxResponse(EthernetClient client);
void PMMSetAjaxResponse(EthernetClient client, String json);
extern modBusCoils PMMInputCoilModbus;
extern modBusCoils PMMOutputCoilModbus;
extern modBusHolding PMMInputHolding;
extern modBusHolding PMMOutputHolding;

#endif