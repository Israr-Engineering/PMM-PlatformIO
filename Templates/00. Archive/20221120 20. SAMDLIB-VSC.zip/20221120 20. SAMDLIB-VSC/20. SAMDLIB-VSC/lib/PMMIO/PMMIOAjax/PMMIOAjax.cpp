#include <PMMIOAjax/PMMIOAjax.h>
void PMMAjaxResponse(EthernetClient client)
{
    if (PMM6032Device)
    {
        String response = "";
        for (uint8_t i = 0; i < 8; i++)
        {
            response += String(aiArray[i].total / 30.0) + ",";
            response += String(aiArray[i].floatToInt.valueAsFloat) + ",";
        }
        client.println(F("HTTP/1.1 200 OK"));
        client.println(F("Access-Control-Allow-Origin: *"));
        client.println(F("Content-Type: text/html"));
        client.println();
        client.println();
        client.println(response);
        client.flush();
    }
    else if (PMM0638Device)
    {
        String response = "";
        for (uint8_t i = 0; i < 4; i++)
        {
            response += String(aiArray[i].total / 30.0) + ",";
            response += String(aiArray[i].floatToInt.valueAsFloat) + ",";
        }
        for (uint8_t i = 0; i < 4; i++)
            response += String(aoArray[i].floatToInt.valueAsFloat) + ",";
        client.println(F("HTTP/1.1 200 OK"));
        client.println(F("Access-Control-Allow-Origin: *"));
        client.println(F("Content-Type: text/html"));
        client.println();
        client.println();
        client.println(response);
        client.flush();
    }
    else if (PMM0620Device)
    {
        String response = "";
        for (uint8_t i = 0; i < 12; i++)
        {
            response += String(PMMInputCoilModbus.boolArrayCurrent[i]) + ",";
        }
        client.println(F("HTTP/1.1 200 OK"));
        client.println(F("Access-Control-Allow-Origin: *"));
        client.println(F("Content-Type: text/html"));
        client.println();
        client.println();
        client.println(response);
        client.flush();
    }
    else if (PMM0625TDevice || PMM0626RDevice || PMM0627Device)
    {
        String response = "";
        for (uint8_t i = 0; i < 8; i++)
        {
            response += String(PMMOutputCoilModbus.boolArrayCurrent[i]) + ",";
        }
        client.println(F("HTTP/1.1 200 OK"));
        client.println(F("Access-Control-Allow-Origin: *"));
        client.println(F("Content-Type: text/html"));
        client.println();
        client.println();
        client.println(response);
        client.flush();
    }
    else if (PMM0639Device)
    {
        String response = "";
        for (uint8_t i = 0; i < 2; i++)
        {
            response += String(aiArray[i].total / 30.0) + ",";
            response += String(aiArray[i].floatToInt.valueAsFloat) + ",";
        }
        for (uint8_t i = 0; i < 2; i++)
            response += String(aoArray[i].floatToInt.valueAsFloat) + ",";
        client.println(F("HTTP/1.1 200 OK"));
        client.println(F("Access-Control-Allow-Origin: *"));
        client.println(F("Content-Type: text/html"));
        client.println();
        client.println();
        client.println(response);
        client.flush();
    }
    else if (PMM0613Device)
    {
        String response = "0,";
        for (uint8_t i = 0; i < 4; i++)
            response += String(aiArray[i].total / 30.0) + ",";
        for (uint8_t i = 0; i < 4; i++)
            response += String(aoArray[i].floatToInt.valueAsFloat) + ",";

        client.println(F("HTTP/1.1 200 OK"));
        client.println(F("Access-Control-Allow-Origin: *"));
        client.println(F("Content-Type: text/html"));
        client.println();
        client.println();
        client.println(response);
        client.flush();
    }
}
void PMMSetAjaxResponse(EthernetClient client, String json)
{

    json = json.substring(json.indexOf("PMMStart") + 9);
    if (PMM0620Device)
    {
        uint8_t index = 0;
        for (uint8_t i = 0; i < 12; i++)
        {
            PMMInputCoilModbus.forcedArray[i] = (json[index] == '1' ? true : false);
            index += 2;
            PMMInputCoilModbus.forcedValue[i] = (json[index] == '0' ? false : true);
            index += 2;
        }
        SerialUSB.println("Requested");
    }
    else if (PMM0625TDevice || PMM0626RDevice||PMM0627Device)
    {
        uint8_t index = 0;
        for (uint8_t i = 0; i < 8; i++)
        {
            PMMOutputCoilModbus.forcedArray[i] = (json[index] == '1' ? true : false);
            index += 2;
            PMMOutputCoilModbus.forcedValue[i] = (json[index] == '0' ? false : true);
            index += 2;
        }
        SerialUSB.println("NANANA");
        
    }
}