#ifndef PMMUDPBridge
#define PMMUDPBridge
#include <Arduino.h>
#include <Ethernet.h>
#include <EthernetUdp.h>
#include <projectConfigration.h>
#include <PMMGlobalFunction.h>
#include <PMMUDPLib/PMMUDPLib.h>
extern String remoteIPAddress;
extern String UDPPort, UDPPort2, UDPPort3, UDPPort4;
extern EthernetUDP Udp;
extern EthernetUDP Udp2;
extern EthernetUDP Udp3;
extern EthernetUDP Udp4;
extern EthernetUDP Udp5;

extern bool PMM0406Device;
extern bool PMM0501Device;

// extern

void PMMUDPLoop();
void PMMUDPToSerial(EthernetUDP &UDP, Uart &serialPort, String RemoteIPAddress, int UDPPort);

#endif