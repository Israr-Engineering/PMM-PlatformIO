#include <PMMUDPBridge/PMMUDPBridge.h>

#define UDP_TX_PACKET_MAX_SIZE 100
char packetBuffer[UDP_TX_PACKET_MAX_SIZE];
byte rcvBuffer[UDP_TX_PACKET_MAX_SIZE];
/**
 * @brief Listen to UDP and Write it to the Serial and
 * @param UDP : the UDP Object
 * @param serial
 * @param RemoteIPAddress
 * @param UDPPort
 * @return ** void
 */

void PMMUDPLoop()
{

    if (PMM0406Device)
    {
        PMMUDPToSerial(Udp, Serial2, remoteIPAddress, 91); // 0611 Only need this
        PMMUDPToSerial(Udp2, Serial, remoteIPAddress, 92);
        PMMUDPToSerial(Udp3, Serial1, remoteIPAddress, UDPPort3.toInt());
        PMMUDPToSerial(Udp4, Serial3, remoteIPAddress, UDPPort4.toInt());
    }
    else
    {
        PMMUDPToSerial(Udp, Serial1, remoteIPAddress, 91); // 0611 Only need this
        if (PMM0406Device || PMM0501Device)
            PMMUDPToSerial(Udp2, Serial, remoteIPAddress, 92);
        if (PMM0406Device)
        {
            // Add port Three & Four
            PMMUDPToSerial(Udp3, Serial2, remoteIPAddress, UDPPort3.toInt());
            PMMUDPToSerial(Udp4, Serial3, remoteIPAddress, UDPPort4.toInt());
        }
    }
}
void PMMUDPToSerial(EthernetUDP &UDP, Uart &serialPort, String RemoteIPAddress, int UDPPort)
{
    char CharRemoteIPAddress[30] = "192.168.1.5";
    RemoteIPAddress.toCharArray(CharRemoteIPAddress, (RemoteIPAddress.length() + 1));
    // UDP Recive Data
    int UDPpacketSize = PMMUDPRecivedMsg(UDP, packetBuffer);
    if (UDPpacketSize > 0)
    {
        serialPort.write(packetBuffer, UDPpacketSize);
        memset(packetBuffer, 0, sizeof packetBuffer);
        Debugprintln("DataRecived");
        SerialUSB.println((UDPPort));
    }
    // Serial Recive
    if (serialPort.available() > 0)
    {
        serialPort.setTimeout(50);
        int msgLength = serialPort.readBytes(rcvBuffer, 64);
        // int msgLength = serialPort.readBytesUntil(0x78, rcvBuffer, 64);
        PMMUDPSend(UDP, UDPPort, CharRemoteIPAddress, rcvBuffer, msgLength);
        Debugprintln("Data Avaliable Size");
    }
}
