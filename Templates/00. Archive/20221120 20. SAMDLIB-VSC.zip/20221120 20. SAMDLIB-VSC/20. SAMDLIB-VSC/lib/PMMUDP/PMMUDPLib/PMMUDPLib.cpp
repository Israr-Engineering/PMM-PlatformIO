#include <PMMUDPLib/PMMUDPLib.h>

void PMMUDPInit(EthernetUDP &UDP, int UDPPort)
{

    UDP.begin(UDPPort); // 91
    Debugprintln("UDPPort Initalized " + UDPPort);
}
void PMMUDPSend(EthernetUDP &UDP, int UDPPort, char *CharRemoteIPAddress, uint8_t *msg, uint16_t msgLength)
{
    UDP.beginPacket(CharRemoteIPAddress, UDPPort);
    UDP.write(msg, msgLength); 
    UDP.endPacket();
    UDP.clearWriteError();
    UDP.flush();
}
void PMMUDPSend(EthernetUDP &UDP, int UDPPort, char *CharRemoteIPAddress, char *msg, uint16_t msgLength)
{
    UDP.beginPacket(CharRemoteIPAddress, UDPPort);
    UDP.write(msg, msgLength);
    UDP.endPacket();
    UDP.clearWriteError();
    UDP.flush();
}
int PMMUDPRecivedMsg(EthernetUDP &UDP, char *msg)
{
    int UDPpacketSize = UDP.parsePacket();
    if (UDPpacketSize)
    {
        UDP.read(msg, UDP_TX_PACKET_MAX_SIZE);
        UDP.clearWriteError();
        UDP.flush();
    }
    return UDPpacketSize;
}



void PMMNTPServerLoop(EthernetUDP &UDP)
{
    int packetSize = UDP.parsePacket();
    if (!packetSize)
    {
    }
}