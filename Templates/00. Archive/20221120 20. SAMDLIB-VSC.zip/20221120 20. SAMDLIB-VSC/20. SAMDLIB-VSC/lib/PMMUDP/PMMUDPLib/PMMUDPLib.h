#ifndef PMMUDPLib
#define PMMUDPLib
#include <Arduino.h>
#include <Ethernet.h>
#include <EthernetUdp.h>
#include <projectConfigration.h>
#include <PMMGlobalFunction.h>

extern String myControllerIP;
extern String myControllerMAC;
extern String myControllerDNS;
extern String myPCIP;
extern String UDPport;
extern struct SerialParameter portOne;
void PMMUDPInit(EthernetUDP &UDP, int UDPPort);
void PMMUDPSend(EthernetUDP &UDP, int UDPPort ,char *CharRemoteIPAddress,uint8_t *msg ,uint16_t msgLength);
void PMMUDPSend(EthernetUDP &UDP, int UDPPort, char *CharRemoteIPAddress, char *msg, uint16_t msgLength);

int PMMUDPRecivedMsg(EthernetUDP &UDP , char *msg);
#endif