#include <PMMFlashGeneralFunction/PMMFlashGeneralFunction.h>
SFE_SPI_FLASH PMMFlash;
/***
 * === General Notes on SPI Flash
 *    - The Flash Memory has to be eresed before writing to it {Edit the Library so you can read / Write on it Freely}
 *    - Add Extra Param so it trigger the Lora Off and return it
 */

bool PMMFlashInit(byte flashCS)
{
    /**
     * PMMFlashInit() :: Call this Function at the Init the Flash
     */
    // SPI.begin();

    pinMode(A2, OUTPUT);
    digitalWrite(A2, HIGH);
    while (!PMMFlash.begin(flashCS))
    {
        SerialUSB.print(".");
        delay(100);
        // return false;
    }
    SerialUSB.println(PMMFlash.getDeviceID());
    SerialUSB.println(PMMFlash.getManufacturerID());
    SerialUSB.println(PMMFlash.isBusy());
    return true;
}
// ========== Read Write Byte From Flash
void PMMFlashWrite(unsigned int eeAddr, uint8_t data)
{
    /**
     * PMMFlashWrite: Write A Byte to the Flash
     * @param int eeAddr: the Flash Address
     * @param byte data: the Byte to Write
     */
    uint8_t myVal[4] = {0xDE, 0xAD, 0xBE, 0xEF};
    PMMFlash.writeBlock(0, myVal, 4);
    // PMMFlash.erase();
    // while (PMMFlash.writeByte(eeAddr, data) == 0)
    // {
    //     SerialUSB.print(".");
    // }
}
byte PMMFlashRead(unsigned int eeAddr)
{
    /**
     * PMMFlashRead : Return the Saved Byte in Specific Address
     * @param int eeAddr: the Flash Address
     */
    // byte readByte = 255;
    // byte readByte = PMMFlash.readByte(eeAddr);
    SerialUSB.print(PMMFlash.readByte(0), HEX);
    SerialUSB.print(PMMFlash.readByte(1), HEX);
    SerialUSB.print(PMMFlash.readByte(2), HEX);
    SerialUSB.print(PMMFlash.readByte(3), HEX);
    SerialUSB.println();
    // PMMFlash.readByte(2);
    return 0;
}
bool PMMFlashFirstRun()
{
    bool firstRun = (PMMFlashRead(1) != firstRunValue);
    if (firstRun)
        Debugprintln("First Run");
    else
        Debugprintln("Used Before");
    return firstRun;
}
void PMMFlashMarkAsRead()
{
    PMMFlashWrite(firstRunValue, 1);
}
// ========== Read Write String From Flash
String PMMFlashReadString(int address, int numberOfChar)
{
    // === Return the Saved Data in Flash As Srting
    String returnData = "";
    int j;
    for (j = 0; j < numberOfChar; j++)
    {
        returnData.concat((char)(PMMFlashRead(address + j)));
    }
    return returnData;
}
int PMMFlashSaveString(String toSave, int startFrom)
{
    /**
     * PMMFlashSaveString   : Save string value to EEPROM
     * @param String toSave : the  String to save
     * @param int startFrom : the starting address
     * @return int the next free space
     */
    // === Add Extra Char for the string {Without this the last char will
    toSave.concat(":");
    signed i = 0;
    // === Save it to EEprom
    while ((toSave.length() - 1) > i)
    {

        PMMFlashWrite(startFrom + i, toSave[i]); //(char)b2[i]);
        i++;
    }
    // === Use & to Split Data
    PMMFlashWrite(startFrom + i, (char)'&');
    return (startFrom + 1 + i);
}
String PMMFlashReadJsonFromEEPROM(int address, int numberOfValue)
{
    // === Return the Saved Data in Flash As Srting Separeted by & Sign
    bool notFound = true;
    String returnData = "";
    int i = 0;
    int j;
    for (j = 0; j < numberOfValue; j++)
    {

        while (notFound)
        {
            if ((char)PMMFlashRead(address + i) == '&')
            {
                returnData.concat((char)PMMFlashRead(address + i));
                notFound = false;
                i++;
            }
        }
    }
    notFound = true;
    return returnData;
}
void PMMFlashRemoveAndSignFromString(String &returnString)
{
    /**
     * removeAndSignFromString : get the first string from many Split string separeted with &
     * @param String returnString: the first string in this data without & Sign
     */
    int index = returnString.indexOf("&");
    returnString = returnString.substring(0, index);
}
void PMMFlashGetValueFromString(String parameter, String &returnVal,
                                String &returnString)
{
    /**
     * PMMFlashGetValueFromString : get the first string from many Split string separeted with &
     * Note That whene we save string we add & to indicate the end of it
     * @param String parameter: the line of data saved inEEPROM
     * @param String returnVal: the first string in this data
     * @param String returnString: the rest of the passed string
     *
     */
    int index = parameter.indexOf("&");
    returnVal = parameter.substring(0, index);
    returnString =
        parameter.substring((returnVal.length()) + 1, (parameter.length()));
}
void PMMFlashSplitString(String parameter, String &returnVal, String &returnString)
{
    /**
     * PMMFlashSplitString : get the first string from many Split string separeted with ,
     * Note That whene we save string we add & to indicate the end of it
     * @param String parameter: the line of data saved inEEPROM
     * @param String returnVal: the first string in this data
     * @param String returnString: the rest of the passed string
     */

    int index = parameter.indexOf(",");
    returnVal = parameter.substring(0, index);
    returnString = parameter.substring((returnVal.length()) + 1, (parameter.length()));
}

// void cleanEEPROM()
// {
//     /***
//      * cleanEEPROM() : Remove All Data From EEPROM
//      * Use this Function to remove old data from the project
//      */
//     Debugprintln("Start Cleaning EEPROM");
//     for (int i = 0; i < 2000; i++)
//     {
//         EEPROM.write(i, 0);
//     }
//     Debugprintln("EEPROM Cleaned");
// }
