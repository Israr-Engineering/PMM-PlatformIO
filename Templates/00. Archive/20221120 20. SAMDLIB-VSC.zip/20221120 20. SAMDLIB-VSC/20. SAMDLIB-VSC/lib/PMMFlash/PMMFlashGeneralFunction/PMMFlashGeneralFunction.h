#ifndef PMMFlashGeneralFunction
#define PMMFlashGeneralFunction
#include <Arduino.h>
#include <SPI.h>
#include <SparkFun SPI SerialFlash Arduino Library/src/SparkFun_SPI_SerialFlash.h>

#include <../PMMGlobalFunction/PMMGlobalFunction.h>

extern bool inDebugMode;
extern byte firstRunValue;
bool PMMFlashInit(byte flashCS);
void PMMFlashWrite(unsigned int eeAddr, uint8_t data);
byte PMMFlashRead(unsigned int eeAddr);
bool PMMFlashFirstRun();
void PMMFlashMarkAsRead();
String PMMFlashReadString(int address, int numberOfChar);
int PMMFlashSaveString(String toSave, int startFrom);
String PMMFlashReadJsonFromEEPROM(int address, int numberOfValue);
void PMMFlashRemoveAndSignFromString(String &returnString);
void PMMFlashGetValueFromString(String parameter, String &returnVal,String &returnString);
void PMMFlashSplitString(String parameter, String &returnVal, String &returnString);


#endif