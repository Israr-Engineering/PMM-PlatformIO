
#ifndef PMMEEPROMGeneralFunction
#define PMMEEPROMGeneralFunction
#include <Arduino.h>
#include <Wire.h>
#include <EthernetUdp.h>
#include <PMMEEPROMGeneralFunction/PMMEEPROMGeneralFunction.h>
#include <../PMMGlobalFunction/PMMGlobalFunction.h>
#include "SparkFun_External_EEPROM.h"


extern bool inDebugMode;
extern byte firstRunValue;


bool PMMEEPROMCheck();
void cleanEEPROM();
bool isItFirstRun();
void markAsRead();
byte readEEPROM(unsigned int eeAddr);
void writeEEPROM(unsigned int eeAddr, byte data);
void initEEPROM();
String readStringEEPROM(int address, int numberOfChar);
int saveStringToEEprom(String toSave, int startFrom);
void getValueFormString(String parameter, String &returnVal,String &returnString);
void splitString(String parameter, String &returnVal, String &returnString);
void removeAndSignFromString(String &returnString);
String readJsonFromEEPROM(int address, int numberOfValue);



#endif
