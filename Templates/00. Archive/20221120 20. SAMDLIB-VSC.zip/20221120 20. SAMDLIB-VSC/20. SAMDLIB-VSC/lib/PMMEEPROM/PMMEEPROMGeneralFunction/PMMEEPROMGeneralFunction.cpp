#include <PMMEEPROMGeneralFunction/PMMEEPROMGeneralFunction.h>
ExternalEEPROM EEPROM;

bool PMMEEPROMCheck()
{
    Wire.begin();
    Wire.beginTransmission(0x50);
    bool EEPROMFound = Wire.endTransmission() == 0;
    return EEPROMFound;
}

void initEEPROM()
{
    /**
     * initEEPROM() :: Call this Function at the start of program
     */
    Wire.begin();
    EEPROM.begin();
    Debugprintln("EEPROM Init Successfully");
}
bool isItFirstRun()
{
    bool firstRun = (readEEPROM(1) != firstRunValue);
    SerialUSB.println("=========================================");
    SerialUSB.println(EEPROM.length());
    SerialUSB.println(EEPROM.length());
    if (firstRun)
        Debugprintln("First Run");
    else
        Debugprintln("Used Before");
    return firstRun;
}
void markAsRead()
{
    writeEEPROM(firstRunValue, 1);
}
void cleanEEPROM()
{
    /***
     * cleanEEPROM() : Remove All Data From EEPROM
     * Use this Function to remove old data from the project
     */
    Debugprintln("Start Cleaning EEPROM");

    for (int i = 0; i < 2000; i++)
    {
        EEPROM.write(i, 0);
    }
    Debugprintln("EEPROM Cleaned");
}
String readStringEEPROM(int address, int numberOfChar)
{
    // === Return the Saved Data in EEPROM As Srting
    String returnData = "";
    int j;
    for (j = 0; j < numberOfChar; j++)
    {

        returnData.concat((char)(EEPROM.read(address + j)));
    }
    return returnData;
}
void writeEEPROM(unsigned int eeAddr, byte data)
{
    /**
     * writeEEPROM: Write A Byte to the EEPROM
     * @param int eeAddr: the EEPROM Address
     * @param byte data: the Byte to Write
     */
    // EEPROM.begin();
    EEPROM.put(eeAddr, (char)data);
}
void removeAndSignFromString(String &returnString)
{
    /**
     * removeAndSignFromString : get the first string from many Split string separeted with &
     * @param String returnString: the first string in this data without & Sign
     */
    int index = returnString.indexOf("&");
    returnString = returnString.substring(0, index);
}
byte readEEPROM(unsigned int eeAddr)
{
    /**
     * readEEPROM : Return the Saved Byte in Specific Address
     * @param int eeAddr: the EEPROM Address
     */
    byte readByte = 255;
    // EEPROM.begin();
    readByte = (char)EEPROM.read(eeAddr);
    return readByte;
}
void getValueFormString(String parameter, String &returnVal,
                        String &returnString)
{
    /**
     * getValueFormString : get the first string from many Split string separeted with &
     * Note That whene we save string we add & to indicate the end of it
     * @param String parameter: the line of data saved inEEPROM
     * @param String returnVal: the first string in this data
     * @param String returnString: the rest of the passed string
     *
     */
    int index = parameter.indexOf("&");
    returnVal = parameter.substring(0, index);
    returnString =
        parameter.substring((returnVal.length()) + 1, (parameter.length()));
}
int saveStringToEEprom(String toSave, int startFrom)
{
    /**
     * saveStringToEEprom   : Save string value to EEPROM
     * @param String toSave : the  String to save
     * @param int startFrom : the starting address
     * @return int the next free space
     */
    // === Add Extra Char for the string {Without this the last char will
    EEPROM.begin();
    toSave.concat(":");
    signed i = 0;

    // === Save it to EEprom
    while ((toSave.length() - 1) > i)
    {
        EEPROM.put(startFrom + i, toSave[i]); //(char)b2[i]);
        i++;
    }
    // delay(1);
    // === Use & to Split Data
    EEPROM.put(startFrom + i, (char)'&');
    return (startFrom + 1 + i);
}
void splitString(String parameter, String &returnVal, String &returnString)
{
    /**
     * getValueFormString : get the first string from many Split string separeted with ,
     * Note That whene we save string we add & to indicate the end of it
     * @param String parameter: the line of data saved inEEPROM
     * @param String returnVal: the first string in this data
     * @param String returnString: the rest of the passed string
     *
     */
    int index = parameter.indexOf(",");
    returnVal = parameter.substring(0, index);
    returnString = parameter.substring((returnVal.length()) + 1, (parameter.length()));
}
String readJsonFromEEPROM(int address, int numberOfValue)
{
    // === Return the Saved Data in EEPROM As Srting Separeted by & Sign
    bool notFound = true;
    String returnData = "";
    int i = 0;
    int j;
    for (j = 0; j < numberOfValue; j++)
    {

        while (notFound)
        {
            if ((char)EEPROM.read(address + i) == '&')
            {
                returnData.concat((char)EEPROM.read(address + i));
                notFound = false;
                i++;
            }
        }
    }
    notFound = true;
    return returnData;
}
