#ifndef PMMEEPROMPID
#define PMMEEPROMPID

#include <Arduino.h>
#include <PMMEEPROMGeneralFunction/PMMEEPROMGeneralFunction.h>
#include <projectConfigration.h>
#include <PMMGlobalFunction.h>

void PMMSetPidInfo();
void PMMGetPidInfo();


extern struct PIDArray pidArray[4];


#endif