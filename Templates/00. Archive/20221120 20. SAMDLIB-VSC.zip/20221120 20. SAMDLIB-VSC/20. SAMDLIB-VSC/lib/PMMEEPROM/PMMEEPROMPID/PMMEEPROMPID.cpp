#include <PMMEEPROMPID/PMMEEPROMPID.h>

/**
 * 1200 - 1300
 */
void PMMSetPidInfo()
{
    String requestFourm = String(pidArray[0].setPoint) + "," + String(pidArray[0].kp) + "," + String(pidArray[0].ki) + "," + String(pidArray[0].kd) + "," + String(pidArray[0].minOutput) + "," + String(pidArray[0].maxOutput) + "," +
                          String(pidArray[1].setPoint) + "," + String(pidArray[1].kp) + "," + String(pidArray[1].ki) + "," + String(pidArray[1].kd) + "," + String(pidArray[1].minOutput) + "," + String(pidArray[1].maxOutput) + "," +
                          String(pidArray[2].setPoint) + "," + String(pidArray[2].kp) + "," + String(pidArray[2].ki) + "," + String(pidArray[2].kd) + "," + String(pidArray[2].minOutput) + "," + String(pidArray[2].maxOutput) + "," +
                          String(pidArray[3].setPoint) + "," + String(pidArray[3].kp) + "," + String(pidArray[3].ki) + "," + String(pidArray[3].kd) + "," + String(pidArray[3].minOutput) + "," + String(pidArray[3].maxOutput);
    saveStringToEEprom(requestFourm, 1200);
    int numberofChar = requestFourm.length();
    writeEEPROM(1299, numberofChar);
    PMMGetPidInfo();
}
void PMMGetPidInfo()
{

    String toConverte = "";
    byte numberofChar = readEEPROM(1299);
    String serialData = readStringEEPROM(1200, numberofChar);
    splitString(serialData, toConverte, serialData);
    pidArray[0].setPoint = toConverte.toDouble();
    splitString(serialData, toConverte, serialData);
    pidArray[0].kp = toConverte.toDouble();
    splitString(serialData, toConverte, serialData);
    pidArray[0].ki = toConverte.toDouble();
    splitString(serialData, toConverte, serialData);
    pidArray[0].kd = toConverte.toDouble();
    splitString(serialData, toConverte, serialData);
    pidArray[0].minOutput = toConverte.toDouble();
    splitString(serialData, toConverte, serialData);
    pidArray[0].maxOutput = toConverte.toDouble();
    splitString(serialData, toConverte, serialData);
    pidArray[1].setPoint = toConverte.toDouble();
    splitString(serialData, toConverte, serialData);
    pidArray[1].kp = toConverte.toDouble();
    splitString(serialData, toConverte, serialData);
    pidArray[1].ki = toConverte.toDouble();
    splitString(serialData, toConverte, serialData);
    pidArray[1].kd = toConverte.toDouble();
    splitString(serialData, toConverte, serialData);
    pidArray[1].minOutput = toConverte.toDouble();
    splitString(serialData, toConverte, serialData);
    pidArray[1].maxOutput = toConverte.toDouble();
    splitString(serialData, toConverte, serialData);
    pidArray[2].setPoint = toConverte.toDouble();
    splitString(serialData, toConverte, serialData);
    pidArray[2].kp = toConverte.toDouble();
    splitString(serialData, toConverte, serialData);
    pidArray[2].ki = toConverte.toDouble();
    splitString(serialData, toConverte, serialData);
    pidArray[2].kd = toConverte.toDouble();
    splitString(serialData, toConverte, serialData);
    pidArray[2].minOutput = toConverte.toDouble();
    splitString(serialData, toConverte, serialData);
    pidArray[2].maxOutput = toConverte.toDouble();
    splitString(serialData, toConverte, serialData);
    pidArray[3].setPoint = toConverte.toDouble();
    splitString(serialData, toConverte, serialData);
    pidArray[3].kp = toConverte.toDouble();
    splitString(serialData, toConverte, serialData);
    pidArray[3].ki = toConverte.toDouble();
    splitString(serialData, toConverte, serialData);
    pidArray[3].kd = toConverte.toDouble();
    splitString(serialData, toConverte, serialData);
    pidArray[3].minOutput = toConverte.toDouble();
    splitString(serialData, toConverte, serialData);
    pidArray[3].maxOutput = toConverte.toDouble();
}