/**
 * @file PMMEEPROMTrackerSettings.h
 * @author Ahmad Joghaimi
 * @brief  Tracker Settings
 * @version 0.1
 * @date 2022-09-11
 * @copyright Copyright (c) 2022
 * @EEPROM Address 1300 - 1500
 */

#ifndef PMMEEPROMTrackerSettings
#define PMMEEPROMTrackerSettings

#include <Arduino.h>
#include <PMMEEPROMGeneralFunction/PMMEEPROMGeneralFunction.h>
#include <projectConfigration.h>
#include <PMMGlobalFunction.h>
extern float xAxisCalibration, yAxisCalibration, zAxisCalibration;
extern float PMM1103RequiredMasterx, PMM1103RequiredMastery, PMM1103RequiredMasterz;
extern float PMM1103TollerentMasterx, PMM1103TollerentMastery, PMM1103TollerentMasterz;
extern int PMM1103MasterlostCommunicationTime, PMM1103ModeType;
extern float PMMMPUOldReadingValuex, PMMMPUOldReadingValuey, PMMMPUOldReadingValuez;
extern float PMM1103MaxLimitSwitchDegree, PMM1103MinLimitSwitchDegree, PMM1103MaxDegree, PMM1103MinDegree;
extern float PMM1103TimeZone, PMM1103Longitude,PMM1103Latitude;
extern int PMM1103LostCommunicationDay;

void PMMGetMasterTrackerInfo();
void PMMSetMasterTrackerInfo();

void PMMSetTrackerInfo();
void PMMGetTrackerInfo();

#endif