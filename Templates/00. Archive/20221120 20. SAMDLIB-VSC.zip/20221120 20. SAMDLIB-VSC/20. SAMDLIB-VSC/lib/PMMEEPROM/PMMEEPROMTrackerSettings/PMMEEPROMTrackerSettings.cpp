#include <PMMEEPROMTrackerSettings/PMMEEPROMTrackerSettings.h>
void PMMSetMasterTrackerInfo()
{
    String requestFourm =
        String(PMM1103RequiredMasterx) + "," + String(PMM1103RequiredMastery) + "," + String(PMM1103RequiredMasterz) + "," +
        String(PMM1103TollerentMasterx) + "," + String(PMM1103TollerentMastery) + "," + String(PMM1103TollerentMasterz) + "," +
        String(xAxisCalibration) + "," + String(yAxisCalibration) + "," + String(zAxisCalibration) + "," + String(PMM1103MasterlostCommunicationTime) + "," +
        String(PMMMPUOldReadingValuex) + "," + String(PMMMPUOldReadingValuey) + "," + String(PMMMPUOldReadingValuez) + "," + String(PMM1103ModeType) + "," +
        String(PMM1103MaxLimitSwitchDegree) + "," + String(PMM1103MinLimitSwitchDegree) + "," + String(PMM1103MaxDegree) + "," + String(PMM1103MinDegree) + "," +
        String(PMM1103TimeZone) + "," + String(PMM1103Longitude) + "," + String(PMM1103Latitude) + ","+PMM1103LostCommunicationDay+ ",";
    saveStringToEEprom(requestFourm, 1300);
    int numberofChar = requestFourm.length();
    writeEEPROM(1499, numberofChar);
    SerialUSB.println(requestFourm);
    PMMGetMasterTrackerInfo();
}
void PMMGetMasterTrackerInfo()
{
    String toConverte = "";
    byte numberofChar = readEEPROM(1499);
    SerialUSB.println(numberofChar);
    String trackerData = readStringEEPROM(1300, numberofChar);
    SerialUSB.println(trackerData);
    // Required Tracking Degree
    splitString(trackerData, toConverte, trackerData);
    PMM1103RequiredMasterx = toConverte.toFloat();
    splitString(trackerData, toConverte, trackerData);
    PMM1103RequiredMastery = toConverte.toFloat();
    splitString(trackerData, toConverte, trackerData);
    PMM1103RequiredMasterz = toConverte.toFloat();
    // Required Tolerance
    splitString(trackerData, toConverte, trackerData);
    PMM1103TollerentMasterx = toConverte.toFloat();
    splitString(trackerData, toConverte, trackerData);
    PMM1103TollerentMastery = toConverte.toFloat();
    splitString(trackerData, toConverte, trackerData);
    PMM1103TollerentMasterz = toConverte.toFloat();
    // Calibration Info
    splitString(trackerData, toConverte, trackerData);
    xAxisCalibration = toConverte.toFloat();
    splitString(trackerData, toConverte, trackerData);
    yAxisCalibration = toConverte.toFloat();
    splitString(trackerData, toConverte, trackerData);
    zAxisCalibration = toConverte.toFloat();
    // Lost Communication
    splitString(trackerData, toConverte, trackerData);
    PMM1103MasterlostCommunicationTime = toConverte.toInt();
    // MPU Last Saved Data
    splitString(trackerData, toConverte, trackerData);
    PMMMPUOldReadingValuex = toConverte.toFloat();
    splitString(trackerData, toConverte, trackerData);
    PMMMPUOldReadingValuey = toConverte.toFloat();
    splitString(trackerData, toConverte, trackerData);
    PMMMPUOldReadingValuez = toConverte.toFloat();
    // Mode Type
    splitString(trackerData, toConverte, trackerData);
    PMM1103ModeType = toConverte.toInt();
    // Maximum & Minumum Degree
    splitString(trackerData, toConverte, trackerData);
    PMM1103MaxLimitSwitchDegree = toConverte.toFloat();
    splitString(trackerData, toConverte, trackerData);
    PMM1103MinLimitSwitchDegree = toConverte.toFloat();
    splitString(trackerData, toConverte, trackerData);
    PMM1103MaxDegree = toConverte.toFloat();
    splitString(trackerData, toConverte, trackerData);
    PMM1103MinDegree = toConverte.toFloat();
    // Tracking Info
    splitString(trackerData, toConverte, trackerData);
    PMM1103TimeZone = toConverte.toFloat();
    splitString(trackerData, toConverte, trackerData);
    PMM1103Longitude = toConverte.toFloat();
    splitString(trackerData, toConverte, trackerData);
    PMM1103Latitude = toConverte.toFloat();
    splitString(trackerData, toConverte, trackerData);
    PMM1103LostCommunicationDay = toConverte.toInt();

    // SerialUSB.println(PMM1103TimeZone);
    // SerialUSB.println(PMM1103Longitude);
    // SerialUSB.println(PMM1103Latitude);
}

void PMMSetTrackerInfo()
{
    String requestFourm = String(xAxisCalibration) + "," + String(yAxisCalibration) + "," + String(zAxisCalibration);
    saveStringToEEprom(requestFourm, 1300);
    int numberofChar = requestFourm.length();
    writeEEPROM(1399, numberofChar);
    PMMGetTrackerInfo();
}
void PMMGetTrackerInfo()
{
    // String toConverte = "";
    // byte numberofChar = readEEPROM(1);
    // String trackerData = readStringEEPROM(1, numberofChar);

    // splitString(trackerData, toConverte, trackerData);
    // xAxisCalibration = toConverte.toFloat();
    // splitString(trackerData, toConverte, trackerData);
    // yAxisCalibration = toConverte.toFloat();
    // splitString(trackerData, toConverte, trackerData);
    // zAxisCalibration = toConverte.toFloat();
}