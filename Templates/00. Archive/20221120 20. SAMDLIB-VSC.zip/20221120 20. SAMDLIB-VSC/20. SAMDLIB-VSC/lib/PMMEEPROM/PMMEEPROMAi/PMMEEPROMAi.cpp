#include <PMMEEPROMAi/PMMEEPROMAi.h>
// EEPROM : 700 - 900

// device type,Modbus communicatio type TCP/RTU , INPUTS SPECIFICATION,
void setAiInfo()
{

    String AiParameterToSave = "";
    for (uint8_t i = 0; i < 8; i++)
    {
        AiParameterToSave += String(aiArray[i].canBeNegative) + ",";
        AiParameterToSave += String(aiArray[i].factorValue) + ",";
        AiParameterToSave += String(aiArray[i].offset) + ",";
        AiParameterToSave += String(aiArray[i].equationType) + ",";
        AiParameterToSave += String(aiArray[i].FX) + ",";
        AiParameterToSave += String(aiArray[i].OX) + ",";
    }

    Debugprintln(AiParameterToSave);
    saveStringToEEprom(AiParameterToSave, 700);
    int numberofChar = AiParameterToSave.length();
    writeEEPROM(899, numberofChar);
    getAiInfo();
}
void getAiInfo()
{

    byte numberofChar = readEEPROM(899);
    String AiParameter = readStringEEPROM(700, numberofChar);
    String holder = "";
    Debugprintln("Analog Input Info");
    Debugprint(AiParameter);
    for (uint8_t i = 0; i < 8; i++)
    {
        splitString(AiParameter, holder, AiParameter);
        aiArray[i].canBeNegative = holder == "1" ? true : false;
        splitString(AiParameter, holder, AiParameter);
        aiArray[i].factorValue = holder.toFloat();
        splitString(AiParameter, holder, AiParameter);
        aiArray[i].offset = holder.toFloat();

        splitString(AiParameter, holder, AiParameter);
        aiArray[i].equationType = holder == "1" ? true : false;

        splitString(AiParameter, holder, AiParameter);
        aiArray[i].FX = holder.toInt();
        splitString(AiParameter, holder, AiParameter);

        if (i != 7)
            aiArray[i].OX = holder.toInt();
    }
    removeAndSignFromString(holder);
    aiArray[7].OX = holder.toInt();
    SerialUSB.println();
    Debugprintln("get Settings Saved");
}