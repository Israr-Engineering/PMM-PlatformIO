/**
 * @file PMMEEPROMAi.h
 * @author Ahmad Joghaimi
 * @brief Save Ai info inside EEPROM
 * @version 0.1
 * @date 2022-03-11
 * EEPROM Start Address 700-800
 * @copyright Copyright (c) 2022
 */

#ifndef PMMEEPROMAi
#define PMMEEPROMAi
#include <Arduino.h>
#include <PMMEEPROMGeneralFunction/PMMEEPROMGeneralFunction.h>
#include <projectConfigration.h>
#include <PMMGlobalFunction.h>
extern struct AI aiArray[8];
void setAiInfo();
void getAiInfo();

#endif