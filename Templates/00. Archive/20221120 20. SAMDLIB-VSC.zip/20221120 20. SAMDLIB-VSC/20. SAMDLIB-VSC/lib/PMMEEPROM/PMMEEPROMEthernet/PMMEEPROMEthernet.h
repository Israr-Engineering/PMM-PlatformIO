#ifndef PMMEEPROMEthernet
#define PMMEEPROMEthernet
#include <Arduino.h>
#include <Ethernet.h>
#include <Wire.h>
#include <../PMMEEPROM/PMMEEPROMGeneralFunction/PMMEEPROMGeneralFunction.h>
// #include </generalEEPROMFunction.h>
#include <projectConfigration.h>
/**
 * UDP SET & GET Update UDP
 * UDP Setting in EEPROM Start From 
 * EEPROM Address 200 - 300 
 * 
*/

void setDefaultUDPSetting();
String getUDPSetting();


#endif
