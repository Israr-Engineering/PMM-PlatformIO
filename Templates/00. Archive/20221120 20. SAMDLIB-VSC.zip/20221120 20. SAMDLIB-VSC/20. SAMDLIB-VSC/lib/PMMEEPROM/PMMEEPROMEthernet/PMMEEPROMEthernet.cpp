#include <PMMEEPROMEthernet/PMMEEPROMEthernet.h>

extern ExternalEEPROM EEPROM;
extern String controllerIPAddress;
extern String subNetMask;
extern String DNS;
extern String GatWay;
extern String remoteIPAddress;
extern String UDPPort;
extern String UDPPort2;
extern String UDPPort3;
extern String UDPPort4;
extern String selOperation;

void setDefaultUDPSetting()
{
    /**
     * Set Default UDP Setting this Function will used at first Run of the project
     * Also its take the parameter from Project Configure File
     */
    // Controller IP Address , DNS , GatWay , Remote IP Address , UDPPort
    String requestFourm = controllerIPAddress + "," + subNetMask + "," + DNS + "," + GatWay + "," + remoteIPAddress + "," + UDPPort + "," + UDPPort2 + "," + UDPPort3 + "," + UDPPort4 + "," + selOperation;
    saveStringToEEprom(requestFourm, 200);
    int numberofChar = requestFourm.length();
    writeEEPROM(299, numberofChar);
    getUDPSetting();
}
String getUDPSetting()
{
    /**
     *
     * Get Saved UDP Setting And Save them on String variable
     */
    byte numberofChar = readEEPROM(299);
    String allDatas = readStringEEPROM(200, numberofChar);
    // if (inDebugMode)
    // {
    //     SerialUSB.print("UDP Setting Data From EEPROM ");
    //     SerialUSB.println(allDatas);
    //     SerialUSB.print("Number of Char ");
    //     SerialUSB.println(numberofChar);
    // }
    splitString(allDatas, controllerIPAddress, allDatas);
    splitString(allDatas, subNetMask, allDatas);
    splitString(allDatas, DNS, allDatas);
    splitString(allDatas, GatWay, allDatas);
    splitString(allDatas, remoteIPAddress, allDatas);
    splitString(allDatas, UDPPort, allDatas);
    splitString(allDatas, UDPPort2, allDatas);
    splitString(allDatas, UDPPort3, allDatas);
    splitString(allDatas, UDPPort4, allDatas);
    splitString(allDatas, selOperation, allDatas);
    removeAndSignFromString(selOperation); // Tor emove the Extra & in the final element
    // if (inDebugMode)
    // {
    //     SerialUSB.println("UDP Configration");
    //     SerialUSB.print("controllerIPAddress: ");
    //     SerialUSB.println(controllerIPAddress);
    //     SerialUSB.print("DNS: ");
    //     SerialUSB.println(DNS);
    //     SerialUSB.print("GatWay: ");
    //     SerialUSB.println(GatWay);
    //     SerialUSB.print("remoteIPAddress: ");
    //     SerialUSB.println(remoteIPAddress);
    //     SerialUSB.print("UDPPort: ");
    //     SerialUSB.println(UDPPort);
    //     SerialUSB.println(UDPPort2);
    //     SerialUSB.println(UDPPort3);
    //     SerialUSB.println(UDPPort4);
    //     SerialUSB.print("SEL Operation: ");
    //     SerialUSB.println(selOperation);
    //     SerialUSB.println(allDatas);
    // }
    return allDatas;
}
