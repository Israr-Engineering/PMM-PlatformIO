#ifndef PMMEEPROMAO
#define PMMEEPROMAO

#include <Arduino.h>
#include <PMMEEPROMGeneralFunction/PMMEEPROMGeneralFunction.h>
#include <projectConfigration.h>
#include <PMMGlobalFunction.h>

extern struct AO aoArray[4];
extern struct AD7441 PMMAD7441;

void setAOInfo();
void getAOInfo();
float mapfloatEE(float x, long in_min, long in_max, long out_min, long out_max);
#endif