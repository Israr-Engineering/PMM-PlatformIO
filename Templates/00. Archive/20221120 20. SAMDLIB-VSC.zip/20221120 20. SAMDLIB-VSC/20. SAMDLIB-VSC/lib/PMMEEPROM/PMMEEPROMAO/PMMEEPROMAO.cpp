#include <PMMEEPROMAO/PMMEEPROMAO.h>
// EEPROM : 900 - 1000
void setAOInfo()
{

    Debugprintln("Set Analog Output Info");
    String AOParameterToSave = "";
    for (uint8_t i = 0; i < 4; i++)
    {
        AOParameterToSave += String(aoArray[i].isVoltage) + ",";
        AOParameterToSave += String(aoArray[i].forced) + ",";
        AOParameterToSave += String(aoArray[i].floatToInt.valueAsFloat) + ",";
    }

    Debugprintln(AOParameterToSave);
    saveStringToEEprom(AOParameterToSave, 900);
    int numberofChar = AOParameterToSave.length();
    writeEEPROM(999, numberofChar);
    getAOInfo();

    digitalWrite(PMMAD7441.rst, LOW);
    delay(20);
    digitalWrite(PMMAD7441.rst, HIGH);
}
void getAOInfo()
{
    byte numberofChar = readEEPROM(999);
    String AiParameter = readStringEEPROM(900, numberofChar);
    String holder = "";
    Debugprintln("get Analog Output Info");
    Debugprint(AiParameter);
    for (uint8_t i = 0; i < 3; i++)
    {
        splitString(AiParameter, holder, AiParameter);
        aoArray[i].isVoltage = holder == "1" ? true : false;
        splitString(AiParameter, holder, AiParameter);
        aoArray[i].forced = holder == "1" ? true : false;
        splitString(AiParameter, holder, AiParameter);
        aoArray[i].floatToInt.valueAsFloat = holder.toFloat();
        if (aoArray[i].forced)
            aoArray[i].valueOnADC = mapfloatEE(aoArray[i].floatToInt.valueAsFloat, 0, 11, 0, 8191);

        if (i == 3)
            break;
        aoArray[i].floatToInt.valueAsFloat = holder.toFloat();
    }
    removeAndSignFromString(holder);
    aoArray[3].floatToInt.valueAsFloat = holder.toFloat();
    if (aoArray[3].forced)
        aoArray[3].valueOnADC = mapfloatEE(aoArray[3].floatToInt.valueAsFloat, 0, 11, 0, 8191);

    Debugprintln("get Settings Saved");
}
float mapfloatEE(float x, long in_min, long in_max, long out_min, long out_max)
{

    return (float)(x - in_min) * (out_max - out_min) / (float)(in_max - in_min) + out_min;
}