#ifndef PMMWebServerOnEEPROM
#define PMMWebServerOnEEPROM
#include <Arduino.h>
#include <Ethernet.h>
#include <../PMMEEPROM/PMMEEPROMGeneralFunction/PMMEEPROMGeneralFunction.h>
#include <projectConfigration.h>

void PMMWebPageSetHeaderTag();
void PMMWebPageSetFooter();
void PMMWebPageSetLogin();
void PMMWebPageToEEPROM(int startAddress,String address);
// void PMMWebPageGetHeaderTag();
void PMMWebPageSetAbout();

#endif 