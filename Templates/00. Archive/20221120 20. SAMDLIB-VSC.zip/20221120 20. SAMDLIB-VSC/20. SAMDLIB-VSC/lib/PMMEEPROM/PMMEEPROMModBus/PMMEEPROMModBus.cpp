#include <PMMEEPROMModBus/PMMEEPROMModBus.h>
/**
 * @brief save ModBus Setting in the eeprom starting from Byte 500
 * Data Sequence ModbusOrUDP,TCPORRTU,slaveId,ReadCoilsStartAddress,ReadCoilsQuintity,WriteCoilsStartAddress,WriteCoilsQuintity,
 * ReadHoldingRegStartAddress,ReadHoldingRegQuintity,WriteHoldingRegStartAddress,WriteHoldingRegQuintity,inputRegisterStartAddress,inputRegisterQuintity
 */

void PMMSetModbusSeting()
{
    String requestFourm = ModbusOrUDP + "," + TCPORRTU + "," + slaveId + "," + ReadCoilsStartAddress + "," + ReadCoilsQuintity + "," + WriteCoilsStartAddress + "," + WriteCoilQuint + "," + ReadHoldingRegStartAddress + "," + ReadHoldingRegQuintity +
                          "," + WriteHoldingRegStartAddress + "," + WriteHoldingRegQuintity + "," + inputRegisterStartAddress + "," + inputRegisterQuintity;

    int numberofChar = requestFourm.length();
    saveStringToEEprom(requestFourm, 500);
    writeEEPROM(599, numberofChar);
    // Debugprintln("ModBus Setting :");
    // Debugprint("ModbusOrUDP :");
    // Debugprintln(ModbusOrUDP);
    // Debugprint("TCPORRTU :");
    // Debugprintln(TCPORRTU);
    // Debugprint("slaveId :");
    // Debugprintln(slaveId);
    // Debugprint("ReadCoilsStartAddress :");
    // Debugprintln(ReadCoilsStartAddress);
    // Debugprint("ReadCoilsQuintity :");
    // Debugprintln(ReadCoilsQuintity);
    // Debugprint("WriteCoilsStartAddress :");
    // Debugprintln(WriteCoilsStartAddress);
    // Debugprint("WriteCoilsQuintity :");
    // Debugprintln(WriteCoilsQuintity);
    // Debugprint("ReadHoldingRegStartAddress :");
    // Debugprintln(ReadHoldingRegStartAddress);
    // Debugprint("ReadHoldingRegQuintity :");
    // Debugprintln(ReadHoldingRegQuintity);
    // Debugprint("WriteHoldingRegStartAddress :");
    // Debugprintln(WriteHoldingRegStartAddress);
    // Debugprint("WriteHoldingRegQuintity :");
    // Debugprintln(WriteHoldingRegQuintity);
    // Debugprint("inputRegisterStartAddress :");
    // Debugprintln(inputRegisterStartAddress);
    // Debugprint("inputRegisterQuintity :");
    // Debugprintln(inputRegisterQuintity);
    PMMgetModBusSetting();
}
void PMMgetModBusSetting()
{

    byte numberofChar = readEEPROM(599);
    String serialData = readStringEEPROM(500, numberofChar);
    splitString(serialData, ModbusOrUDP, serialData);
    splitString(serialData, TCPORRTU, serialData);
    splitString(serialData, slaveId, serialData);
    splitString(serialData, ReadCoilsStartAddress, serialData);
    splitString(serialData, ReadCoilsQuintity, serialData);
    splitString(serialData, WriteCoilsStartAddress, serialData);
    splitString(serialData, WriteCoilQuint, serialData);
    splitString(serialData, ReadHoldingRegStartAddress, serialData);
    splitString(serialData, ReadHoldingRegQuintity, serialData);
    splitString(serialData, WriteHoldingRegStartAddress, serialData);
    splitString(serialData, WriteHoldingRegQuintity, serialData);
    splitString(serialData, inputRegisterStartAddress, serialData);
    splitString(serialData, inputRegisterQuintity, serialData);
    // Debugprintln("ModBus Setting :");
    // Debugprint("ModbusOrUDP :");
    // Debugprintln(ModbusOrUDP);
    // Debugprint("TCPORRTU :");
    // Debugprintln(TCPORRTU);
    // Debugprint("slaveId :");
    // Debugprintln(slaveId);
    // Debugprint("ReadCoilsStartAddress :");
    // Debugprintln(ReadCoilsStartAddress);
    // Debugprint("ReadCoilsQuintity :");
    // Debugprintln(ReadCoilsQuintity);
    // Debugprint("WriteCoilsStartAddress :");
    // Debugprintln(WriteCoilsStartAddress);
    // Debugprint("WriteCoilsQuintity :");
    // Debugprintln(WriteCoilsQuintity);
    // Debugprint("ReadHoldingRegStartAddress :");
    // Debugprintln(ReadHoldingRegStartAddress);
    // Debugprint("ReadHoldingRegQuintity :");
    // Debugprintln(ReadHoldingRegQuintity);
    // Debugprint("WriteHoldingRegStartAddress :");
    // Debugprintln(WriteHoldingRegStartAddress);
    // Debugprint("WriteHoldingRegQuintity :");
    // Debugprintln(WriteHoldingRegQuintity);
    // Debugprint("inputRegisterStartAddress :");
    // Debugprintln(inputRegisterStartAddress);
    // Debugprint("inputRegisterQuintity :");
    // Debugprintln(inputRegisterQuintity);
}