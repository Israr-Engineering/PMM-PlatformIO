/**
 * @file PMMEEPROMModBus.h
 * @author Ahmad Joghaimi
 * @brief  Modbus Settings And info
 * @version 0.1
 * @date 2022-01-17
 * @copyright Copyright (c) 2022
 * Modbus Info :
 *   - TCP or RTU
 *   - ModbusOrUDP
 *   - Slave id
 *   - ReadCoils Start Address
 *   - ReadCoils Quintity
 *   - WriteCoils Start Address
 *   - WriteCoils Quintity
 *   - ReedHoldingReg Start Address
 *   - ReedHoldingReg Quintity
 *   - WriteHoldingReg Start Address
 *   - WriteHoldingReg Quintity
 *   - inputRegister Start Address
 *   - inputRegister Quintity
 */
#ifndef PMMEEPROMModBus
#define PMMEEPROMModBus
#include <Arduino.h>
#include <projectConfigration.h>
#include <PMMGlobalFunction.h>
#include <PMMEEPROMGeneralFunction/PMMEEPROMGeneralFunction.h>

extern String ModbusOrUDP;
extern String TCPORRTU;
extern String slaveId;
extern String ReadCoilsStartAddress;
extern String ReadCoilsQuintity;
extern String WriteCoilsStartAddress;
extern String WriteCoilsQuintity;
extern String WriteCoilQuint;
extern String ReadHoldingRegStartAddress;
extern String ReadHoldingRegQuintity;
extern String WriteHoldingRegStartAddress;
extern String WriteHoldingRegQuintity;
extern String inputRegisterStartAddress;
extern String inputRegisterQuintity;
void PMMSetModbusSeting();
void PMMgetModBusSetting();

#endif