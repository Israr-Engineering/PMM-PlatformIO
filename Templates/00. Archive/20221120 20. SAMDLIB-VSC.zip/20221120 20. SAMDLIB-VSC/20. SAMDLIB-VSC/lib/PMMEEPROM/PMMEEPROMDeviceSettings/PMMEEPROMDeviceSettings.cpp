#include <PMMEEPROMDeviceSettings/PMMEEPROMDeviceSettings.h>

void setDeviceSettings()
{
    /**
     * @brief Deep Info Saved Start At 10000
     */
    // Check if Deep Info Is Written 10000
    // RequestFourm: DeviceName,SerialNumber,Mac Address,Web Enable
    String requestFourm = DeviceName + "," + MACAddressString + "," + controllerSerialNumber + "," + webservestring + "," + FirmwareVersion + "," + hardwareVersion;
    Debugprintln(requestFourm);
    saveStringToEEprom(requestFourm, 1001);
    int numberofChar = requestFourm.length();
    // Save Default Setting
    writeEEPROM(1100, numberofChar);
    MACAddressString.getBytes(mac, MACAddressString.length());
}
void getDeviceSettings()
{
    byte numberofChar = readEEPROM(1100);
    String allDatas = readStringEEPROM(1001, numberofChar);
    splitString(allDatas, DeviceName, allDatas);
    splitString(allDatas, MACAddressString, allDatas);
    splitString(allDatas, controllerSerialNumber, allDatas);
    splitString(allDatas, webservestring, allDatas);
    splitString(allDatas, FirmwareVersion, allDatas);
    splitString(allDatas, hardwareVersion, allDatas);
    SerialUSB.println("############ Device ");
    SerialUSB.println(DeviceName);
    SerialUSB.println(MACAddressString);
    SerialUSB.println(controllerSerialNumber);
    SerialUSB.println(webservestring);
    SerialUSB.println(FirmwareVersion);
    SerialUSB.println(hardwareVersion);
    MACAddressString.getBytes(mac, MACAddressString.length());
}
