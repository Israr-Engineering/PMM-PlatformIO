#ifndef PMMEEPROMDeviceSettings
#define PMMEEPROMDeviceSettings
#include <Arduino.h>
#include <Ethernet.h>
#include <Wire.h>
#include <PMMEEPROMGeneralFunction/PMMEEPROMGeneralFunction.h>
#include <projectConfigration.h>
void setDeviceSettings();
void getDeviceSettings();

extern String DeviceName;
extern String MACAddressString;
extern String controllerSerialNumber;
extern String webservestring;
extern byte mac[] ;
extern String FirmwareVersion;
extern String hardwareVersion;

#endif