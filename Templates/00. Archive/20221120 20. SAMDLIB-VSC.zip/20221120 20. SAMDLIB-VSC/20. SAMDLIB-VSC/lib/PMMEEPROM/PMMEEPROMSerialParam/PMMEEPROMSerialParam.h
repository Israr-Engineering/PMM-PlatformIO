
/**
 * SET & GET Update SerialParametr
 * Serial Setting in EEPROM Start From 
 * EEPROM Address  2-100    
*/
#ifndef PMMEEPROMSerialParam
#define PMMEEPROMSerialParam
#include <Arduino.h>
#include <Wire.h>
// #include <generalEEPROMFunction.h>
#include <../PMMEEPROM/PMMEEPROMGeneralFunction/PMMEEPROMGeneralFunction.h>
#include <projectConfigration.h>
void setDefaultSerialMode();
void getSerialSettingFromEEPROM();
int initialSerialPort(Uart &serial, String baudRate, String dataBit,
                          String parity, String stopBit, String interface);


#endif