#include <PMMEEPROMSerialParam/PMMEEPROMSerialParam.h>

extern byte numberOfSerial;
extern SerialParameter portOne;
extern SerialParameter portTwo;
extern SerialParameter portThree;
extern SerialParameter portFour;
/**
 * Start Address in EEPROM :2-100
 * 
*/
void setDefaultSerialMode()
{
    /**
     * save the Default Serial Port Setting to EEPROM
     * Setting get From 
     * DataFourm PortOneBaudrate ,PortdataBit,stopBit,parity,interface
    */
    String SerialParameterToSave = "";
    SerialParameterToSave =
        portOne.baudRate + "," + portOne.dataBit + "," + portOne.stopBit + "," + portOne.parity + "," + portOne.interface + "," +
        portTwo.baudRate + "," + portTwo.dataBit + "," + portTwo.stopBit + "," + portTwo.parity + "," + portTwo.interface + "," +
        portThree.baudRate + "," + portThree.dataBit + "," + portThree.stopBit + "," + portThree.parity + "," + portThree.interface + "," +
        portFour.baudRate + "," + portFour.dataBit + "," + portFour.stopBit + "," + portFour.parity + "," + portFour.interface;
    saveStringToEEprom(SerialParameterToSave, 2);
    int numberofChar = SerialParameterToSave.length();
    writeEEPROM(99, numberofChar);
    getSerialSettingFromEEPROM();
}
void getSerialSettingFromEEPROM()
{

    byte numberofChar = readEEPROM(99);
    String serialData = readStringEEPROM(2, numberofChar);
    splitString(serialData, portOne.baudRate, serialData);
    splitString(serialData, portOne.dataBit, serialData);
    splitString(serialData, portOne.stopBit, serialData);
    splitString(serialData, portOne.parity, serialData);
    splitString(serialData, portOne.interface, serialData);
    splitString(serialData, portTwo.baudRate, serialData);
    splitString(serialData, portTwo.dataBit, serialData);
    splitString(serialData, portTwo.stopBit, serialData);
    splitString(serialData, portTwo.parity, serialData);
    splitString(serialData, portTwo.interface, serialData);
    splitString(serialData, portThree.baudRate, serialData);
    splitString(serialData, portThree.dataBit, serialData);
    splitString(serialData, portThree.stopBit, serialData);
    splitString(serialData, portThree.parity, serialData);
    splitString(serialData, portThree.interface, serialData);
    splitString(serialData, portFour.baudRate, serialData);
    splitString(serialData, portFour.dataBit, serialData);
    splitString(serialData, portFour.stopBit, serialData);
    splitString(serialData, portFour.parity, serialData);
    splitString(serialData, portFour.interface, serialData);
    removeAndSignFromString(portFour.interface);
    // if (inDebugMode)
    // {
    //     Debugprintln("Port One == > ");
    //     Debugprint("portOne baudRate ");
    //     Debugprintln(portOne.baudRate);
    //     Debugprint("portOne dataBit ");
    //     Debugprintln(portOne.dataBit);
    //     Debugprint("portOne stopBit ");
    //     Debugprint(portOne.stopBit);
    //     Debugprint("portOne parity");
    //     Debugprintln(portOne.parity);
    //     Debugprint("portOne interface ");
    //     Debugprintln(portOne.interface);
    //     Debugprintln("Port Two == > ");
    //     Debugprint("port Two baudRate ");
    //     Debugprintln(portTwo.baudRate);
    //     Debugprint("port Two dataBit ");
    //     Debugprintln(portTwo.dataBit);
    //     Debugprint("port Two stopBit ");
    //     Debugprint(portTwo.stopBit);
    //     Debugprint("port Two parity");
    //     Debugprintln(portTwo.parity);
    //     Debugprint("port Two interface ");
    //     Debugprintln(portTwo.interface);
    //     Debugprintln("Port Three == > ");
    //     Debugprint("port three baudRate ");
    //     Debugprintln(portThree.baudRate);
    //     Debugprint("portThree dataBit ");
    //     Debugprintln(portThree.dataBit);
    //     Debugprint("portThree stopBit ");
    //     Debugprint(portThree.stopBit);
    //     Debugprint("portThree parity");
    //     Debugprintln(portThree.parity);
    //     Debugprint("portThree interface ");
    //     Debugprintln(portThree.interface);
    //     Debugprintln("Port Four == > ");
    //     Debugprint("port Four baudRate ");
    //     Debugprintln(portFour.baudRate);
    //     Debugprint("portFour dataBit ");
    //     Debugprintln(portFour.dataBit);
    //     Debugprint("portFour stopBit ");
    //     Debugprint(portFour.stopBit);
    //     Debugprint("portFour parity");
    //     Debugprintln(portFour.parity);
    //     Debugprint("portFour interface ");
    //     Debugprintln(portFour.interface);
    // }
}
int initialSerialPort(Uart &serial, String baudRate, String dataBit,
                      String parity, String stopBit, String interface)
{
    /***
   * initialSerialPort Function is for initalizing the SerialPort For {UART1
   *,UART2 , UART3}
   * @param USARTClass refSe is pointer For the Serial Port
   * @param String baudRate : the saved value in EEPROM
   * @param String dataBit : the saved value in EEPROM
   * @param String parity : the saved value in EEPROM
   * @param String stopBit : the saved value in EEPROM
   * @param String interface : the saved value in EEPROM
   **/
    int BaudRate;
    int DataBit;
    int StopBit;
    int Parity;
    if (inDebugMode)
        SerialUSB.println("In Serial Initalization");
    if (baudRate == "0")
    {
        BaudRate = 115200;
    }
    else if (baudRate == "1")
    {
        BaudRate = 57600;
    }
    else if (baudRate == "2")
    {
        BaudRate = 38400;
    }
    else if (baudRate == "3")
    {
        BaudRate = 19200;
    }
    else if (baudRate == "4")
    {
        BaudRate = 9600;
    }
    else if (baudRate == "5")
    {
        BaudRate = 4800;
    }
    else if (baudRate == "6")
    {
        BaudRate = 2400;
    }
    else if (baudRate == "7")
    {
        BaudRate = 1200;
    }
    DataBit = dataBit.toInt();
    StopBit = dataBit.toInt();
    Parity = parity.toInt();
    if (DataBit == 3 && StopBit == 0 && Parity == 0)
    {
        serial.begin(BaudRate, SERIAL_5N1);
    }
    if (DataBit == 2 && StopBit == 0 && Parity == 0)
    {
        serial.begin(BaudRate, SERIAL_6N1);
    }
    if (DataBit == 1 && StopBit == 0 && Parity == 0)
    {
        serial.begin(BaudRate, SERIAL_7N1);
    }
    if (DataBit == 0 && StopBit == 0 && Parity == 0)
    {
        serial.begin(BaudRate, SERIAL_8N1);
    }
    if (DataBit == 3 && StopBit == 2 && Parity == 0)
    {
        serial.begin(BaudRate, SERIAL_5N1);
    }
    if (DataBit == 2 && StopBit == 2 && Parity == 0)
    {
        serial.begin(BaudRate, SERIAL_6N1);
    }
    if (DataBit == 1 && StopBit == 2 && Parity == 0)
    {
        serial.begin(BaudRate, SERIAL_7N1);
    }
    if (DataBit == 0 && StopBit == 2 && Parity == 0)
    {
        serial.begin(BaudRate, SERIAL_8N1);
    }
    if (DataBit == 3 && StopBit == 0 && Parity == 1)
    {
        serial.begin(BaudRate, SERIAL_5E1);
    }
    if (DataBit == 2 && StopBit == 0 && Parity == 1)
    {
        serial.begin(BaudRate, SERIAL_6E1);
    }
    if (DataBit == 1 && StopBit == 0 && Parity == 1)
    {
        serial.begin(BaudRate, SERIAL_7E1);
    }
    if (DataBit == 0 && StopBit == 0 && Parity == 1)
    {
        serial.begin(BaudRate, SERIAL_8E1);
    }
    if (DataBit == 3 && StopBit == 2 && Parity == 1)
    {
        serial.begin(BaudRate, SERIAL_5E2);
    }
    if (DataBit == 2 && StopBit == 2 && Parity == 1)
    {
        serial.begin(BaudRate, SERIAL_6E2);
    }
    if (DataBit == 1 && StopBit == 2 && Parity == 1)
    {
        serial.begin(BaudRate, SERIAL_7E2);
    }
    if (DataBit == 0 && StopBit == 2 && Parity == 1)
    {
        serial.begin(BaudRate, SERIAL_8E2);
    }
    if (DataBit == 3 && StopBit == 0 && Parity == 2)
    {
        serial.begin(BaudRate, SERIAL_5O1);
    }
    if (DataBit == 2 && StopBit == 0 && Parity == 2)
    {
        serial.begin(BaudRate, SERIAL_6O1);
    }
    if (DataBit == 1 && StopBit == 0 && Parity == 2)
    {
        serial.begin(BaudRate, SERIAL_7O1);
    }
    if (DataBit == 0 && StopBit == 0 && Parity == 2)
    {
        serial.begin(BaudRate, SERIAL_8O1);
    }
    if (DataBit == 3 && StopBit == 2 && Parity == 2)
    {
        serial.begin(BaudRate, SERIAL_5O2);
    }
    if (DataBit == 2 && StopBit == 2 && Parity == 2)
    {
        serial.begin(BaudRate, SERIAL_6O2);
    }
    if (DataBit == 1 && StopBit == 2 && Parity == 2)
    {
        serial.begin(BaudRate, SERIAL_7O2);
    }
    if (DataBit == 0 && StopBit == 2 && Parity == 2)
    {
        serial.begin(BaudRate, SERIAL_8O2);
    }

    if (inDebugMode)
    {
        SerialUSB.print("portOne baudRate in Num");
        SerialUSB.println(BaudRate);
        SerialUSB.println("Serial Initalized");
    }
    return BaudRate;
}
