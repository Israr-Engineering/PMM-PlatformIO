#include <PMMEEPROMAuth/PMMEEPROMAuth.h>

void setPasswordInEEPROM()
{
    int i = 400; // Length Size
    int numberofChar = password.length();
    writeEEPROM(i, numberofChar);
    saveStringToEEprom(password, i + 1);
    Debugprintln(password);
}
void returnSavedPasswordInEEPROM()
{

    byte numberofChar = readEEPROM(400); // Password Length
    password = readStringEEPROM(401, numberofChar);
    removeAndSignFromString(password);
    Debugprint("Saved Password: ");
    Debugprintln(password);
}