#ifndef PMMEEPROMAuth
#define PMMEEPROMAuth
#include <Arduino.h>
#include <PMMEEPROMGeneralFunction/PMMEEPROMGeneralFunction.h>
#include <projectConfigration.h>
#include <PMMGlobalFunction.h>


void setPasswordInEEPROM();
void returnSavedPasswordInEEPROM();
extern String password;

#endif