EEPROM Saved Addresses
   1            -> Mark As read
   2   - 100    -> Serial Settings
   200 - 300    -> UDP Settings
   400 - 420    -> Password Settings
   500 - 600    -> Modbus Settings
   700 - 900    -> Ai Settings
   900 - 1000   -> AO Settings
   1001- 1100   -> Device Settings
   1200- 1300   -> PID Settings
   1300- 1400   -> Tracker Settings

