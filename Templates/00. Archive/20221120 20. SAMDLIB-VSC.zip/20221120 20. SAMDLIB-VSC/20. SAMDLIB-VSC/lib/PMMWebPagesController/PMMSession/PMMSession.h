
#ifndef PMMSession
#define PMMSession
#include <Arduino.h>
#include <SPI.h>
#include <Ethernet.h>
#include <ArduinoJson.h>
#include <../projectConfigration/projectConfigration.h>

extern String controllerIPAddress;
extern String subNetMask;
extern String DNS;
extern String GatWay;
extern String remoteIPAddress;
extern String UDPPort;
extern String UDPPort2;
extern String UDPPort3;
extern String UDPPort4;
extern String MACAddressString;
extern String controllerSerialNumber;
extern String enableModBus;
extern String ModbusOrUDP;
extern String TCPORRTU;
extern String slaveId;

extern String IOType;
extern String IOslaveid;
extern struct SerialParameter portOne;
extern struct SerialParameter portTwo;
extern struct SerialParameter portThree;
extern struct SerialParameter portFour;

extern String ReadHoldingRegQuintity;
extern String ReadHoldingRegStartAddress;
extern String WriteCoilsStartAddress;
extern String WriteCoilQuint;
extern String ReadCoilsStartAddress;
extern String ReadCoilsQuintity;
extern String WriteHoldingRegStartAddress;
extern String WriteHoldingRegQuintity;

extern bool PMM0501Device;
extern bool PMM0406Device;
extern bool PMM1003Device;
extern bool PMM1002Device;
extern bool PMM6032Device;
extern bool PMM0620Device;
extern bool PMM0625TDevice;
extern bool PMM0626RDevice;
extern bool PMM0627Device;
extern bool PMM0638Device;
extern bool PMM0639Device;
extern bool PMM0613Device;
extern String selOperation;

extern AI aiArray[8];
extern AO aoArray[4];
extern PIDArray pidArray[4];
;

void saveSession(EthernetClient client, String sessionName, String items);
void returnAboutSession(EthernetClient client);
void returnSerialParameterSession(EthernetClient client);
void returnAccessableIPSession(EthernetClient client);
void saveSessionStart(EthernetClient client);
void saveSessionEnd(EthernetClient client);
void returnCommandSession(EthernetClient client);
void returnModBusConfigSession(EthernetClient client);
void returnModBusDOConfigSession(EthernetClient client);
void returnDIMonitorSession(EthernetClient client);
void returnIOSession(EthernetClient client);
#endif