#include <PMMSession/PMMSession.h>
/***
 * Return Saved Data From EEPROM TO webpages using Session
 **/
void returnAboutSession(EthernetClient client)
{
    /***
     * Return About and network page Saved Data From EEPROM TO webpages
     **/
    saveSessionStart(client);
    saveSession(client, "idAddress", controllerIPAddress);
    saveSession(client, "gateWay", GatWay);
    saveSession(client, "DNS1", DNS);
    saveSession(client, "netMask", subNetMask);
    saveSession(client, "SerialNumber", controllerSerialNumber);
    saveSession(client, "macAddress", MACAddressString);
    saveSession(client, "UDPPort", UDPPort);
    saveSession(client, "remoteIPAddress", remoteIPAddress);
    if (PMM1003Device || PMM1002Device)
        saveSession(client, "operation", selOperation);
    if (PMM0406Device || PMM0501Device)
    {
        saveSession(client, "UDPPort2", UDPPort2);
        if (PMM0406Device)
        {
            saveSession(client, "UDPPort3", UDPPort3);
            saveSession(client, "UDPPort4", UDPPort4);
        }
    }

    saveSessionEnd(client);
}
/**Serial Parameter**/
void returnSerialParameterSession(EthernetClient client)
{
    /***
     * Return Serial Parameter Session page Saved Data From EEPROM TO webpages
     **/
    saveSessionStart(client);
    // Port 1
    saveSession(client, "P1StopBit", portOne.stopBit);
    saveSession(client, "P1DataBit", portOne.dataBit);
    saveSession(client, "P1Interface", portOne.interface);
    saveSession(client, "P1parity", portOne.parity);
    saveSession(client, "P1BaudRate", portOne.baudRate);
    if (PMM0501Device || PMM0406Device)
    {
        // Port 2
        saveSession(client, "P2StopBit", portTwo.stopBit);
        saveSession(client, "P2DataBit", portTwo.dataBit);
        saveSession(client, "P2Interface", portTwo.interface);
        saveSession(client, "P2parity", portTwo.parity);
        saveSession(client, "P2BaudRate", portTwo.baudRate);
    }
    if (PMM0406Device)
    {
        // Port 3
        saveSession(client, "P3StopBit", portThree.stopBit);
        saveSession(client, "P3DataBit", portThree.dataBit);
        saveSession(client, "P3Interface", portThree.interface);
        saveSession(client, "P3parity", portThree.parity);
        saveSession(client, "P3BaudRate", portThree.baudRate);
        // Port 4
        saveSession(client, "P4StopBit", portFour.stopBit);
        saveSession(client, "P4DataBit", portFour.dataBit);
        saveSession(client, "P4Interface", portFour.interface);
        saveSession(client, "P4parity", portFour.parity);
        saveSession(client, "P4BaudRate", portFour.baudRate);
    }

    saveSessionEnd(client);
}
/**ModBus Configration**/
void returnModBusConfigSession(EthernetClient client)
{
    /***
     * Return Serial Parameter Session page Saved Data From EEPROM TO webpages
     **/
    saveSessionStart(client);
    if (PMM0501Device || PMM0406Device)
        saveSession(client, "EnableModBus", ModbusOrUDP);
    else
        saveSession(client, "EnableModBus", TCPORRTU);
    saveSession(client, "slaveID", slaveId);
    if (PMM6032Device)
    {
        saveSession(client, "holdinStartAddress", ReadHoldingRegStartAddress);
        saveSession(client, "holdingQuintity", ReadHoldingRegQuintity);
    }
    if (PMM0638Device)
    {
        saveSession(client, "holdinStartAddress", ReadHoldingRegStartAddress);
        saveSession(client, "holdingQuintity", WriteHoldingRegStartAddress);
    }
    else if (PMM0620Device)
    {
        saveSession(client, "readCoilStartAddress", ReadCoilsStartAddress);
        saveSession(client, "readCoilQuintity", ReadCoilsQuintity);
    }
    else if (PMM0625TDevice || PMM0626RDevice || PMM0627Device)
    {
        saveSession(client, "writeCoilStartAddress", WriteCoilsStartAddress);
        saveSession(client, "writeCoilQuintity", WriteCoilQuint);
    }

    saveSessionEnd(client);
}
/* Return IO Session */
void returnIOSession(EthernetClient client)
{
    saveSessionStart(client);
    if (PMM6032Device)
    {
        for (uint8_t i = 0; i < 8; i++)
        {
            String holder = "in" + String(i + 1) + "Check";
            saveSession(client, holder, String(!aiArray[i].canBeNegative));
            holder = "in" + String(i + 1) + "Factor";
            saveSession(client, holder, String(aiArray[i].factorValue));
            holder = "in" + String(i + 1) + "Offset";
            saveSession(client, holder, String(aiArray[i].offset));
            holder = "in" + String(i + 1) + "EQ";
            saveSession(client, holder, String(aiArray[i].equationType));
            holder = "in" + String(i + 1) + "FactorX";
            saveSession(client, holder, String(aiArray[i].FX));
            holder = "in" + String(i + 1) + "OffsetX";
            saveSession(client, holder, String(aiArray[i].OX));
        }
    }
    else if (PMM0638Device)
    {
        for (uint8_t i = 0; i < 4; i++)
        {
            String holder = "in" + String(i + 1) + "Check";
            saveSession(client, holder, String(aiArray[i].canBeNegative));
            holder = "in" + String(i + 1) + "Factor";
            saveSession(client, holder, String(aiArray[i].factorValue));
            holder = "in" + String(i + 1) + "Offset";
            saveSession(client, holder, String(aiArray[i].offset));
        }
        for (uint8_t i = 0; i < 4; i++)
        {
            String holder = "value" + String(i + 1);
            saveSession(client, holder, String(aoArray[i].floatToInt.valueAsFloat));
            holder = "currentVoltage" + String(i + 1);
            saveSession(client, holder, String(aoArray[i].isVoltage));
            holder = "force" + String(i + 1);
            saveSession(client, holder, String(aoArray[i].forced));
        }
    }
    else if (PMM0613Device)
    {
        for (uint8_t i = 0; i < 4; i++)
        {
            String holder = "pid" + String(i + 1) + "SetPoint";
            saveSession(client, holder, String(pidArray[i].setPoint));
            holder = "pid" + String(i + 1) + "Ki";
            saveSession(client, holder, String(pidArray[i].ki));
            holder = "pid" + String(i + 1) + "Kp";
            saveSession(client, holder, String(pidArray[i].kp));
            holder = "pid" + String(i + 1) + "Kd";
            saveSession(client, holder, String(pidArray[i].kd));
            holder = "minOutput" + String(i + 1);
            saveSession(client, holder, String(pidArray[i].minOutput));
            holder = "maxOutput" + String(i + 1);
            saveSession(client, holder, String(pidArray[i].maxOutput));
            // holder = "currentVoltage" + String(i + 1);
            // saveSession(client, holder, String(aoArray[i].isVoltage));
        }
    }
    else if (PMM0639Device)
    {
        for (uint8_t i = 0; i < 2; i++)
        {
            String holder = "in" + String(i + 1) + "Check";
            saveSession(client, holder, String(aiArray[i].canBeNegative));
            holder = "in" + String(i + 1) + "Factor";
            saveSession(client, holder, String(aiArray[i].factorValue));
            holder = "in" + String(i + 1) + "Offset";
            saveSession(client, holder, String(aiArray[i].offset));
        }
        for (uint8_t i = 0; i < 2; i++)
        {
            String holder = "value" + String(i + 1);
            saveSession(client, holder, String(aoArray[i].floatToInt.valueAsFloat));
            holder = "currentVoltage" + String(i + 1);
            saveSession(client, holder, String(aoArray[i].isVoltage));
            holder = "force" + String(i + 1);
            saveSession(client, holder, String(aoArray[i].forced));
        }
    }
    SerialUSB.println("Joghaimi");
    saveSessionEnd(client);
}

void saveSession(EthernetClient client, String sessionName, String items)
{
    /**
     * This Function used for Sendding the Saved item in
     * EEPROM to the Web page as Sesion
     * @param client
     * @param sessionName : session Name
     * @param items : session Data
     */
    client.print(F("sessionStorage.setItem('"));
    client.print(sessionName);
    client.print(F("','"));
    client.print(items);
    client.print(F("');"));
}
void saveSessionStart(EthernetClient client)
{
    /**
     * This Function used for Sendding the Start of saving session
     * to the Web page as Sesion
     * @param client
     */
    client.println(F("<!DOCTYPE HTML>"));
    client.println(F("<html>"));
    client.print(F("<head><script>"));
}
void saveSessionEnd(EthernetClient client)
{
    /**
     * This Function used for Sendding the end of saving session
     * to the Web page as Sesion
     * @param client
     */
    client.println(F("</script></head>"));
    client.println(F("</html>"));
}