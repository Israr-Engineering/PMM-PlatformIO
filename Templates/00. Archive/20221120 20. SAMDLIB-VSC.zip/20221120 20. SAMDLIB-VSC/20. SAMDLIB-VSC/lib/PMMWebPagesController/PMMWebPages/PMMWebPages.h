#ifndef PMMWebPages
#define PMMWebPages
#include <Arduino.h>
#include <Ethernet.h>
#include <PMMEEPROMGeneralFunction/PMMEEPROMGeneralFunction.h>
void printHeaderTag(EthernetClient client);
void printLeftSideBar(EthernetClient client, String titel);
void stringToWebPages(const String webPage, EthernetClient client);
void getAboutPage(EthernetClient client);
void getDOAboutPage(EthernetClient client);
void getDIAboutPage(EthernetClient client);
void modBusDOConfig(EthernetClient client);
void modBusDIConfig(EthernetClient client);
void getDiMonitorPage(EthernetClient client);
void getDoMonitorPage(EthernetClient client);
void getNetworkPage(EthernetClient client);
void getMaintinusPage(EthernetClient client);
void getSerialPageHead(EthernetClient client);
void getSerialPage(EthernetClient client);
void getLoginPage(EthernetClient client);
void getNotFoundPage(EthernetClient client);
void printOldSideBar(EthernetClient client, String titel);
void printFotterTag(EthernetClient client);
void modbusConfig(EthernetClient client);
void IOPage(EthernetClient client);
void printTag(EthernetClient client, String name, String url);
void printEndOfBody(EthernetClient client);
extern String ModelName;
extern String FirmwareVersion;
extern bool PMM0501Device;
extern bool PMM0501DeviceOnePort;
extern bool PMM0406Device;
extern bool PMM1003Device;
extern bool PMM1002Device;
extern bool PMM6032Device;
extern bool PMM0620Device;
extern bool PMM0625TDevice;
extern bool PMM0638Device;
extern bool PMM0639Device;
extern bool PMM0626RDevice;
extern bool PMM0627Device;
extern bool PMM0612Device;
extern bool PMM0613Device;

#endif