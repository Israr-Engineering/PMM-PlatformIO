#include <PMMWebEEPROM/PMMWebEEPROM.h>

/**
 * @brief saveJsonToEEPROM handling the save Request in webserver and update the value
 * @param client
 * @param json
 */
void saveJsonToEEPROM(EthernetClient client, String json)
{
    // ** Prepare Json Object
    json = removeHeaderForJson(json);
    DynamicJsonDocument doc(2048);
    deserializeJson(doc, json);
    JsonObject obj = doc.as<JsonObject>();
    if (obj.containsKey("network"))
    {
        // Set New Network Info
        controllerIPAddress = obj["network"]["idAddress"].as<String>();
        subNetMask = obj["network"]["netMask"].as<String>();
        GatWay = obj["network"]["gateWay"].as<String>();
        remoteIPAddress = obj["network"]["remoteIPAddress"].as<String>();
        UDPPort = obj["network"]["UDPPort1"].as<String>();
        UDPPort2 = obj["network"]["UDPPort2"].as<String>();
        UDPPort3 = obj["network"]["UDPPort3"].as<String>();
        UDPPort4 = obj["network"]["UDPPort4"].as<String>();
        if (PMM1002Device || PMM1003Device)
        {
            selOperation = obj["network"]["operation"].as<String>();
            Debugprint("SEL Operation");
            Debugprintln(selOperation);
        }
        Debugprint("the New Network IPAddress: ");
        Debugprintln(controllerIPAddress);
        Debugprint("the New Network netMask: ");
        Debugprintln(subNetMask);
        Debugprint("the New Network gateWay: ");
        Debugprintln(GatWay);
        Debugprint("the New Network remoteIPAddress: ");
        Debugprintln(remoteIPAddress);
        Debugprint("the New Network UDP Port: ");
        Debugprintln(UDPPort);
        Debugprintln(UDPPort2);
        Debugprintln(UDPPort2);
        Debugprintln(UDPPort4);
        setDefaultUDPSetting();
    }
    else if (obj.containsKey("Password"))
    {
    }
    else if (obj.containsKey("serialParameter"))
    {
        if (obj["serialParameter"].containsKey("P1"))
        {
            portOne.baudRate = obj["serialParameter"]["P1"]["BaudRate"].as<String>();
            portOne.dataBit = obj["serialParameter"]["P1"]["DataBit"].as<String>();
            portOne.stopBit = obj["serialParameter"]["P1"]["StopBit"].as<String>();
            portOne.parity = obj["serialParameter"]["P1"]["parity"].as<String>();
            portOne.interface = obj["serialParameter"]["P1"]["Interface"].as<String>();
            Debugprintln("Serial Settings Port 1 ");
            Debugprintln(portOne.baudRate);
            Debugprintln(portOne.dataBit);
            Debugprintln(portOne.stopBit);
            Debugprintln(portOne.parity);
            Debugprintln(portOne.interface);
        }
        if (obj["serialParameter"].containsKey("P2"))
        {
            portTwo.baudRate = obj["serialParameter"]["P2"]["BaudRate"].as<String>();
            portTwo.dataBit = obj["serialParameter"]["P2"]["DataBit"].as<String>();
            portTwo.stopBit = obj["serialParameter"]["P2"]["StopBit"].as<String>();
            portTwo.parity = obj["serialParameter"]["P2"]["parity"].as<String>();
            portTwo.interface = obj["serialParameter"]["P2"]["Interface"].as<String>();
            Debugprintln("Serial Settings Port 2");
            Debugprintln(portTwo.baudRate);
            Debugprintln(portTwo.dataBit);
            Debugprintln(portTwo.stopBit);
            Debugprintln(portTwo.parity);
            Debugprintln(portTwo.interface);
        }
        if (obj["serialParameter"].containsKey("P3"))
        {
            portThree.baudRate = obj["serialParameter"]["P3"]["BaudRate"].as<String>();
            portThree.dataBit = obj["serialParameter"]["P3"]["DataBit"].as<String>();
            portThree.stopBit = obj["serialParameter"]["P3"]["StopBit"].as<String>();
            portThree.parity = obj["serialParameter"]["P3"]["parity"].as<String>();
            portThree.interface = obj["serialParameter"]["P3"]["Interface"].as<String>();
            Debugprintln("Serial Settings Port 3");
            Debugprintln(portThree.baudRate);
            Debugprintln(portThree.dataBit);
            Debugprintln(portThree.stopBit);
            Debugprintln(portThree.parity);
            Debugprintln(portThree.interface);
        }
        if (obj["serialParameter"].containsKey("P4"))
        {
            portFour.baudRate = obj["serialParameter"]["P4"]["BaudRate"].as<String>();
            portFour.dataBit = obj["serialParameter"]["P4"]["DataBit"].as<String>();
            portFour.stopBit = obj["serialParameter"]["P4"]["StopBit"].as<String>();
            portFour.parity = obj["serialParameter"]["P4"]["parity"].as<String>();
            portFour.interface = obj["serialParameter"]["P4"]["Interface"].as<String>();
            Debugprintln("Serial Settings Port 4");
            Debugprintln(portFour.baudRate);
            Debugprintln(portFour.dataBit);
            Debugprintln(portFour.stopBit);
            Debugprintln(portFour.parity);
            Debugprintln(portFour.interface);
        }
        setDefaultSerialMode();
    }
    else if (!obj.getMember("ModbusSetting").isNull())
    {
        if (PMM0501Device || PMM0406Device)
        {
            if (PMM0501Device)
                Debugprintln("Modbus settings For 0501");
            else
                Debugprintln("Modbus settings For 0406");
            ModbusOrUDP = obj["ModbusSetting"]["EnableModBus"].as<String>();
        }
        else if (PMM6032Device)
        {
            Debugprintln("Modbus settings For 0632");
            ModbusOrUDP = obj["ModbusSetting"]["EnableModBus"].as<String>();
            TCPORRTU = obj["ModbusSetting"]["EnableModBus"].as<String>();
            slaveId = obj["ModbusSetting"]["slaveID"].as<String>();
            ReadHoldingRegStartAddress = obj["ModbusSetting"]["ReadHoldingStartAdd"].as<String>();
            ReadHoldingRegQuintity = obj["ModbusSetting"]["ReadHoldingQuin"].as<String>();
        }
        else if (PMM0638Device)
        {
            Debugprintln("Modbus settings For 0638");
            ModbusOrUDP = obj["ModbusSetting"]["EnableModBus"].as<String>();
            TCPORRTU = obj["ModbusSetting"]["EnableModBus"].as<String>();
            slaveId = obj["ModbusSetting"]["slaveID"].as<String>();
            ReadHoldingRegStartAddress = obj["ModbusSetting"]["ReadHoldingStartAdd"].as<String>();
            WriteHoldingRegStartAddress = obj["ModbusSetting"]["ReadHoldingQuin"].as<String>();
        }
        else if (PMM0620Device)
        {
            Debugprintln("Modbus settings For 0625");
            ModbusOrUDP = obj["ModbusSetting"]["EnableModBus"].as<String>();
            TCPORRTU = obj["ModbusSetting"]["EnableModBus"].as<String>();
            slaveId = obj["ModbusSetting"]["slaveID"].as<String>();
            ReadCoilsStartAddress = obj["ModbusSetting"]["ReadCoilStartAdd"].as<String>();
            ReadCoilsQuintity = obj["ModbusSetting"]["ReadCoilQuin"].as<String>();
        }
        else if (PMM0625TDevice || PMM0626RDevice || PMM0627Device)
        {
            Debugprintln("Modbus settings For 0625T");
            ModbusOrUDP = obj["ModbusSetting"]["EnableModBus"].as<String>();
            TCPORRTU = obj["ModbusSetting"]["EnableModBus"].as<String>();
            slaveId = obj["ModbusSetting"]["slaveID"].as<String>();
            WriteCoilsStartAddress = obj["ModbusSetting"]["writeCoilStartAdd"].as<String>();
            WriteCoilsQuintity = obj["ModbusSetting"]["writeCoilQuin"].as<String>();
        }
        PMMSetModbusSeting();
    }
    else if (!obj.getMember("IOSettings").isNull())
    {
        if (PMM6032Device)
        {

            aiArray[0].canBeNegative = obj["IOSettings"]["inputOne"]["check"].as<String>() == "true" ? false : true;
            aiArray[0].factorValue = obj["IOSettings"]["inputOne"]["factor"].as<String>().toFloat();
            aiArray[0].offset = obj["IOSettings"]["inputOne"]["offset"].as<String>().toFloat();
            aiArray[0].equationType = obj["IOSettings"]["inputOne"]["inEq"].as<String>() == "0" ? false : true;

            aiArray[0].FX = obj["IOSettings"]["inputOne"]["inFx"].as<String>().toInt();
            aiArray[0].OX = obj["IOSettings"]["inputOne"]["inOfX"].as<String>().toInt();

            aiArray[1].canBeNegative = obj["IOSettings"]["inputTwo"]["check"].as<String>() == "true" ? false : true;
            aiArray[1].factorValue = obj["IOSettings"]["inputTwo"]["factor"].as<String>().toFloat();
            aiArray[1].offset = obj["IOSettings"]["inputTwo"]["offset"].as<String>().toFloat();
            aiArray[1].equationType = obj["IOSettings"]["inputTwo"]["inEq"].as<String>() == "0" ? false : true;
            aiArray[1].FX = obj["IOSettings"]["inputTwo"]["inFx"].as<String>().toInt();
            aiArray[1].OX = obj["IOSettings"]["inputTwo"]["inOfX"].as<String>().toInt();

            aiArray[2].canBeNegative = obj["IOSettings"]["inputThree"]["check"].as<String>() == "true" ? false : true;
            aiArray[2].factorValue = obj["IOSettings"]["inputThree"]["factor"].as<String>().toFloat();
            aiArray[2].offset = obj["IOSettings"]["inputThree"]["offset"].as<String>().toFloat();
            aiArray[2].equationType = obj["IOSettings"]["inputThree"]["inEq"].as<String>() == "0" ? false : true;
            aiArray[2].FX = obj["IOSettings"]["inputThree"]["inFx"].as<String>().toInt();
            aiArray[2].OX = obj["IOSettings"]["inputThree"]["inOfX"].as<String>().toInt();

            aiArray[3].canBeNegative = obj["IOSettings"]["inputFour"]["check"].as<String>() == "true" ? false : true;
            aiArray[3].factorValue = obj["IOSettings"]["inputFour"]["factor"].as<String>().toFloat();
            aiArray[3].offset = obj["IOSettings"]["inputFour"]["offset"].as<String>().toFloat();
            aiArray[3].equationType = obj["IOSettings"]["inputFour"]["inEq"].as<String>() == "0" ? false : true;
            aiArray[3].FX = obj["IOSettings"]["inputFour"]["inFx"].as<String>().toInt();
            aiArray[3].OX = obj["IOSettings"]["inputFour"]["inOfX"].as<String>().toInt();

            aiArray[4].canBeNegative = obj["IOSettings"]["inputFive"]["check"].as<String>() == "true" ? false : true;
            aiArray[4].factorValue = obj["IOSettings"]["inputFive"]["factor"].as<String>().toFloat();
            aiArray[4].offset = obj["IOSettings"]["inputFive"]["offset"].as<String>().toFloat();
            aiArray[4].equationType = obj["IOSettings"]["inputFive"]["inEq"].as<String>() == "0" ? false : true;
            aiArray[4].FX = obj["IOSettings"]["inputFive"]["inFx"].as<String>().toInt();
            aiArray[4].OX = obj["IOSettings"]["inputFive"]["inOfX"].as<String>().toInt();

            aiArray[5].canBeNegative = obj["IOSettings"]["inputSix"]["check"].as<String>() == "true" ? false : true;
            aiArray[5].factorValue = obj["IOSettings"]["inputSix"]["factor"].as<String>().toFloat();
            aiArray[5].offset = obj["IOSettings"]["inputSix"]["offset"].as<String>().toFloat();
            aiArray[5].equationType = obj["IOSettings"]["inputSix"]["inEq"].as<String>() == "0" ? false : true;
            aiArray[5].FX = obj["IOSettings"]["inputSix"]["inFx"].as<String>().toInt();
            aiArray[5].OX = obj["IOSettings"]["inputSix"]["inOfX"].as<String>().toInt();

            aiArray[6].canBeNegative = obj["IOSettings"]["inputSeven"]["check"].as<String>() == "true" ? false : true;
            aiArray[6].factorValue = obj["IOSettings"]["inputSeven"]["factor"].as<String>().toFloat();
            aiArray[6].offset = obj["IOSettings"]["inputSeven"]["offset"].as<String>().toFloat();
            aiArray[6].equationType = obj["IOSettings"]["inputSeven"]["inEq"].as<String>() == "0" ? false : true;
            aiArray[6].FX = obj["IOSettings"]["inputSix"]["inFx"].as<String>().toInt();
            aiArray[6].OX = obj["IOSettings"]["inputSix"]["inOfX"].as<String>().toInt();

            aiArray[7].canBeNegative = obj["IOSettings"]["inputeight"]["check"].as<String>() == "true" ? false : true;
            aiArray[7].factorValue = obj["IOSettings"]["inputeight"]["factor"].as<String>().toFloat();
            aiArray[7].offset = obj["IOSettings"]["inputeight"]["offset"].as<String>().toFloat();
            aiArray[7].equationType = obj["IOSettings"]["inputeight"]["inEq"].as<String>() == "0" ? false : true;
            aiArray[7].FX = obj["IOSettings"]["inputSix"]["inFx"].as<String>().toInt();
            aiArray[7].OX = obj["IOSettings"]["inputSix"]["inOfX"].as<String>().toInt();

            // Save Setting to EEPROM
            setAiInfo();
        }
        else if (PMM0638Device)
        {

            aiArray[0].canBeNegative = obj["IOSettings"]["inputOne"]["check"].as<String>() == "true" ? false : true;
            aiArray[0].factorValue = obj["IOSettings"]["inputOne"]["factor"].as<String>().toFloat();
            aiArray[0].offset = obj["IOSettings"]["inputOne"]["offset"].as<String>().toFloat();
            aiArray[1].canBeNegative = obj["IOSettings"]["inputTwo"]["check"].as<String>() == "true" ? false : true;
            aiArray[1].factorValue = obj["IOSettings"]["inputTwo"]["factor"].as<String>().toFloat();
            aiArray[1].offset = obj["IOSettings"]["inputTwo"]["offset"].as<String>().toFloat();
            aiArray[2].canBeNegative = obj["IOSettings"]["inputThree"]["check"].as<String>() == "true" ? false : true;
            aiArray[2].factorValue = obj["IOSettings"]["inputThree"]["factor"].as<String>().toFloat();
            aiArray[2].offset = obj["IOSettings"]["inputThree"]["offset"].as<String>().toFloat();
            aiArray[3].canBeNegative = obj["IOSettings"]["inputFour"]["check"].as<String>() == "true" ? false : true;
            aiArray[3].factorValue = obj["IOSettings"]["inputFour"]["factor"].as<String>().toFloat();
            aiArray[3].offset = obj["IOSettings"]["inputFour"]["offset"].as<String>().toFloat();

            aoArray[0].isVoltage = obj["IOSettings"]["output1"]["currentVoltage"].as<String>() == "0" ? false : true;
            aoArray[0].forced = obj["IOSettings"]["output1"]["force"].as<String>() == "0" ? false : true;
            aoArray[0].floatToInt.valueAsFloat = obj["IOSettings"]["output1"]["value"].as<String>().toFloat();
            aoArray[0].valueOnADC = mapfloat(aoArray[0].floatToInt.valueAsFloat, 0, 11, 0, 8191);

            aoArray[1].isVoltage = obj["IOSettings"]["output2"]["currentVoltage"].as<String>() == "0" ? false : true;
            aoArray[1].forced = obj["IOSettings"]["output2"]["force"].as<String>() == "0" ? false : true;
            aoArray[1].floatToInt.valueAsFloat = obj["IOSettings"]["output2"]["value"].as<String>().toFloat();
            aoArray[1].valueOnADC = mapfloat(aoArray[1].floatToInt.valueAsFloat, 0, 11, 0, 8191);

            aoArray[2].isVoltage = obj["IOSettings"]["output3"]["currentVoltage"].as<String>() == "0" ? false : true;
            aoArray[2].forced = obj["IOSettings"]["output3"]["force"].as<String>() == "0" ? false : true;
            aoArray[2].floatToInt.valueAsFloat = obj["IOSettings"]["output3"]["value"].as<String>().toFloat();
            aoArray[2].valueOnADC = mapfloat(aoArray[2].floatToInt.valueAsFloat, 0, 11, 0, 8191);

            aoArray[3].isVoltage = obj["IOSettings"]["output4"]["currentVoltage"].as<String>() == "0" ? false : true;
            aoArray[3].forced = obj["IOSettings"]["output4"]["force"].as<String>() == "0" ? false : true;
            aoArray[3].floatToInt.valueAsFloat = obj["IOSettings"]["output4"]["value"].as<String>().toFloat();
            aoArray[3].valueOnADC = mapfloat(aoArray[3].floatToInt.valueAsFloat, 0, 11, 0, 8191);
            setAiInfo();
            setAOInfo();
        }
        else if (PMM0639Device)
        {

            aiArray[0].canBeNegative = obj["IOSettings"]["inputOne"]["check"].as<String>() == "true" ? false : true;
            aiArray[0].factorValue = obj["IOSettings"]["inputOne"]["factor"].as<String>().toFloat();
            aiArray[0].offset = obj["IOSettings"]["inputOne"]["offset"].as<String>().toFloat();
            aiArray[1].canBeNegative = obj["IOSettings"]["inputTwo"]["check"].as<String>() == "true" ? false : true;
            aiArray[1].factorValue = obj["IOSettings"]["inputTwo"]["factor"].as<String>().toFloat();
            aiArray[1].offset = obj["IOSettings"]["inputTwo"]["offset"].as<String>().toFloat();

            aoArray[0].isVoltage = obj["IOSet   tings"]["output1"]["currentVoltage"].as<String>() == "0" ? false : true;
            aoArray[0].forced = obj["IOSettings"]["output1"]["force"].as<String>() == "0" ? false : true;
            aoArray[0].floatToInt.valueAsFloat = obj["IOSettings"]["output1"]["value"].as<String>().toFloat();
            aoArray[0].valueOnADC = mapfloat(aoArray[0].floatToInt.valueAsFloat, 0, 11, 0, 8191);

            aoArray[1].isVoltage = obj["IOSettings"]["output2"]["currentVoltage"].as<String>() == "0" ? false : true;
            aoArray[1].forced = obj["IOSettings"]["output2"]["force"].as<String>() == "0" ? false : true;
            aoArray[1].floatToInt.valueAsFloat = obj["IOSettings"]["output2"]["value"].as<String>().toFloat();
            aoArray[1].valueOnADC = mapfloat(aoArray[1].floatToInt.valueAsFloat, 0, 11, 0, 8191);

            PMMInputCoilModbus.forcedArray[0] = obj["IOSettings"]["IO1"]["IOForce"];
            PMMInputCoilModbus.forcedValue[0] = obj["IOSettings"]["IO1"]["IOForceValue"];

            PMMInputCoilModbus.forcedArray[1] = obj["IOSettings"]["IO2"]["IOForce"];
            PMMInputCoilModbus.forcedValue[1] = obj["IOSettings"]["IO2"]["IOForceValue"];

            PMMOutputCoilModbus.forcedArray[0] = obj["IOSettings"]["IO3"]["IOForce"];
            PMMOutputCoilModbus.forcedValue[0] = obj["IOSettings"]["IO3"]["IOForceValue"];

            PMMOutputCoilModbus.forcedArray[1] = obj["IOSettings"]["IO4"]["IOForce"];
            PMMOutputCoilModbus.forcedValue[1] = obj["IOSettings"]["IO4"]["IOForceValue"];
            setAiInfo();
            setAOInfo();
        }
        else if (PMM0613Device)
        {
            pidArray[0].setPoint = obj["IOSettings"]["PIDOne"]["pidSetPoint"].as<String>().toDouble();
            pidArray[0].kp = obj["IOSettings"]["PIDOne"]["pidKi"].as<String>().toDouble();
            pidArray[0].ki = obj["IOSettings"]["PIDOne"]["pidKp"].as<String>().toDouble();
            pidArray[0].kd = obj["IOSettings"]["PIDOne"]["pidKd"].as<String>().toDouble();
            pidArray[0].minOutput = obj["IOSettings"]["PIDOne"]["minOutput"].as<String>().toDouble();
            pidArray[0].maxOutput = obj["IOSettings"]["PIDOne"]["maxOutput"].as<String>().toDouble();
            aoArray[0].isVoltage = obj["IOSettings"]["PIDOne"]["currentVoltage"].as<String>() == "0" ? false : true;

            pidArray[1].setPoint = obj["IOSettings"]["PIDTwo"]["pidSetPoint"].as<String>().toDouble();
            pidArray[1].kp = obj["IOSettings"]["PIDTwo"]["pidKi"].as<String>().toDouble();
            pidArray[1].ki = obj["IOSettings"]["PIDTwo"]["pidKp"].as<String>().toDouble();
            pidArray[1].kd = obj["IOSettings"]["PIDTwo"]["pidKd"].as<String>().toDouble();
            pidArray[1].minOutput = obj["IOSettings"]["PIDTwo"]["minOutput"].as<String>().toDouble();
            pidArray[1].maxOutput = obj["IOSettings"]["PIDTwo"]["maxOutput"].as<String>().toDouble();
            aoArray[1].isVoltage = obj["IOSettings"]["PIDTwo"]["currentVoltage"].as<String>() == "0" ? false : true;

            pidArray[2].setPoint = obj["IOSettings"]["PIDThree"]["pidSetPoint"].as<String>().toDouble();
            pidArray[2].kp = obj["IOSettings"]["PIDThree"]["pidKi"].as<String>().toDouble();
            pidArray[2].ki = obj["IOSettings"]["PIDThree"]["pidKp"].as<String>().toDouble();
            pidArray[2].kd = obj["IOSettings"]["PIDThree"]["pidKd"].as<String>().toDouble();
            pidArray[2].minOutput = obj["IOSettings"]["PIDThree"]["minOutput"].as<String>().toDouble();
            pidArray[2].maxOutput = obj["IOSettings"]["PIDThree"]["maxOutput"].as<String>().toDouble();
            aoArray[2].isVoltage = obj["IOSettings"]["PIDThree"]["currentVoltage"].as<String>() == "0" ? false : true;

            pidArray[3].setPoint = obj["IOSettings"]["PIDFour"]["pidSetPoint"].as<String>().toDouble();
            pidArray[3].kp = obj["IOSettings"]["PIDFour"]["pidKi"].as<String>().toDouble();
            pidArray[3].ki = obj["IOSettings"]["PIDFour"]["pidKp"].as<String>().toDouble();
            pidArray[3].kd = obj["IOSettings"]["PIDFour"]["pidKd"].as<String>().toDouble();
            pidArray[3].minOutput = obj["IOSettings"]["PIDFour"]["minOutput"].as<String>().toDouble();
            pidArray[3].maxOutput = obj["IOSettings"]["PIDFour"]["maxOutput"].as<String>().toDouble();
            aoArray[3].isVoltage = obj["IOSettings"]["PIDFour"]["currentVoltage"].as<String>() == "0" ? false : true;

            setAOInfo();
            PMMSetPidInfo();
        }
    }
}
String removeHeaderForJson(String value)
{
    int startFrom = value.indexOf('{');
    value = value.substring(startFrom);
    value.trim();
    return value;
}
float mapfloat(float x, long in_min, long in_max, long out_min, long out_max)
{
    return (float)(x - in_min) * (out_max - out_min) / (float)(in_max - in_min) + out_min;
}