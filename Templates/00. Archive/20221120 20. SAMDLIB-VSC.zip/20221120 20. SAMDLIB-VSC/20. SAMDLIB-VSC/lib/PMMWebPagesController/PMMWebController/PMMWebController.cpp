#include <PMMWebController/PMMWebController.h>
// Decleare This Variable on the Hedaer Will Give Error -> multiple definitions of a variable
EthernetServer server(80);
EthernetClient client;
String HTTP_req;
String SavedEmail = "admin@israr.com";
String requestBody = "";
String AjaxArray[10];
String AjaxResponse;
bool PMMisSignIn = false;
void PMMInitWebServer()
{
    server = EthernetServer(80);
    server.begin();
}
void PMMWebCommunication()
{
    /**
     * This Function for WebServer Communication --> All magic done here
     */

    client = server.available();
   
    if (client)
    {
        boolean currentLineIsBlank = true;
        while (client.connected())
        {
            if (client.available())
            {
                char c = client.read();
                if (HTTP_req.length() < 120)
                {
                    HTTP_req += c;
                }
                if (c == '\n' && currentLineIsBlank)
                {
                    while (client.available())
                    {
                        requestBody.concat((char)client.read());
                    }
                    route(HTTP_req, client, requestBody);
                    HTTP_req = "";
                    requestBody = "";
                    break;
                }
            }
            else
            {
                break;
            }
        }
        client.stop();
    }
}
// Page navigation
void route(String HTTP_req, EthernetClient client, String requestBody = "")
{
    /**
     * route : This function navigate the user to its destination
     *
     */
    bool isItSaveRequest = HTTP_req.indexOf("POST") >= 0;
    if ((HTTP_req.indexOf("login") >= 0 && !isItSaveRequest))
        PMMLoginPage();
    // Pages
    else if (HTTP_req.indexOf("about.html") >= 0 && (isSingInFn(client)))
        PMMaboutPage();
    else if (HTTP_req.indexOf("Network.html") >= 0 && !isItSaveRequest && (isSingInFn(client)))
        PMMNetworkPage();
    else if (HTTP_req.indexOf("Serial.html") >= 0 && !isItSaveRequest && (isSingInFn(client)))
        PMMSerialPage();
    else if (HTTP_req.indexOf("IO.html") >= 0 && !isItSaveRequest && (isSingInFn(client)))
        PMMIOControl();
    else if (HTTP_req.indexOf("ModbusSetting.html") >= 0 && !isItSaveRequest && (isSingInFn(client)))
        PMMModbusSetting();
    else if (HTTP_req.indexOf("Maintenance.html") >= 0 || HTTP_req.indexOf("maintenance.html") >= 0 && !isItSaveRequest && (isSingInFn(client)))
        PMMMaintenance();
    // internal Function
    else if (isItSaveRequest && HTTP_req.indexOf("save") >= 0)
        PMMSaveSettings(client);
    else if (HTTP_req.indexOf("restart") >= 0 && !isItSaveRequest)
        PMMRestartPage();
    else if (HTTP_req.indexOf("Authintication") >= 0)
    {
        returnOKHeader(client);
        signInMethod(requestBody, client);
    }
    // else if (HTTP_req.indexOf("Ajax") >= 0)
    // {
    //     PMMAjaxRequest();
    // }
    // read Ajax requist
    else if (HTTP_req.indexOf("setIORequist") >= 0)
    {
        PMMSetAjaxResponse(client, requestBody);
    }
    else if (HTTP_req.indexOf("AjaxRequist") >= 0)
    {
        PMMAjaxResponse(client);
        // returnOKHeader(client);
        // int startAddress = HTTP_req.indexOf("AjaxRequist") + 12;
        // int HttpStartAddress = HTTP_req.indexOf("HTTP");
        // // int quintity = startAddress - HttpStartAddress;
        // String ajaxRequestValue = HTTP_req.substring(HttpStartAddress, startAddress);

        // AjaxReqFun(client, ajaxRequestValue);
    }

    else if (HTTP_req.indexOf("logOut") >= 0 && !isItSaveRequest)
    {
        PMMisSignIn = false;
        navigateTo("../login", client);
    }
    else
    {
        returnOKHeader(client);
        navigateTo("../login", client);
    }
}
// Pages Function
/**
 * These Function Used Contains the Webpages
 * The Fourm of webpage is
 *  - ReturnOkHeader
 *  - Session Return
 *  - WebPages
 */
void PMMaboutPage()
{

    returnOKHeader(client);
    returnAboutSession(client);
    getAboutPage(client);
}
void PMMNetworkPage()
{
    returnOKHeader(client);
    getNetworkPage(client);
}
void PMMSerialPage()
{
    returnOKHeader(client);
    returnSerialParameterSession(client);
    getSerialPage(client);
}
void PMMModbusSetting()
{

    returnOKHeader(client);
    returnModBusConfigSession(client);
    modbusConfig(client);
    // else if (modBusSlaveDO)
    // {
    //     returnModBusDOConfigSession(client);
    //     modBusDOConfig(client);
    // }
    // else if (modBusSlaveDI)
    // {
    //     returnModBusDOConfigSession(client);
    //     modBusDIConfig(client);
    // }
    // else
    // {
    //     returnModBusConfigSession(client);
    //     // modBusConfig(client);
    // }
}
void PMMMaintenance()
{
    returnOKHeader(client);
    getMaintinusPage(client);
}
void PMMIOControl()
{
    returnOKHeader(client);
    returnIOSession(client);
    IOPage(client);
}

void PMMDigitalInput()
{
    returnOKHeader(client);

    // if (modBusSlaveDI)
    // {
    //     returnDIMonitorSession(client);
    //     getDiMonitorPage(client);
    // }
    // else if (modBusSlaveDO)
    // {
    //     returnDIMonitorSession(client);
    //     getDoMonitorPage(client);
    // }
}
void PMMLoginPage()
{
    if (!PMMisSignIn)
    {
        returnOKHeader(client);
        getLoginPage(client);
        Debugprintln("in login Page");
    }
    else
    {
        navigateTo("about.html", client);
    }
}
void PMMRestartPage()
{
    returnOKHeader(client);
    navigateTo("../login", client);
    restetController(client);
}
// Internal Functions
void returnOKHeader(EthernetClient client)
{
    /**
     * @brief Call this Function Before Any Page
     */
    client.println(F("HTTP/1.1 200 OK"));
    client.println(F("Access-Control-Allow-Origin: *"));
    client.println(F("Content-Type: text/html"));
    client.println();
    client.println();
}
String returnPostData(String requestBody, String ParamName)
{
    /**
     * @brief get Data From Post Reguest
     */
    int startIndex = 0;
    String requestParam = "";
    requestBody = requestBody.substring(requestBody.indexOf("Content-Type"));
    startIndex = (requestBody.indexOf(ParamName)) + ParamName.length();
    requestParam = requestBody.substring(startIndex + 1, (-2));
    requestParam.trim();
    requestParam = requestParam.substring(0, 25);
    requestParam.replace("-", "");
    requestBody = "";
    return requestParam;
}
void navigateTo(String path, EthernetClient client)
{
    /**
     * @brief Use This Function to navigate between Functions
     *
     */
    returnOKHeader(client);
    client.println(F("<!DOCTYPE HTML>"));
    client.println(F("<html>"));
    client.print(F("<head><script>window.location.href = '"));
    client.print(path);
    client.println(F("';</script></head>"));
    client.println(F("</html>"));
}
// Autintication
void signInMethod(String requestBody, EthernetClient client)
{
    /***
     * signInMethod : Check the email & password for the user
     * and allow him to access the website
     * @param requestBody
     * @param client
     */
    // Remove the Extra Header Data

    requestBody = PMMRemoveHeaderTag(requestBody);
    String Passwoed = "";
    String email = "";
    splitString(requestBody, email, requestBody);
    splitString(requestBody, Passwoed, requestBody);
    Passwoed.trim();
    email.trim();

    // String Passwoed = (returnPostData(requestBody, "password"));
    // String email = returnPostData(requestBody, "Email");
    // email.replace("%40", "@");
    // email.replace("&passwor", "");
    // Passwoed.trim();
    // email.trim();

    if (Passwoed == password && email == SavedEmail)
    {
        PMMisSignIn = true;
        Debugprintln("Access");
        AjaxResponse = "Access";
        navigateTo("about.html", client);
    }
    else
    {
        AjaxResponse = "Access Denaied";
        Debugprintln("Sign in Access Denaied");
    }
    Debugprint(String(PMMisSignIn));
}
bool isSingInFn(EthernetClient client)
{
    /***
     * isSingInFn : check if the user is signed up
     * @return Boolean for the state of user
     *
     */
    if (!PMMisSignIn)
    {
        navigateTo("../login", client);
    }
    return PMMisSignIn;
}
// General Function
void restetController(EthernetClient client)
{
    /***
     * restetController : This Function used for ressiting the Controller
     * @param client
     */
    PMMisSignIn = false;
    delay(1000);
    NVIC_SystemReset();
    digitalWrite(25, LOW);
}
void PMMSaveSettings(EthernetClient client)
{
    returnOKHeader(client);
    saveJsonToEEPROM(client, requestBody);
}

void PMMAjaxRequest()
{
    client.print(AjaxResponse);
    Debugprintln(AjaxResponse);
}
String PMMRemoveHeaderTag(String Request)
{

    // Remove Extra info From Request Hader
    Request = Request.substring(Request.indexOf("PMMSaveRequest") + 14);
    return Request;
}