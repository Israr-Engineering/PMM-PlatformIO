#ifndef PMMWebController
#define PMMWebController
#include <Arduino.h>
#include <SPI.h>
#include <Ethernet.h>
#include <ArduinoJson.h>
#include <PMMSession/PMMSession.h>
#include <PMMWebPages/PMMWebPages.h>
#include <PMMWebEEPROM/PMMWebEEPROM.h>
#include <PMMEEPROMGeneralFunction/PMMEEPROMGeneralFunction.h>
#include <projectConfigration.h>
#include <PMMIOAjax/PMMIOAjax.h>
#include <PMMUDPBridge/PMMUDPBridge.h>
#include <PMMTCPServer/PMMTCPServer.h>
// #include <../PMM>
// #include <AjaxRequist.h>
// #include <DigitalIO.h>
// #include <PMMGlobalFunction.h>
extern uint8_t resetButton;
extern uint8_t EthernetCS;
extern byte mac[6];
extern byte controllerMacAddress[6];
extern String password;
extern bool PMM0501Device;
void PMMWebCommunication();
void PMMInitWebServer();
void PMMaboutPage();
void PMMNetworkPage();
void PMMSerialPage();
void PMMModbusSetting();
void PMMMaintenance();
void PMMDigitalInput();
void PMMLoginPage();
void PMMRestartPage();
void PMMIOControl();
void returnOKHeader(EthernetClient client);
String returnPostData(String requestBody, String ParamName);
void navigateTo(String path, EthernetClient client);
void stringToWebPage(String webPage, EthernetClient client);
void signInMethod(String requestBody, EthernetClient client);
void route(String HTTP_req, EthernetClient client, String requestBody);
void checkConnection();
bool isSingInFn(EthernetClient client);
void restetController(EthernetClient client);
bool canAccess(IPAddress ipAddress);
void PMMSaveSettings(EthernetClient client);
void PMMAjaxRequest();
String PMMRemoveHeaderTag(String Request);
#endif