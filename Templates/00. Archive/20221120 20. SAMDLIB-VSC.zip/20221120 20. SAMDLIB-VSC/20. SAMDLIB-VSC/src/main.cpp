#include <Arduino.h>
#include <WDTZero.h>
#include <ArduinoJson.h>
#include <SPI.h>
#include <Wire.h>
#include <LoRa.h>

#include <ArduinoRS485.h>
#include <ArduinoModbus.h>
#include <PMMWebController/PMMWebController.h>
#include <PMMModbusGateWay/PMMModbusGateWay.h>
#include <projectInitalization.h>
#include <PMMIOLib/PMMIOLib.h>
#include <PMM1003DeviceLib/PMM1003DeviceLib.h>
#include <PMM1002DeviceLib/PMM1002DeviceLib.h>
#include <PMM0638DeviceLib/PMM0638DeviceLib.h>
#include <PMM0625TDeviceLib/PMM0625TDeviceLib.h>
#include <projectConfigration.h>
#include <PMMUDPBridge/PMMUDPBridge.h>
#include <PMMUSBConfigration/PMMUSBConfigration.h>
#include <PMM1103DeviceLib/PMM1103MasterDevice/PMM1103MasterDevice.h>

#include <HC595.h>
#include <variant.h>
#include "wiring_private.h"
#include <RingBuffer.h>
#include <ADE7758/ADE7758Lib.h>

#include <SolarCalculator/src/SolarCalculator.h>
#include "ArduinoLowPower.h"

WDTZero MyWatchDoggy;
ADE7758 PMMADE7758(3);
int volatile repetitions = 0;
int printTiming = 0;
void decimalToOutput(int num);
bool inSleep = false;
void setup()
{
  // delay(5000);
  MyWatchDoggy.setup(WDT_SOFTCYCLE2M);
  SerialUSB.begin(9600);
  initializeProject();
}
void loop()
{

  MyWatchDoggy.clear();
  // if (PMM0501Device)
  // {
  //   // GateWay or Bridge
  //   if (bridgeOrModBus)
  //     PMMGateWayLoop();
  //   else
  //     PMMUDPLoop();
  //   if (webPageConfugration)
  //     PMMWebCommunication(); // Webserver
  // }
  // else if (PMM1003Device)
  // {
  //   PMM1003Loop();
  //   if (webPageConfugration)
  //     PMMWebCommunication(); // Webserver
  // }
  // else if (PMM1002Device)
  // {
  //   PMM1002Loop();
  //   if (webPageConfugration)
  //     PMMWebCommunication(); // Webserver
  // }
  // else if (PMM6032Device)
  // {
  //   PMM0632Loop();
  //   if (webPageConfugration)
  //     PMMWebCommunication(); // Webserver
  // }
  // else if (PMM0620Device)
  // {
  //   PMM0620Loop();
  //   if (webPageConfugration)
  //     PMMWebCommunication(); // Webserver
  // }
  // else if (PMM0625TDevice || PMM0626RDevice || PMM0627Device)
  // {
  //   PMM0625TLoop();
  //   if (webPageConfugration)
  //     PMMWebCommunication(); // Webserver
  // }
  // else if (PMM0638Device)
  // {
  //   PMM0638Loop();
  //   if (webPageConfugration)
  //     PMMWebCommunication(); // Webserver
  // }
  // else if (PMM0630Device)
  // {
  //   PMM0630Loop();
  //   if (webPageConfugration)
  //     PMMWebCommunication(); // Webserver
  // }
  // else if (PMM0639Device)
  // {
  //   PMM0639Loop();
  //   if (webPageConfugration)
  //     PMMWebCommunication();
  // }
  // else if (PMM0406Device)
  // {
  //   PMM0406Loop();
  //   // SerialUSB.print(".");
  //   // delay(1000);
  // }
  // else if (PMM0612Device)
  // {
  //   PMMUDPLoop();
  //   if (webPageConfugration)
  //     PMMWebCommunication();
  // }
  // else if (PMM0613Device)
  // {
  //   PMMLoop0613();
  //   if (webPageConfugration)
  //     PMMWebCommunication();
  // }
  // else if (PMM1103MasterDevice)
  //   PMM1103MasterLoop();
  // else if (PMM1103SlavDevice)
  // {
  PMM1103SlaveLoop();
  PMMConfigrationLoop();
  // }
}
