#include <Arduino.h>

int ams_init();
void ams_tuning();

int ams_sma(int );
int ams_ema(int );
