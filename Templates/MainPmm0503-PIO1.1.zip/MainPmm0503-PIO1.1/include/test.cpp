
//#include "PmmCommands.cpp"

#include <PmmCommands.h>
#include <PmmTypes.h>

void testclass()
{

ThisProduct.PmmGeneral.DeviceName = 622;


}

//xxxx=10 ; 