typedef enum {P_BOOL, P_CHAR, P_UCHAR, P_INT, P_UINT, P_LONG, P_ULONG, P_DOUBLE} packet_t;
